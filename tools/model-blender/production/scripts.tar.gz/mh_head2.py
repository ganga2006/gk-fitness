"""
GK Fitness — trainer face finishing, eyes, eyebrows and hairstyle.
Runs after mh_face.py (face laid on the real skull).

Face  : squarer jaw angle, stronger chin, firmer brow ridge — smooth fields
        sized by the fitted mandible, so the slim structure is kept.
Hair  : short textured crop — tight buzzed sides and back, 2-3 cm textured top
        swept up and back at the front, natural male hairline with slight
        temple recession. Built as a shell grown from the scalp itself.
Brows : thick, fairly straight male eyebrows on the brow ridge.
"""
import bpy, bmesh, json, math, os
from mathutils import Vector, noise
OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped_face_v1.blend'))
for nm in ('Hair', 'Eyes', 'Brows'):
    if nm in bpy.data.objects: bpy.data.objects.remove(bpy.data.objects[nm])
body = bpy.data.objects['Body']
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
C = json.load(open(os.path.join(OUT, 'face_metrics.json')))['colors']
EL, ER, MO = J['l-eye'], J['r-eye'], J['mouth']; E = (EL + ER) / 2
def sm(t): t = max(0.0, min(1.0, t)); return t*t*(3-2*t)
def g(x, c, w): return math.exp(-((x - c) / w) ** 2)
srgb2lin = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

# ── 0. handsome male face: artist-made CC0 MakeHuman detail morphs ─
import numpy as np
DF = np.load(os.path.join(OUT, 'anatomy', 'face_recipe.npy'))
for v in body.data.vertices:
    if v.co.z > 9.85:
        v.co += Vector(DF[v.index]) * sm((v.co.z - 9.90) / 0.30)
body.data.update()
# ── 1. masculine trainer refinements ───────────────────────────────
bm = bmesh.new(); bm.from_mesh(body.data); bm.verts.ensure_lookup_table(); bm.normal_update()
for v in bm.verts:
    c = v.co
    if c.z < 10.0: continue
    ay = abs(c.y); s = 1 if c.y >= 0 else -1; n = v.normal
    # jaw angle: wider and crisper at the gonion
    wj = g(c.z, MO.z - 0.24, 0.12) * g(ay, 0.42, 0.10) * g(c.x, E.x - 0.50, 0.22)
    c.y += s * 0.030 * wj; c.z -= 0.012 * wj
    # chin: forward and a touch squarer
    wc = g(c.z, MO.z - 0.30, 0.09) * g(ay, 0.0, 0.16) * sm((c.x - (MO.x - 0.25)) / 0.15)
    c.x += 0.012 * wc
    c.y += s * 0.012 * g(c.z, MO.z - 0.30, 0.09) * g(ay, 0.12, 0.06) * sm((c.x - (MO.x - 0.25)) / 0.15)
    # brow ridge
    wb = g(c.z, E.z + 0.12, 0.06) * g(ay, 0.26, 0.20) * sm((c.x - (E.x - 0.05)) / 0.1)
    c.x += 0.026 * wb
# ── 1d. jawline in profile, ears, lips ─────────────────────────────
for v in bm.verts:
    c = v.co; ay = abs(c.y)
    # crisp under-jaw: pull the throat below the chin back -> defined cervicomental angle
    if 10.05 < c.z < 10.45 and ay < 0.42 and c.x > 0.30:
        w = g(c.z, 10.27, 0.09) * sm((c.x - 0.30) / 0.25) * sm((0.42 - ay) / 0.12)
        c.x -= 0.065 * w
    # under the jaw at the sides: tuck in below the mandible border
    if 10.15 < c.z < 10.50 and 0.25 < ay < 0.55 and -0.1 < c.x < 0.9:
        c.y -= (1 if c.y > 0 else -1) * 0.025 * g(c.z, 10.33, 0.08) * g(ay, 0.42, 0.10)
    # ears pinned back toward the head
    for e in (1, -1):
        ec = Vector((E.x - 0.60, 0.50 * e, E.z - 0.12))
        if c.y * e > 0.45 and (c - ec).length < 0.30:
            c.y -= e * (abs(c.y) - 0.45) * 0.30 * sm(1 - (c - ec).length / 0.30)
# ── 1c. aesthetic face shape ──────────────────────────────────────
# Measured: the face was widest at the mouth (51.6 mm half-width) and narrower at
# the cheekbones (48.9) — the chubby lower face. Aesthetic male proportion: the
# cheekbones are the widest point, tapering in a clean V to a defined jaw.
TARGET = [(11.25, 1.00), (11.05, 1.00), (10.95, 0.985), (10.85, 0.935), (10.75, 0.915), (10.65, 0.935), (10.55, 0.96), (10.45, 1.0), (10.30, 1.0)]
def width_factor(z):
    if z >= TARGET[0][0]: return 1.0
    for (z0, f0), (z1, f1) in zip(TARGET, TARGET[1:]):
        if z1 <= z <= z0: t = (z0 - z) / (z0 - z1); return f0 + (f1 - f0) * (t*t*(3-2*t))
    return 1.0
for v in bm.verts:
    c = v.co
    if not (10.25 < c.z < 11.3): continue
    f = width_factor(c.z)
    w = sm((c.x - (E.x - 0.75)) / 0.30)                       # face, not the back of the head
    w *= sm((abs(c.y) - 0.05) / 0.12)                         # keep the midline features as they are
    c.y *= 1 + (f - 1) * w
def find_slit(verts, lo=10.60, hi=10.80):
    """mouth line = deepest point of the midline profile between chin and nose"""
    best = None
    for z10 in range(int(lo * 100), int(hi * 100)):
        z = z10 / 100.0
        xs = [v.co.x for v in verts if abs(v.co.y) < 0.015 and abs(v.co.z - z) < 0.006 and v.co.x > 0.9]
        if not xs: continue
        x = max(xs)
        if best is None or x < best[1]: best = (z, x)
    return best[0]
import numpy as _np
LM = _np.load(os.path.join(OUT, 'anatomy', 'lip_masks.npy'))
def lip_centres(verts):
    up = [v.co for v in verts if LM[v.index, 0] > 0.5]; lo = [v.co for v in verts if LM[v.index, 1] > 0.5]
    zu = sum(p.z for p in up) / len(up); zl = sum(p.z for p in lo) / len(lo)
    xf = max(p.x for p in up + lo)
    return zu, zl, xf
_zu, _zl, _xf = lip_centres(bm.verts); SL0 = (_zu + _zl) / 2
# aesthetic lower third: mouth line one third of the way from nose base to chin.
# Move the whole mouth (inner lips included) down; the philtrum stretches above,
# the chin pad compresses below — both over wide, gentle falloffs.
DROP = -(0.673 + 10.0 - SL0) if False else 0.0
for v in bm.verts:
    c = v.co
    if c.x < 0.55 or not (SL0 - 0.30 < c.z < SL0 + 0.13): continue
    up = sm(((SL0 + 0.115) - c.z) / 0.075)                  # 0 at the nose base -> 1 at the upper lip
    dn = sm((c.z - (SL0 - 0.28)) / 0.15)                    # 0 at the chin -> 1 at the lower lip
    lat = sm((0.46 - abs(c.y)) / 0.16)
    c.z -= DROP * up * dn * lat
# lengthen the philtrum: carry the whole mouth down ~4 mm, nose base stays
for v in bm.verts:
    c = v.co
    if c.x < 0.85 or not (SL0 - 0.30 < c.z < SL0 + 0.12): continue
# separate lip and chin: less fullness right under the lower lip, chin projection set lower
_zu, _zl, _xf = lip_centres(bm.verts); SL = (_zu + _zl) / 2; print('mouth line at z %.3f (was %.3f)' % (SL, SL0))
# nose/upper-lip profile: a real subnasale dip, a projected tip, a defined upper lip
for v in bm.verts:
    c = v.co; ay = abs(c.y)
    if c.x < 1.0 or not (SL - 0.1 < c.z < SL + 0.25): continue
    c.x -= 0.016 * g(c.z, SL + 0.085, 0.020) * g(ay, 0.0, 0.10)
    c.x += 0.022 * g(c.z, SL + 0.140, 0.028) * g(ay, 0.0, 0.07)
    c.z += 0.008 * g(c.z, SL + 0.140, 0.028) * g(ay, 0.0, 0.07)
# soften the crease under the lower lip: it read as a second, frowning mouth
for v in bm.verts:
    c = v.co
    if c.x > 0.9 and SL - 0.20 < c.z < SL - 0.04:
        c.x += 0.018 * g(c.z, SL - 0.112, 0.026) * g(abs(c.y), 0.0, 0.24)
CR = [v for v in bm.verts if v.co.x > 0.9 and SL - 0.18 < v.co.z < SL - 0.06 and abs(v.co.y) < 0.32]
for _ in range(5):
    mv = {}
    for v in CR:
        ring = [e.other_vert(v).co for e in v.link_edges]; mv[v] = (sum(ring, Vector())/len(ring) - v.co) * 0.5
    for v, dd in mv.items(): v.co += dd
bm.to_mesh(body.data); bm.normal_update(); body.data.update()
print('trainer face refinements applied (jaw, chin, brow, nose, lips, cheekbones, canthal tilt)')

def mat(name, rgb, rough, spec=0.5):
    m = bpy.data.materials.new(name); m.use_nodes = True; b = m.node_tree.nodes['Principled BSDF']
    b.inputs['Base Color'].default_value = (*rgb, 1); b.inputs['Roughness'].default_value = rough
    return m

# ── 2. eyes ────────────────────────────────────────────────────────
parts = []
for e in (EL, ER):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=20, radius=0.106, location=e + Vector((0.010, 0, 0)))
    bpy.ops.object.shade_smooth(); parts.append(bpy.context.active_object)
for o in bpy.data.objects: o.select_set(o in parts)
bpy.context.view_layer.objects.active = parts[0]; bpy.ops.object.join()
eyes = bpy.context.active_object; eyes.name = 'Eyes'
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)   # mesh in world space
eyes.data.materials.append(mat('eyes', (0.80, 0.78, 0.76), 0.15))
eyes.data.materials.append(mat('iris', (0.075, 0.040, 0.020), 0.10))
eyes.data.materials.append(mat('pupil', (0.004, 0.004, 0.004), 0.05))
aimdir = {}
bnd = [v.co.copy() for v in bm.verts if v.is_boundary]
for key, e in (('l', EL), ('r', ER)):
    ring = [p for p in bnd if (p - e).length < 0.26]
    aimdir[key] = ((sum(ring, Vector()) / len(ring)) - e).normalized() if ring else Vector((1, 0, 0))
print('iris aim:', {k: tuple(round(x, 2) for x in v) for k, v in aimdir.items()})
for p in eyes.data.polygons:
    key = 'l' if p.center.y > 0 else 'r'; ctr = EL if key == 'l' else ER
    d = (p.center - ctr).normalized().dot(aimdir[key])
    if d > 0.985: p.material_index = 2
    elif d > 0.925: p.material_index = 1

# ── 3. hair shell grown from the scalp ─────────────────────────────
HC = Vector((E.x - 0.55, 0.0, E.z + 0.05))
def hairline_z(phi):
    """hairline height (above eye line) vs azimuth: 0 = front, 180 = back"""
    p = abs(phi)
    pts = [(0, 0.54), (22, 0.53), (38, 0.42), (52, 0.38), (64, 0.18), (78, 0.10), (100, 0.10), (125, 0.00), (150, -0.32), (180, -0.40)]
    for (a0, z0), (a1, z1) in zip(pts, pts[1:]):
        if a0 <= p <= a1: t = (p - a0) / (a1 - a0); return z0 + (z1 - z0) * (t*t*(3-2*t))
    return pts[-1][1]
def ear(c):
    for e in (1, -1):
        ec = Vector((E.x - 0.62, 0.50 * e, E.z - 0.10))
        if (Vector((c.x, c.y, c.z)) - ec).length < 0.24 and abs(c.y) > 0.40: return True
    return False
scalp, tval, mval = set(), {}, {}
def ear_gap(c):
    k = 1.0
    for e in (1, -1):
        ec = Vector((E.x - 0.60, 0.50 * e, E.z - 0.12))
        k = min(k, sm(((c - ec).length - 0.20) / 0.06))
    return k
for v in bm.verts:
    c = v.co
    if c.z < MO.z - 0.10: continue
    d = c - HC; phi = math.degrees(math.atan2(d.y, d.x))
    hz = hairline_z(phi) + E.z
    if c.z < hz - 0.10: continue
    m = sm((c.z - (hz - 0.02)) / 0.07) * ear_gap(c)               # smooth hairline + gap around the ears
    top = sm((c.z - (E.z + 0.30)) / 0.22)
    front = sm((d.x - 0.20) / 0.45)
    t = 0.021 + top * (0.068 + 0.090 * front)                     # ~3 mm clipper sides; 1.3-2.7 cm top
    scalp.add(v.index); tval[v.index] = t * m - 0.010 * (1 - m); mval[v.index] = (m, top, front)
faces = [f for f in bm.faces if all(v.index in scalp for v in f.verts) and max(mval[v.index][0] for v in f.verts) > 0.02]
hb = bmesh.new(); vmap = {}
for f in faces:
    for v in f.verts:
        if v.index in vmap: continue
        m, top, front = mval[v.index]; c = v.co; n = v.normal
        off = n * tval[v.index]
        # swept up and back at the front, textured clumps running front-to-back
        off += Vector((0.035, 0, 0.055)) * top * front * front * m
        # strand clumps: long along the comb direction (front->back), narrow across it
        clump = noise.noise(Vector((c.x * 3.0, c.y * 22.0, c.z * 5.0))) + 0.5 * noise.noise(Vector((c.x * 7.0, c.y * 45.0, c.z * 9.0)))
        off += n * (0.014 * clump * top * m)
        vmap[v.index] = hb.verts.new(c + off)
for f in faces: hb.faces.new([vmap[v.index] for v in f.verts])
hm = bpy.data.meshes.new('Hair'); hb.to_mesh(hm); hb.free()
hair = bpy.data.objects.new('Hair', hm); bpy.context.scene.collection.objects.link(hair)
bpy.context.view_layer.objects.active = hair
for o in bpy.data.objects: o.select_set(o == hair)
sd = hair.modifiers.new('sub', 'SUBSURF'); sd.levels = 1; bpy.ops.object.modifier_apply(modifier='sub')
so = hair.modifiers.new('sol', 'SOLIDIFY'); so.thickness = 0.014; so.offset = -1; bpy.ops.object.modifier_apply(modifier='sol')
bpy.ops.object.shade_smooth()
hrgb = tuple(srgb2lin(x / 255) for x in C['hair'])
hm_ = mat('hair', hrgb, 0.58); nt = hm_.node_tree; bs = nt.nodes['Principled BSDF']
tex = nt.nodes.new('ShaderNodeTexNoise'); tex.inputs['Scale'].default_value = 160; tex.inputs['Detail'].default_value = 10
mp = nt.nodes.new('ShaderNodeMapping'); mp.inputs['Scale'].default_value = (0.25, 1.0, 0.6)   # streaks along the comb line
tc = nt.nodes.new('ShaderNodeTexCoord'); nt.links.new(tc.outputs['Object'], mp.inputs['Vector']); nt.links.new(mp.outputs['Vector'], tex.inputs['Vector'])
ramp = nt.nodes.new('ShaderNodeValToRGB'); ramp.color_ramp.elements[0].color = (*[x * 0.55 for x in hrgb], 1); ramp.color_ramp.elements[1].color = (*[min(1, x * 1.9) for x in hrgb], 1)
nt.links.new(tex.outputs['Fac'], ramp.inputs['Fac']); nt.links.new(ramp.outputs['Color'], bs.inputs['Base Color'])
bump = nt.nodes.new('ShaderNodeBump'); bump.inputs['Strength'].default_value = 0.35
nt.links.new(tex.outputs['Fac'], bump.inputs['Height']); nt.links.new(bump.outputs['Normal'], bs.inputs['Normal'])
hair.data.materials.append(hm_)
print('hair verts:', len(hair.data.vertices), ' colour', C['hair'])

# ── 4. eyebrows ────────────────────────────────────────────────────
brow, bh = set(), {}
for v in bm.verts:
    c = v.co; best = -1.0
    for e in (EL, ER):
        s_ = 1 if e.y > 0 else -1; u = (c.y * s_ - 0.065) / 0.37
        if c.x < e.x - 0.12 or not (-0.15 <= u <= 1.15): continue
        zc = e.z + 0.158 + 0.024 * math.sin(math.pi * min(1, max(0, u) / 0.72)) - 0.045 * max(0, u - 0.72) / 0.28
        hh = 0.052 * (1 - 0.50 * max(0, min(1, u)))
        inside = min((hh - abs(c.z - zc)) / 0.016, min(u + 0.02, 1.02 - u) / 0.05)   # >0 inside the brow shape
        best = max(best, inside)
    if best > -1.0:
        brow.add(v.index); bh[v.index] = 0.011 * sm(best) - 0.006 * (1 - sm(best + 1))
bfaces = [f for f in bm.faces if all(v.index in brow for v in f.verts) and max(bh[v.index] for v in f.verts) > 0]
bb = bmesh.new(); bmap = {}
for f in bfaces:
    for v in f.verts:
        if v.index not in bmap: bmap[v.index] = bb.verts.new(v.co + v.normal * bh[v.index])
for f in bfaces: bb.faces.new([bmap[v.index] for v in f.verts])
bmh = bpy.data.meshes.new('Brows'); bb.to_mesh(bmh); bb.free()
brows = bpy.data.objects.new('Brows', bmh); bpy.context.scene.collection.objects.link(brows)
for o in bpy.data.objects: o.select_set(o == brows)
bpy.context.view_layer.objects.active = brows
sd = brows.modifiers.new('sub', 'SUBSURF'); sd.levels = 1; bpy.ops.object.modifier_apply(modifier='sub')
bpy.ops.object.shade_smooth(); brows.data.materials.append(bpy.data.materials['hair'])
print('brow faces:', len(bfaces))
bm.free()
skin = [(a + b) / 2 for a, b in zip(C['skin_cheek'], C['skin_fore'])]
json.dump({'skin': skin, 'hair': C['hair'], 'beard': C['beard'], 'lip': C['lip']}, open(os.path.join(OUT, 'palette.json'), 'w'))
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend (face + eyes + brows + hair)')
