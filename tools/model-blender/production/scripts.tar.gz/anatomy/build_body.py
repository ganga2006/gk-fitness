"""Builds the full posed anatomy: every bone + every superficial muscle, in the trainer's pose."""
import sys, re, bpy, bmesh, numpy as np
sys.path.insert(0, '/home/claude/mh/anatomy')
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bp3d_io import read_stl, make_object
from parts import skeleton_parts, NAMES
import body_rig_map as M
bpy.ops.wm.read_factory_settings(use_empty=True)
cb = bpy.data.collections.new('Skeleton'); bpy.context.scene.collection.children.link(cb)
cm = bpy.data.collections.new('Muscles'); bpy.context.scene.collection.children.link(cm)

THICK = [  # athletic build: how much each muscle's thickness grows (outer face only)
 (r'pectoralis major', 1.50), (r'deltoid', 1.50), (r'descending part of .* trapezius', 1.05),
 (r'trapezius', 1.40), (r'latissimus', 1.75), (r'serratus anterior', 1.30), (r'rectus abdominis', 1.35),
 (r'infraspinatus|teres', 1.55), (r'rhomboid', 1.3), (r'iliocostalis|longissimus|spinalis', 1.45),
 (r'gluteus maximus', 1.20), (r'gluteus medius|tensor fasciae', 0.95),
 (r'biceps brachii', 1.65), (r'triceps', 1.45), (r'brachialis', 1.40), (r'brachioradialis', 1.55),
 (r'extensor carpi|flexor carpi|flexor digitorum superficialis|palmaris|pronator teres|extensor digitorum$', 1.35),
 (r'vastus medialis', 1.05), (r'rectus femoris|vastus', 1.25), (r'biceps femoris|semitendinosus|semimembranosus', 1.25),
 (r'medial head of .* gastrocnemius', 1.40), (r'lateral head of .* gastrocnemius', 1.10), (r'soleus', 1.20), (r'tibialis anterior', 1.25),
 (r'external oblique', 0.80),
 (r'sternocleidomastoid|splenius|levator scapulae|semispinalis|longissimus capitis', 1.0),
]
def thick_of(nm):
    for rx, k in THICK:
        if re.search(rx, nm): return k
    return 1.0

def decimate(ob, target):
    n = len(ob.data.vertices)
    if n <= target: return
    m = ob.modifiers.new('d', 'DECIMATE'); m.ratio = target / n
    with bpy.context.temp_override(object=ob, active_object=ob): bpy.ops.object.modifier_apply(modifier='d')

def thicken(ob, k, nm):
    if abs(k - 1.0) < 1e-6: return
    bm = bmesh.new(); bm.from_mesh(ob.data); bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-4)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces); bm.normal_update(); tree = BVHTree.FromBMesh(bm)
    cen = np.array([v.co for v in bm.verts]).mean(0)
    disp = {}
    for v in bm.verts:
        n = v.normal
        # 'outer face' = facing away from the muscle's own deep side: test against the body axis
        out = Vector((v.co.x - 0.30, v.co.y, 0)) if v.co.z > 5.6 or abs(v.co.y) < 0.4 else Vector((v.co.x - cen[0], v.co.y - cen[1], 0))
        if out.length > 1e-6 and n.dot(out.normalized()) < 0.10: continue
        hit = tree.ray_cast(v.co - n * 1e-3, -n, 0.6)
        if hit[0] is None: continue
        zw = 0.35 + 0.65 * max(0.0, min(1.0, (v.co.z - 8.55) / 0.75)) if 'pectoralis' in nm else 1.0
        disp[v.index] = n * ((k - 1) * hit[3] * zw)
    for _ in range(5):
        new = {}
        for v in bm.verts:
            if v.index not in disp: continue
            nb = [disp[e.other_vert(v).index] for e in v.link_edges if e.other_vert(v).index in disp]
            new[v.index] = (disp[v.index]*2 + sum(nb, Vector())) / (2 + len(nb))
        disp = new
    for v in bm.verts:
        if v.index in disp: v.co += disp[v.index]
    bm.to_mesh(ob.data); bm.free()

nb = 0
for grp, ids in skeleton_parts().items():
    if grp == 'other': continue
    for fid in ids:
        P, Fc = read_stl(fid); ob = make_object(f'bone_{grp}_{fid}', M.map_points(P), Fc, cb)
        decimate(ob, 2500 if len(P) > 2500 else len(P)); nb += 1
print('bones placed:', nb)
nm_ = 0
for line in open('/home/claude/mh/anatomy/muscle_ids.txt'):
    fid, nm = line.strip().split('|')
    P, Fc = read_stl(fid); ob = make_object(f'mus_{nm.replace(" ", "_")}', M.map_points(P), Fc, cm)
    decimate(ob, 7000); thicken(ob, thick_of(nm), nm); nm_ += 1
print('muscles placed:', nm_)
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/anatomy/body_anatomy.blend')
print('saved body_anatomy.blend')
