"""Item 1 — narrow the pelvis: hip joints 23 cm -> ~19 cm apart (real male ~17-19 cm)."""
import bpy, json, math
from mathutils import Vector
D = 0.20                                  # units per side: hip joints 17.6 cm apart (real male 17-18 cm)
def sm(t): t = max(0.0, min(1.0, t)); return t*t*(3-2*t)
def shift(x, y, z):
    wz = sm((7.10 - z) / 0.85)            # full at/below the hip joints, 0 at the waist
    f = sm(abs(y) / 0.45)                 # midline (groin) stays put
    return y - math.copysign(D * wz * f, y)
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/mh_shaped_chest_v1.blend')
# ── arm length: upper arm 24 -> 30.5 cm, forearm 24 -> 26 cm (178 cm male norms) ──
Jo = {k: Vector(v) for k, v in json.load(open('/home/claude/mh/joints_mh_original.json')).items()}
UNIT_CM = 14.74
ARM = {}
for sd, sg in (('l', 1), ('r', -1)):
    S_, E_, H_ = Jo[f'{sd}-shoulder'], Jo[f'{sd}-elbow'], Jo[f'{sd}-hand']
    d1, L1 = (E_ - S_).normalized(), (E_ - S_).length; d2, L2 = (H_ - E_).normalized(), (H_ - E_).length
    ARM[sd] = (S_, E_, H_, d1, L1, d2, L2, 30.5 / UNIT_CM - L1, 26.0 / UNIT_CM - L2, sg)
def seg_dist(p, a, b):
    ab = b - a; t = (p - a).dot(ab) / ab.length_squared
    return t, (p - (a + ab * max(0.0, min(1.0, t)))).length
def arm_shift(p):
    out = Vector((0, 0, 0))
    for sd, (S_, E_, H_, d1, L1, d2, L2, dL1, dL2, sg) in ARM.items():
        if p.y * sg < 0.6: continue
        t1, r1 = seg_dist(p, S_, E_); t2, r2 = seg_dist(p, E_, H_)
        near = max(sm((0.62 - r1) / 0.15) * sm((t1 - 0.05) / 0.10), 1.0 if (0.0 < t2 <= 1.0 and r2 < 0.55) else 0.0, 1.0 if (t2 > 0.98 and seg_dist(p, H_, Jo[f'{sd}-finger-3-4'] + (Jo[f'{sd}-finger-3-4'] - H_) * 0.15)[1] < 0.75) else 0.0)
        if near <= 0: continue
        a1 = dL1 * sm((t1 - 0.15) / 0.80) if t2 <= 0 else dL1
        a2 = dL2 * sm(t2 / 1.0) if t2 > 0 else 0.0
        out += (d1 * a1 + d2 * a2) * near
    return out
for o in bpy.data.objects:
    if o.type != 'MESH': continue
    for v in o.data.vertices:
        v.co += arm_shift(v.co.copy())
        v.co.y = shift(v.co.x, v.co.y, v.co.z)
J = json.load(open('/home/claude/mh/joints_mh_original.json'))
for k, p in J.items():
    q = Vector(p)
    if k[:2] in ('l-', 'r-') and any(t in k for t in ('elbow', 'hand', 'finger')):
        sd = k[0]; S_, E_, H_, d1, L1, d2, L2, dL1, dL2, sg = ARM[sd]
        q += d1 * dL1 + (d2 * dL2 if ('hand' in k or 'finger' in k) else Vector())
    p[0], p[1], p[2] = q.x, q.y, q.z
    p[1] = shift(*p)
json.dump(J, open('/home/claude/mh/joints.json', 'w'), indent=1)
print('upper arm %.1f cm, forearm %.1f cm' % ((Vector(J['l-elbow'])-Vector(J['l-shoulder'])).length*UNIT_CM, (Vector(J['l-hand'])-Vector(J['l-elbow'])).length*UNIT_CM))
print('hip joints now y=±%.3f  knees ±%.3f  ankles ±%.3f' % (J['l-upper-leg'][1], J['l-knee'][1], J['l-ankle'][1]))
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/mh_shaped_pre_fullwrap.blend')
