"""
One shared mapping from the BodyParts3D male (mm, +X left, -Y front, +Z up) into
the trainer's space (units, +X front, +Y left, +Z up, height 12).

Every bone and muscle goes through these functions, so the skeleton, the muscles
and the skin wrap all agree.
"""
import json, os
import numpy as np
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
MH = os.path.dirname(HERE)
L = {k: np.array(v) for k, v in json.load(open(os.path.join(HERE, 'bp3d_landmarks.json'))).items()}
J0 = {k: np.array(v) for k, v in json.load(open(os.path.join(MH, 'joints_mh_original.json'))).items()}

# vertical scale and offset: the shoulder and hip joint centres line up exactly
S = (J0['l-shoulder'][2] - J0['l-upper-leg'][2]) / (L['l-shoulder'][2] - L['l-hip'][2])
Z0 = J0['l-shoulder'][2] - L['l-shoulder'][2] * S
X0 = -0.335            # front-back placement: centres the ribcage in the trainer's torso
KW_THORAX = 1.05       # a slightly broader chest than the reference male
KW_PELVIS = 1.15

# ── proportions ────────────────────────────────────────────────────
# The MakeHuman base has a short upper arm (shoulder->elbow = 0.137 H against
# 0.17-0.186 H in real adults), which leaves the hands up at the hips. The upper
# arm is lengthened to the reference skeleton's ratio; forearm, hand and leg
# segments are already within normal ranges.
UPPER_ARM_TARGET = np.linalg.norm(
    (np.array([-L['l-elbow'][1], L['l-elbow'][0], L['l-elbow'][2]]) -
     np.array([-L['l-shoulder'][1], L['l-shoulder'][0], L['l-shoulder'][2]])) * S)

def arm_stretch(side):
    sh, el = J0[f'{side}-shoulder'], J0[f'{side}-elbow']
    d = el - sh
    L0 = np.linalg.norm(d)
    return sh, d / L0, L0, UPPER_ARM_TARGET / L0

ARM_JOINTS = ('elbow', 'hand', 'hand-2', 'hand-3') + tuple(
    f'finger-{f}-{k}' for f in range(1, 6) for k in range(1, 5))

def target_joints():
    """MakeHuman joints after the upper-arm correction."""
    J = {k: v.copy() for k, v in J0.items()}
    for side in ('l', 'r'):
        sh, u, L0, k = arm_stretch(side)
        shift = u * (k - 1) * L0
        for nm in ARM_JOINTS:
            key = f'{side}-{nm}'
            if key in J:
                J[key] = J[key] + shift
    return J

J = target_joints()

# ── axial warp ─────────────────────────────────────────────────────
def axes(P):
    """BodyParts3D axes -> trainer axes, still in mm."""
    P = np.atleast_2d(P)
    return np.c_[-P[:, 1], P[:, 0], P[:, 2]]

def kw_of(zmm):
    t = np.clip((zmm - 960.0) / (1100.0 - 960.0), 0, 1)
    t = t * t * (3 - 2 * t)
    return KW_PELVIS + (KW_THORAX - KW_PELVIS) * t

def warp_axial(P):
    P = np.atleast_2d(P)
    Q = axes(P)
    return np.c_[X0 + Q[:, 0] * S, Q[:, 1] * S * kw_of(P[:, 2]), Z0 + Q[:, 2] * S]

def lm(key):
    """A landmark in trainer axes (mm), for building segment transforms."""
    return axes(L[key])[0]

def rot_between(a, b):
    q = Vector(a).rotation_difference(Vector(b))
    return np.array(q.to_matrix())

def segment(A_bp, B_bp, A, B, C_bp=None, C=None):
    """
    Rigid similarity placing a bone segment between two of the trainer's joints.
    A_bp/B_bp are landmark points in trainer axes (mm); A/B are trainer joints.
    An optional third pair fixes the roll (used for the hand).
    """
    d_bp, d = B_bp - A_bp, B - A
    k = np.linalg.norm(d) / np.linalg.norm(d_bp)
    if C_bp is None:
        R = rot_between(d_bp, d)
    else:
        def frame(a, c):
            e1 = a / np.linalg.norm(a)
            e2 = c - e1 * (c @ e1); e2 /= np.linalg.norm(e2)
            return np.c_[e1, e2, np.cross(e1, e2)]
        R = frame(d, C - A) @ frame(d_bp, C_bp - A_bp).T
    return lambda Q: A + ((Q - A_bp) * k) @ R.T

def girdle_shift(side):
    """How far the warped shoulder socket sits from the trainer's shoulder joint."""
    return J[f'{side}-shoulder'] - warp_axial(L[f'{side}-shoulder'])[0]

if __name__ == '__main__':
    print('S', S, 'Z0', Z0, 'upper arm target', UPPER_ARM_TARGET)
    for side in ('l', 'r'):
        sh, u, L0, k = arm_stretch(side)
        print(side, 'upper arm', round(L0, 3), '->', round(L0 * k, 3), f'(x{k:.3f})',
              'girdle shift', np.round(girdle_shift(side), 3))
    print('new elbow', np.round(J['l-elbow'], 3), 'new hand', np.round(J['l-hand'], 3))

# ── mesh-side upper-arm correction ─────────────────────────────────
def _closest_on_segment(P, a, b):
    ab = b - a
    t = np.clip(((P - a) @ ab) / (ab @ ab), 0, 1)
    return np.linalg.norm(P - (a + t[:, None] * ab), axis=1), t

def stretch_arms(co):
    """
    Lengthen the MakeHuman upper arms in place (co: (N,3) trainer coordinates).

    Upper-arm vertices slide along the arm axis in proportion to how far down the
    arm they sit; everything past the elbow moves rigidly with it. Torso vertices
    are excluded by their distance from the arm axis, so the chest wall and the
    armpit do not get dragged along.
    """
    co = np.asarray(co, float).copy()
    for side in ('l', 'r'):
        sh, u, L0, k = arm_stretch(side)
        el, hd = J0[f'{side}-elbow'], J0[f'{side}-hand']
        tip = J0[f'{side}-finger-3-4'] if f'{side}-finger-3-4' in J0 else hd + (hd - el) * 0.5
        rel = co - sh
        t = (rel @ u) / L0
        radial = np.linalg.norm(rel - np.outer(t * L0, u), axis=1)
        d_up, _ = _closest_on_segment(co, sh, el)
        d_fa, _ = _closest_on_segment(co, el, hd)
        d_hd, _ = _closest_on_segment(co, hd, tip)
        beyond = (np.minimum(d_fa, d_hd) < d_up) & (np.minimum(d_fa, d_hd) < 0.9)
        w_up = np.clip((0.80 - radial) / (0.80 - 0.52), 0, 1)
        w_up = w_up * w_up * (3 - 2 * w_up)
        amount = np.where(beyond, 1.0, w_up * np.clip(t, 0, 1))
        amount[(t <= 0) & ~beyond] = 0.0
        co += np.outer(amount * (k - 1) * L0, u)
    return co
