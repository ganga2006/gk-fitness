"""Full-body Cycles review: front, side, back. usage: -- <blend> <prefix>"""
import bpy, os, math, sys
from mathutils import Vector
args = sys.argv[sys.argv.index('--') + 1:]
bpy.ops.wm.open_mainfile(filepath=args[0]); pre = args[1]
sc = bpy.context.scene
for o in bpy.data.objects:
    if o.type == 'MESH' and o.name not in ('Body',): o.hide_render = True
body = bpy.data.objects['Body']
for m in body.modifiers:
    if m.type == 'ARMATURE': m.show_render = False
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 20; sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = 420, 900
w = bpy.data.worlds.new('W'); w.use_nodes = True
w.node_tree.nodes['Background'].inputs[0].default_value = (0.05, 0.06, 0.08, 1); sc.world = w
mat = bpy.data.materials.new('skin_review'); mat.use_nodes = True
b = mat.node_tree.nodes['Principled BSDF']; b.inputs['Base Color'].default_value = (0.62, 0.45, 0.36, 1); b.inputs['Roughness'].default_value = 0.5
body.data.materials.clear(); body.data.materials.append(mat)
for p in body.data.polygons: p.material_index = 0; p.use_smooth = True
def light(n, loc, e, sz):
    d = bpy.data.lights.new(n, 'AREA'); d.energy = e; d.size = sz
    o = bpy.data.objects.new(n, d); o.location = loc
    o.rotation_euler = (Vector((0, 0, 6)) - Vector(loc)).normalized().to_track_quat('-Z', 'Y').to_euler(); sc.collection.objects.link(o)
light('key', (12, -9, 16), 16000, 9); light('fill', (10, 12, 8), 4500, 12); light('rim', (-12, 5, 14), 9000, 10); light('rim2', (-11, -8, 9), 4000, 10)
cd = bpy.data.cameras.new('C'); cd.type = 'ORTHO'; cd.ortho_scale = 12.8
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
for tag, az in (('front', -3), ('side', -90), ('back', 182)):
    a = math.radians(az); t = Vector((0.15, 0, 6.0))
    cam.location = t + Vector((math.cos(a), math.sin(a), 0.04)) * 30
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = f'{pre}_{tag}.png'; bpy.ops.render.render(write_still=True)
print('rendered')
