"""
GK Fitness — face, skeleton first: the real skull + mandible + facial muscles,
fitted to the trainer's eye centres, chin, crown and occiput, then fused into an
envelope the face skin is laid onto at lean-athlete tissue depths.
"""
import sys, json, bpy, bmesh, numpy as np
sys.path.insert(0, '/home/claude/mh/anatomy')
from mathutils import Vector
from bp3d_io import read_stl, make_object
from parts import skeleton_parts
J = {k: np.array(v) for k, v in json.load(open('/home/claude/mh/joints.json')).items()}
c = lambda P: np.c_[-P[:, 1], P[:, 0], P[:, 2]]

# ── trainer landmarks (skin) from the current mesh ────────────────
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/mh_shaped.blend')
V = np.array([v.co for v in bpy.data.objects['Body'].data.vertices])
H = V[V[:, 2] > 10.2]
mid = H[np.abs(H[:, 1]) < 0.06]
eyeL, eyeR = J['l-eye'], J['r-eye']; E = (eyeL + eyeR) / 2
top = H[:, 2].max()
chin = 10.42                                                 # menton (skin), as measured for the head script
chin_pt = mid[(mid[:, 0] > E[0] - 0.35)][np.argmin(mid[(mid[:, 0] > E[0] - 0.35)][:, 2])]
back = mid[np.abs(mid[:, 2] - (E[2] + 0.15)) < 0.08][:, 0].min()
print('trainer: eyes z %.3f  top %.3f  chin z %.3f (x %.2f)  occiput x %.3f  IPD %.3f' % (E[2], top, chin, chin_pt[0], back, eyeL[1]-eyeR[1]))

# ── scan landmarks ────────────────────────────────────────────────
eb = c(read_stl('FMA12513')[0]); ebL = eb[eb[:, 1] > 0].mean(0); ebR = eb[eb[:, 1] < 0].mean(0); Eb = (ebL + ebR) / 2
groups = skeleton_parts(); skull_ids = groups['skull']
SK = np.vstack([c(read_stl(f)[0]) for f in skull_ids])
mand = c(read_stl('FMA52748')[0])
menton = mand[np.argmin(mand[:, 2] + 0.0 * mand[:, 0])]
vertex = SK[:, 2].max(); occ = SK[np.abs(SK[:, 2] - (Eb[2] + 22)) < 6][:, 0].min()
print('scan: IPD %.1f mm  eye->vertex %.1f  eye->menton %.1f  eye->occiput %.1f' % (ebL[1]-ebR[1], vertex-Eb[2], Eb[2]-menton[2], Eb[0]-occ))

TIS = {'vertex': 0.040, 'menton': 0.050, 'occiput': 0.045}
sy_ipd = (eyeL[1] - eyeR[1]) / (ebL[1] - ebR[1])
sz_up = ((top - TIS['vertex']) - E[2]) / (vertex - Eb[2])
sz_dn = (E[2] - (chin + TIS['menton'])) / (Eb[2] - menton[2])
sx = (E[0] - (back + TIS['occiput'])) / (Eb[0] - occ)
# slim face: bone width from the skull's own proportions (+4%), not stretched to the eye spacing
sy = min(sy_ipd, 1.04 * (sz_up + sz_dn) / 2)
print('fit scales (units/mm): x %.5f  y %.5f  z-up %.5f  z-down %.5f' % (sx, sy, sz_up, sz_dn))
sm = lambda t: (lambda u: u*u*(3-2*u))(np.clip(t, 0, 1))
def fmap(P):
    Q = c(P) - Eb
    k = sm((Q[:, 2] + 12) / 24)                       # blend the two vertical scales across the eye line
    sz = sz_dn + (sz_up - sz_dn) * k
    return np.c_[E[0] + Q[:, 0] * sx, E[1] + Q[:, 1] * sy, E[2] + Q[:, 2] * sz]

bpy.ops.wm.read_factory_settings(use_empty=True)
cs = bpy.data.collections.new('Skull'); bpy.context.scene.collection.children.link(cs)
cmu = bpy.data.collections.new('FaceMuscles'); bpy.context.scene.collection.children.link(cmu)
for f in skull_ids:
    P, Fc = read_stl(f); make_object(f'skull_{f}', fmap(P), Fc, cs)
THICK = {'masseter': 1.30, 'temporalis': 1.10, 'zygomaticus': 1.10}
for line in open('/home/claude/mh/anatomy/face_ids.txt'):
    fid, nm = line.strip().split('|')
    if 'eyeball' in nm or 'palpebral' in nm or 'nasal cartilages' in nm: continue
    P, Fc = read_stl(fid); Wp = fmap(P)
    k = next((v for key, v in THICK.items() if key in nm), 1.0)
    if k != 1.0:                                     # thicken outward from the skull (lateral for masseter)
        cen = Wp.mean(0); out = Wp - np.array([E[0] - 0.35, 0, cen[2]]); out[:, 2] = 0
        out /= np.linalg.norm(out, axis=1, keepdims=True) + 1e-9
        Wp = Wp + out * (k - 1) * 0.045 * sm(1 - np.linalg.norm(Wp - cen, axis=1) / (np.ptp(Wp, axis=0).max() * 0.6))[:, None]
    make_object(f'fm_{nm.replace(" ", "_")}', Wp, Fc, cmu)
# eyeball reference for socket sizing
make_object('eyeball_ref', fmap(read_stl('FMA12513')[0]), read_stl('FMA12513')[1], cs)
r_eye = np.linalg.norm(fmap(read_stl('FMA12513')[0]) - np.r_[E[0], eyeL[1], E[2]], axis=1)
print('eyeball radius (units) ~', round(float(np.median(r_eye[r_eye < 0.15])), 4))
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/anatomy/face_anatomy.blend')

# ── envelope ───────────────────────────────────────────────────────
obs = [o for o in bpy.data.objects if o.type == 'MESH' and o.name != 'eyeball_ref']
for o in bpy.data.objects: o.select_set(o in obs)
bpy.context.view_layer.objects.active = obs[0]
bpy.ops.object.duplicate(); bpy.ops.object.join(); env = bpy.context.active_object; env.name = 'FaceEnvelope'
def mod(t, **kw):
    m = env.modifiers.new(t.lower(), t)
    for k, v in kw.items(): setattr(m, k, v)
    bpy.ops.object.modifier_apply(modifier=m.name)
mod('REMESH', mode='VOXEL', voxel_size=0.010); mod('SMOOTH', factor=0.5, iterations=3)
D = 0.035                                             # light closing: bridge orbits' fissures, keep the bone forms
mod('DISPLACE', direction='NORMAL', strength=D, mid_level=0.0); mod('REMESH', mode='VOXEL', voxel_size=0.010)
mod('SMOOTH', factor=0.5, iterations=3); mod('DISPLACE', direction='NORMAL', strength=-D, mid_level=0.0)
mod('SMOOTH', factor=0.5, iterations=3)
for o in list(bpy.data.objects):
    if o != env: bpy.data.objects.remove(o)
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/anatomy/face_envelope.blend')
print('face envelope verts', len(env.data.vertices))
