"""Envelope_Smooth: a softened muscle body for the low-poly game mesh (Taubin, no shrink)."""
import os, sys, bpy, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(HERE, 'anatomy.blend'))
env = bpy.data.objects['Envelope']
old = bpy.data.objects.get('Envelope_Smooth')
if old: bpy.data.objects.remove(old)
me = env.data.copy(); me.name = 'Envelope_Smooth'
ob = bpy.data.objects.new('Envelope_Smooth', me); bpy.context.scene.collection.objects.link(ob)
P = np.empty(len(me.vertices) * 3); me.vertices.foreach_get('co', P); P = P.reshape(-1, 3)
E = np.empty(len(me.edges) * 2, dtype=np.int64); me.edges.foreach_get('vertices', E); E = E.reshape(-1, 2)
E = np.r_[E, E[:, ::-1]]
cnt = np.bincount(E[:, 0], minlength=len(P)).astype(float)[:, None]
def step(P, f):
    acc = np.zeros_like(P); np.add.at(acc, E[:, 0], P[E[:, 1]])
    return P + f * (acc / cnt - P)
ITERS = int(os.environ.get('GK_SOFTEN', '45'))
for _ in range(ITERS):
    P = step(P, 0.5); P = step(P, -0.53)
me.vertices.foreach_set('co', P.astype(np.float32).ravel()); me.update()
ob.hide_render = True
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(HERE, 'anatomy.blend'))
print('Envelope_Smooth written,', ITERS, 'Taubin iterations')
