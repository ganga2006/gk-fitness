import bpy, math, sys, os
from mathutils import Vector
args = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
anat = args[0] if args else '/home/claude/mh/anatomy/chest_anatomy.blend'
tag = args[1] if len(args) > 1 else 'anat'
bodyfile = args[2] if len(args) > 2 else '/home/claude/mh/mh_shaped.blend'
OUT = '/home/claude/mh/anatomy'
bpy.ops.wm.open_mainfile(filepath=anat)
with bpy.data.libraries.load(bodyfile) as (src, dst):
    dst.objects = [n for n in src.objects if n == 'Body']
body = dst.objects[0]; bpy.context.scene.collection.objects.link(body)
sc = bpy.context.scene
sc.render.engine = 'BLENDER_WORKBENCH'; sc.render.resolution_x, sc.render.resolution_y = 560, 640
sc.render.film_transparent = False
sh = sc.display.shading; sh.light = 'STUDIO'; sh.color_type = 'OBJECT'
sh.show_cavity = True; sh.cavity_type = 'BOTH'; sh.show_shadows = False
w = bpy.data.worlds.new('W'); sc.world = w; w.color = (0.06, 0.07, 0.09)
for o in bpy.data.objects:
    if o.type != 'MESH': continue
    o.color = (0.93, 0.89, 0.80, 1) if o.name.startswith('bone') else \
              (0.72, 0.12, 0.10, 1) if o.name.startswith('mus') else (0.80, 0.66, 0.57, 1)
cd = bpy.data.cameras.new('C'); cd.lens = 70
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
def shoot(n, az, t=Vector((0.3, 0, 8.6)), dist=15, lift=0.6):
    a = math.radians(az)
    cam.location = Vector((math.cos(a)*dist + t.x, math.sin(a)*dist, t.z + lift))
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = os.path.join(OUT, f'{n}.png'); bpy.ops.render.render(write_still=True)
for vis_body, suffix in ((False, 'in'), (True, 'skin')):
    body.hide_render = not vis_body
    for o in bpy.data.objects:
        if o.type == 'MESH' and o != body: o.hide_render = vis_body
    for nm, az in (('front', 0), ('tq', -38), ('side', -90)):
        shoot(f'{tag}_{suffix}_{nm}', az)
