import bpy
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/anatomy/body_anatomy.blend')
skip = ('platysma',)
obs = [o for o in bpy.data.objects if o.type == 'MESH' and not any(k in o.name for k in skip)
       and not o.name.startswith('bone_skull')]
for o in bpy.data.objects: o.select_set(o in obs)
bpy.context.view_layer.objects.active = obs[0]
dups = []
bpy.ops.object.duplicate(); bpy.ops.object.join()
env = bpy.context.active_object; env.name = 'Envelope'
def mod(t, **kw):
    m = env.modifiers.new(t.lower(), t)
    for k, v in kw.items(): setattr(m, k, v)
    bpy.ops.object.modifier_apply(modifier=m.name)
mod('REMESH', mode='VOXEL', voxel_size=0.024)
mod('SMOOTH', factor=0.6, iterations=4)
det = env.copy(); det.data = env.data.copy(); det.name = 'EnvelopeDetail'
bpy.context.scene.collection.objects.link(det)
D = 0.06
mod('DISPLACE', direction='NORMAL', strength=D, mid_level=0.0)
mod('REMESH', mode='VOXEL', voxel_size=0.024)
mod('SMOOTH', factor=0.5, iterations=4)
mod('DISPLACE', direction='NORMAL', strength=-D, mid_level=0.0)
mod('SMOOTH', factor=0.5, iterations=4)
for o in list(bpy.data.objects):
    if o not in (env, det): bpy.data.objects.remove(o)
print('envelope verts', len(env.data.vertices))
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/anatomy/body_envelope.blend')
