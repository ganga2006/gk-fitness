"""Joint centres and bony landmarks of the BodyParts3D male, in his own frame (mm)."""
import sys, json, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
from bp3d_io import read_stl
from parts import NAMES

def sphere_fit(P):
    A = np.c_[2 * P, np.ones(len(P))]; b = (P ** 2).sum(1)
    c, *_ = np.linalg.lstsq(A, b, rcond=None)
    return c[:3], float(np.sqrt(c[3] + c[:3] @ c[:3]))

def robust_sphere(P):
    c, r = sphere_fit(P)
    for _ in range(5):
        d = np.abs(np.linalg.norm(P - c, axis=1) - r)
        P = P[d < np.percentile(d, 70)]; c, r = sphere_fit(P)
    return c, r

def fid(name):
    for k, v in NAMES.items():
        if v == name: return k
    raise KeyError(name)

def end_centre(name, which, depth):
    v, _ = read_stl(fid(name)); z = v[:, 2]
    sel = v[z < z.min() + depth] if which == 'low' else v[z > z.max() - depth]
    return sel.mean(0)

def compute():
    L = {}
    for side, s in (('l', 'left'), ('r', 'right')):
        med = -1 if side == 'l' else 1          # medial is toward x = 0
        v, _ = read_stl(fid(f'{s} humerus'))
        top = v[v[:, 2] > v[:, 2].max() - 48]; mx = np.median(top[:, 0])
        L[f'{side}-shoulder'] = robust_sphere(top[(top[:, 0] - mx) * med > -5])[0]
        L[f'{side}-elbow'] = v[v[:, 2] < v[:, 2].min() + 16].mean(0)
        L[f'{side}-wrist'] = end_centre(f'{s} radius', 'low', 10)
        mc3 = end_centre(f'{s} third metacarpal bone', 'low', 8)
        L[f'{side}-hand-end'] = mc3
        L[f'{side}-thumb-end'] = end_centre(f'{s} first metacarpal bone', 'low', 8)
        v, _ = read_stl(fid(f'{s} femur'))
        top = v[v[:, 2] > v[:, 2].max() - 50]; mx = np.median(top[:, 0])
        L[f'{side}-hip'] = robust_sphere(top[(top[:, 0] - mx) * med > -5])[0]
        L[f'{side}-knee'] = v[v[:, 2] < v[:, 2].min() + 18].mean(0)
        L[f'{side}-ankle'] = read_stl(fid(f'{s} talus'))[0].mean(0)
        mt2 = read_stl(fid(f'{s} second metatarsal bone'))[0]
        head = mt2[mt2[:, 1] < mt2[:, 1].min() + 8]          # anterior = -y: metatarsal head
        L[f'{side}-foot-end'] = head.mean(0)
        cl, _ = read_stl(fid(f'{s} clavicle'))
        ax = np.abs(cl[:, 0])
        L[f'{side}-sc'] = cl[ax < ax.min() + 8].mean(0)
        L[f'{side}-ac'] = cl[ax > ax.max() - 8].mean(0)
    man, _ = read_stl(fid('manubrium'))
    mid = man[np.abs(man[:, 0]) < 6]
    L['jugular'] = mid[mid[:, 2].argmax()]
    stb, _ = read_stl(fid('body of sternum'))
    L['xiphisternal'] = stb[stb[:, 2] < stb[:, 2].min() + 4].mean(0)
    for nm, key in (('seventh cervical vertebra', 'C7'), ('first thoracic vertebra', 'T1'),
                    ('twelfth thoracic vertebra', 'T12'), ('fifth lumbar vertebra', 'L5'),
                    ('atlas', 'C1')):
        v, _ = read_stl(fid(nm)); L[key] = v.mean(0)
    sk, _ = read_stl('FMA7163')
    head = sk[sk[:, 2] > 1450]
    L['skin-top'] = head[head[:, 2].argmax()]
    L['skin-head-bbox'] = np.r_[head.min(0), head.max(0)]
    return {k: np.asarray(v, float).tolist() for k, v in L.items()}

if __name__ == '__main__':
    L = compute()
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bp3d_landmarks.json')
    json.dump(L, open(out, 'w'), indent=1)
    for k, v in L.items():
        print(f'{k:16s}', np.round(v, 1))
