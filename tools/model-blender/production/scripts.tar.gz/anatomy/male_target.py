"""Converts a CC0 MakeHuman target into a per-vertex offset field for the subdivided body."""
import bpy, numpy as np, sys, os
TGT = sys.argv[sys.argv.index('--') + 1]; OUTF = sys.argv[sys.argv.index('--') + 2]
OBJ = '/home/claude/mh/base.obj'
verts, faces, group = [], [], None
for line in open(OBJ):
    if line.startswith('v '): verts.append([float(x) for x in line.split()[1:4]])
    elif line.startswith('g '): group = line[2:].strip()
    elif line.startswith('f ') and group == 'body': faces.append([int(t.split('/')[0]) - 1 for t in line.split()[1:]])
verts = np.array(verts); used = sorted({i for f in faces for i in f}); remap = {v: n for n, v in enumerate(used)}
s = 12.0 / (verts[used, 1].max() - verts[used, 1].min())
D = np.zeros((len(used), 3))
for line in open(TGT):
    if line.startswith('#') or not line.strip(): continue
    p = line.split(); i = int(p[0])
    if i in remap:
        dx, dy, dz = map(float, p[1:4]); D[remap[i]] = (dz * s, dx * s, dy * s)   # (x,y,z)_mh -> (z,x,y)_app
me = bpy.data.meshes.new('d'); me.from_pydata(D.tolist(), [], [[remap[i] for i in f] for f in faces]); me.update()
ob = bpy.data.objects.new('d', me); bpy.context.scene.collection.objects.link(ob)
bpy.context.view_layer.objects.active = ob
m = ob.modifiers.new('s', 'SUBSURF'); m.levels = 1
bpy.ops.object.modifier_apply(modifier='s')
out = np.array([v.co for v in ob.data.vertices])
np.save(OUTF, out); print('offset field', out.shape, 'max', np.abs(out).max().round(4))
