"""Collects every BodyParts3D bone under 'skeletal system' and groups it by body segment."""
import os, re
from collections import defaultdict
D = '/home/claude/kevin-mattheus-moerman/bodyparts3d/assets/BodyParts3D_data'
NAMES = {}
for line in open(os.path.join(D, 'parts_list_e.txt')):
    p = line.rstrip('\n').split('\t')
    if len(p) >= 2 and not p[0].startswith('"'):
        NAMES[p[0]] = p[1]
KIDS = defaultdict(set)
for fn in ('conventional_part_of.txt', 'composite_parts.txt'):
    for line in open(os.path.join(D, fn)):
        p = line.rstrip('\n').split('\t')
        if len(p) >= 4 and not p[0].startswith(('"', 'composite')):
            KIDS[p[0]].add(p[2]); NAMES.setdefault(p[2], p[3])

def has_stl(fid):
    return os.path.exists(os.path.join(D, 'stl', f'{fid}.stl'))

def leaves(root):
    out, seen, stack = set(), set(), [root]
    while stack:
        n = stack.pop()
        if n in seen: continue
        seen.add(n)
        if has_stl(n): out.add(n)
        stack.extend(KIDS.get(n, ()))
    return out

SKULL = r'frontal bone|parietal bone|occipital bone|temporal bone|sphenoid|ethmoid|maxilla|mandible|zygomatic bone|nasal bone|lacrimal bone|palatine bone|vomer|inferior nasal concha'
RULES = [   # (group, regex) — first match wins; side is appended for paired bones
    ('skip',     r'tooth|teeth|disk|disc|ligament|meniscus|cartilage of|auditory ossicle|malleus|incus|stapes'),
    ('skull',    SKULL),
    ('neck',     r'atlas|axis|cervical vertebra|hyoid'),
    ('thorax',   r'thoracic vertebra|rib\b|costal cartilage|manubrium|sternum|xiphoid'),
    ('lumbar',   r'lumbar vertebra'),
    ('pelvis',   r'hip bone|sacrum|coccyx'),
    ('girdle',   r'clavicle|scapula'),
    ('humerus',  r'humerus'),
    ('forearm',  r'radius|ulna'),
    ('hand',     r'scaphoid|lunate|triquetral|pisiform|trapezium|trapezoid|capitate|hamate|metacarpal|finger|thumb|sesamoid bone of (left|right) hand'),
    ('femur',    r'femur|patella'),
    ('shin',     r'tibia|fibula'),
    ('foot',     r'talus|calcaneus|navicular|cuboid|cuneiform|metatarsal|toe|sesamoid bone of (left|right) foot'),
]

def classify(fid):
    nm = NAMES.get(fid, '').lower()
    for g, rx in RULES:
        if re.search(rx, nm):
            if g == 'skip': return None
            side = 'L' if 'left' in nm else 'R' if 'right' in nm else ''
            paired = g in ('girdle', 'humerus', 'forearm', 'hand', 'femur', 'shin', 'foot')
            return (g + '_' + side) if paired and side else g
    return 'other'

def skeleton_parts():
    groups = defaultdict(list)
    for fid in sorted(leaves('FMA23881')):
        g = classify(fid)
        if g: groups[g].append(fid)
    return groups

if __name__ == '__main__':
    g = skeleton_parts()
    for k in sorted(g):
        print(f'{k:10s} {len(g[k]):3d}  e.g. ' + ', '.join(NAMES[f] for f in g[k][:4]))
    if 'other' in g:
        print('OTHER:', [NAMES[f] for f in g['other']])
