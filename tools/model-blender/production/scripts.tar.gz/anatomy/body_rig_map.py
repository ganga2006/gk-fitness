"""
Maps any BodyParts3D point (mm, scan frame) into the trainer's posed frame.

Trunk  : measured warp (uniform scale, ribcage 10% wider, pelvis fitted to the
         rig's hip joints, shoulder girdle nudged onto the rig's shoulder joints)
Limbs  : one similarity transform per bone segment, joint-to-joint
Blend  : capsule-distance weights, so muscles crossing a joint stretch across it
"""
import json, numpy as np, sys
sys.path.insert(0, '/home/claude/mh/anatomy')
from bp3d_io import read_stl
F = json.load(open('/home/claude/mh/anatomy/fit.json')); S, Z0, X0 = F['s'], F['z0'], F['x0']
J = {k: np.array(v) for k, v in json.load(open('/home/claude/mh/joints.json')).items()}
c = lambda P: np.c_[-P[:, 1], P[:, 0], P[:, 2]]          # scan axes -> trainer axes (still mm)
sm = lambda t: (lambda u: u*u*(3-2*u))(np.clip(t, 0, 1))

def mean_end(fid, top, mm=15):
    P = c(read_stl(fid)[0]); z = P[:, 2]
    return P[z > z.max()-mm].mean(0) if top else P[z < z.min()+mm].mean(0)
def sphere(P):
    A = np.c_[2*P, np.ones(len(P))]; b = (P**2).sum(1); x = np.linalg.lstsq(A, b, rcond=None)[0]; return x[:3]

BP = {}
for s, sd in ((1, 'l'), (-1, 'r')):
    hum = 'FMA23131' if s > 0 else 'FMA23130'; rad = 'FMA23465' if s > 0 else 'FMA23464'; uln = 'FMA23468' if s > 0 else 'FMA23467'
    fem = 'FMA24475' if s > 0 else 'FMA24474'; tib = 'FMA24478' if s > 0 else 'FMA24477'; tal = 'FMA24483' if s > 0 else 'FMA24482'
    BP[f'sho_{sd}'] = c(np.array([[161.3*s, -71.9, 1325.2]]))[0]
    BP[f'elb_{sd}'] = mean_end(hum, False, 18)
    BP[f'wri_{sd}'] = (mean_end(rad, False, 10) + mean_end(uln, False, 10)) / 2
    BP[f'rad_{sd}'] = mean_end(rad, False, 10); BP[f'uln_{sd}'] = mean_end(uln, False, 10)
    BP[f'hip_{sd}'] = c(np.array([[80.9*s, -93.0, 820.0]]))[0]
    BP[f'kne_{sd}'] = (mean_end(fem, False, 12) + mean_end(tib, True, 12)) / 2
    BP[f'ank_{sd}'] = c(read_stl(tal)[0]).mean(0)
from parts import NAMES
def fid_of(name):
    for k, v in NAMES.items():
        if v == name: return k
for sd, side in (('l', 'left'), ('r', 'right')):
    BP[f'mcp_{sd}'] = mean_end(fid_of(f'{side} third metacarpal bone'), False, 8)
    P = c(read_stl(fid_of(f'{side} second metatarsal bone'))[0]); BP[f'mtp_{sd}'] = P[P[:, 0].argmax()]
BP['c7'] = c(np.array([[-2.1, -67.9, 1392.6]]))[0]; BP['l5'] = c(np.array([[0.1, -66.6, 941.8]]))[0]
BP['skull_top'] = np.array([0.0, 0.0, 0.0])
P = c(read_stl(fid_of('frontal bone'))[0]); BP['skull_top'] = np.array([P[:,0].mean(), 0.0, P[:, 2].max()])

def ky(zmm):                               # lateral scale: thorax 1.10 -> pelvis fitted to hip joints
    kp = abs(J['l-upper-leg'][1]) / (80.9 * S)
    return 1.10 + (kp - 1.10) * sm((1000 - zmm) / 100)
def trunk_raw(Q):
    return np.c_[X0 + Q[:, 0]*S, Q[:, 1]*S*ky(Q[:, 2]), Z0 + Q[:, 2]*S]
SH = {}
for sd in ('l', 'r'):
    SH[sd] = J[f'{sd}-shoulder'] - trunk_raw(BP[f'sho_{sd}'][None])[0]
def trunk(Q):
    out = trunk_raw(Q)
    for sd in ('l', 'r'):                  # shoulder girdle onto the rig's shoulder joint
        d = np.linalg.norm(Q - BP[f'sho_{sd}'], axis=1)
        out += np.outer(sm((170 - d) / 110), SH[sd])
    return out

def rot_between(a, b):
    a = a/np.linalg.norm(a); b = b/np.linalg.norm(b); v = np.cross(a, b); cth = a@b
    if np.linalg.norm(v) < 1e-9: return np.eye(3)
    K = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + K + K@K * (1/(1+cth))
def roll_fix(R, axis, sec_bp, sec):
    """extra twist about the bone axis so a secondary direction also lines up"""
    a = axis/np.linalg.norm(axis); s1 = R@sec_bp; s1 -= a*(s1@a); s2 = sec - a*(sec@a)
    if np.linalg.norm(s1) < 1e-6 or np.linalg.norm(s2) < 1e-6: return R
    s1 /= np.linalg.norm(s1); s2 /= np.linalg.norm(s2)
    ang = np.arctan2(np.cross(s1, s2)@a, s1@s2)
    K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    return (np.eye(3) + np.sin(ang)*K + (1-np.cos(ang))*K@K) @ R

SEG = {}   # name -> (A_bp, B_bp, A, B, R, k)
TWIST = {}  # forearm: pronation grows from elbow (0) to wrist (full), like the real radius
def seg(name, A_bp, B_bp, A, B, sec_bp=None, sec=None, twist=False):
    R0 = rot_between(B_bp - A_bp, B - A)
    R = roll_fix(R0, B - A, sec_bp, sec) if sec_bp is not None else R0
    k = np.linalg.norm(B - A) / np.linalg.norm(B_bp - A_bp)
    SEG[name] = (A_bp, B_bp, A, B, R, k)
    if twist:
        Rr = R @ R0.T; a = (B - A) / np.linalg.norm(B - A)
        ang = np.arctan2((np.array([Rr[2,1]-Rr[1,2], Rr[0,2]-Rr[2,0], Rr[1,0]-Rr[0,1]])) @ a, np.trace(Rr) - 1)
        TWIST[name] = (R0, ang, a)
for sd in ('l', 'r'):
    seg(f'upperarm_{sd}', BP[f'sho_{sd}'], BP[f'elb_{sd}'], J[f'{sd}-shoulder'], J[f'{sd}-elbow'])
    seg(f'forearm_{sd}', BP[f'elb_{sd}'], BP[f'wri_{sd}'], J[f'{sd}-elbow'], J[f'{sd}-hand'],
        BP[f'rad_{sd}'] - BP[f'uln_{sd}'], J[f'{sd}-finger-1-1'] - J[f'{sd}-finger-5-1'], twist=True)
    seg(f'hand_{sd}', BP[f'wri_{sd}'], BP[f'mcp_{sd}'], J[f'{sd}-hand'], J[f'{sd}-finger-3-1'],
        BP[f'rad_{sd}'] - BP[f'uln_{sd}'], J[f'{sd}-finger-1-1'] - J[f'{sd}-finger-5-1'])
    seg(f'thigh_{sd}', BP[f'hip_{sd}'], BP[f'kne_{sd}'], J[f'{sd}-upper-leg'], J[f'{sd}-knee'], np.array([1., 0, 0]), np.array([1., 0, 0]))
    seg(f'shin_{sd}', BP[f'kne_{sd}'], BP[f'ank_{sd}'], J[f'{sd}-knee'], J[f'{sd}-ankle'], np.array([1., 0, 0]), np.array([1., 0, 0]))
    seg(f'foot_{sd}', BP[f'ank_{sd}'], BP[f'mtp_{sd}'], J[f'{sd}-ankle'], J[f'{sd}-toe-2-1'], np.array([0, 0, 1.]), np.array([0, 0, 1.]))
head_top = np.array([J['head'][0], 0, 11.985])
seg('head', BP['c7'], BP['skull_top'], trunk(BP['c7'][None])[0], head_top)

def axis_rot(a, ang):
    K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    return np.eye(3) + np.sin(ang)*K + (1-np.cos(ang))*K@K
def seg_apply(name, Q):
    A_bp, B_bp, A, B, R, k = SEG[name]
    if name not in TWIST:
        return A + (Q - A_bp) @ R.T * k
    R0, ang, a = TWIST[name]
    ab = B_bp - A_bp; t = np.clip(((Q - A_bp) @ ab) / (ab @ ab), 0, 1)
    base = (Q - A_bp) @ R0.T * k
    out = np.empty_like(base)
    for i, tt in enumerate(np.round(t, 2)):      # quantised: few distinct rotations
        pass
    for tt in np.unique(np.round(t, 2)):
        m = np.round(t, 2) == tt
        out[m] = base[m] @ axis_rot(a, ang * tt).T
    return A + out
def capsule(Q, A, B):
    ab = B - A; t = np.clip(((Q - A) @ ab) / (ab @ ab), 0, 1)
    return np.linalg.norm(Q - (A + np.outer(t, ab)), axis=1)

def map_points(P_scan, only=None):
    """scan-frame mm -> trainer frame. `only` limits which segments may claim points."""
    Q = c(P_scan)
    names = ['trunk'] + list(SEG)
    if only: names = [n for n in names if n in only]
    D, X = [], []
    for n in names:
        if n == 'trunk':
            d = np.maximum(capsule(Q, BP['l5'] - [0, 0, 60], BP['c7']) - 95, 0); x = trunk(Q)
        else:
            A_bp, B_bp = SEG[n][0], SEG[n][1]
            d = capsule(Q, A_bp, B_bp) - (55 if n == 'head' else 0); d = np.maximum(d, 0); x = seg_apply(n, Q)
        D.append(d); X.append(x)
    D = np.array(D); X = np.array(X)
    W = 1.0 / (D + 8.0) ** 6
    W /= W.sum(0)
    return np.einsum('ij,ijk->jk', W, X)
