"""Lip regions from MakeHuman's own lip morphs (topology-exact) -> per-vertex masks on the subdivided body."""
import bpy, numpy as np
SRC = '/tmp/claude-0/-home-claude/e6b57e36-289f-59ea-995f-25b1be937a96/scratchpad/mht'
verts, faces, group = [], [], None
for line in open('/home/claude/mh/base.obj'):
    if line.startswith('v '): verts.append(1)
    elif line.startswith('g '): group = line[2:].strip()
    elif line.startswith('f ') and group == 'body': faces.append([int(t.split('/')[0]) - 1 for t in line.split()[1:]])
used = sorted({i for f in faces for i in f}); remap = {v: n for n, v in enumerate(used)}
M = np.zeros((len(used), 3))
for col, name in ((0, 'mouth_mouth-upperlip-volume-incr'), (1, 'mouth_mouth-lowerlip-volume-incr')):
    for line in open(f'{SRC}/{name}.target'):
        if line.startswith('#') or not line.strip(): continue
        p = line.split(); i = int(p[0])
        if i in remap: M[remap[i], col] = np.linalg.norm([float(x) for x in p[1:4]])
    M[:, col] /= M[:, col].max()
me = bpy.data.meshes.new('m'); me.from_pydata(M.tolist(), [], [[remap[i] for i in f] for f in faces]); me.update()
ob = bpy.data.objects.new('m', me); bpy.context.scene.collection.objects.link(ob); bpy.context.view_layer.objects.active = ob
s = ob.modifiers.new('s', 'SUBSURF'); s.levels = 1; bpy.ops.object.modifier_apply(modifier='s')
out = np.array([v.co for v in ob.data.vertices])[:, :2]
np.save('/home/claude/mh/anatomy/lip_masks.npy', np.clip(out, 0, 1)); print('lip masks', out.shape, (out[:,0] > 0.3).sum(), (out[:,1] > 0.3).sum())
