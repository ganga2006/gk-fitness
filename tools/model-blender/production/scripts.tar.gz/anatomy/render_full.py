import bpy, os, math, sys
from mathutils import Vector
A = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(A, 'muscles.blend'))
sc = bpy.context.scene
sc.render.engine = 'BLENDER_WORKBENCH'
sh = sc.display.shading
sh.light = 'STUDIO'; sh.color_type = 'OBJECT'; sh.show_cavity = True; sh.cavity_type = 'BOTH'; sh.show_shadows = False
w = bpy.data.worlds.new('W'); sc.world = w; w.color = (0.06, 0.07, 0.09)
for o in bpy.data.objects:
    if o.type != 'MESH': continue
    o.color = (0.90, 0.85, 0.72, 1) if o.name.startswith('Skel') else (0.66, 0.20, 0.16, 1) if o.name.startswith('M_') else (0.74, 0.62, 0.55, 1)
cd = bpy.data.cameras.new('C'); cd.type = 'ORTHO'
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
def shoot(name, az, env, z=6.0, scale=12.6, w=460, h=900):
    cd.ortho_scale = scale; sc.render.resolution_x, sc.render.resolution_y = w, h
    for o in bpy.data.objects:
        if o.type == 'MESH':
            o.hide_render = (o.name != 'Envelope') if env else (o.name == 'Envelope' or o.name.startswith('Fill'))
    a = math.radians(az); t = Vector((0.2, 0, z))
    cam.location = t + Vector((math.cos(a), math.sin(a), 0.05)) * 30
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = os.path.join(A, f'f_{name}.png'); bpy.ops.render.render(write_still=True)
for nm, az in (('front', 0), ('side', 90), ('back', 180)):
    shoot('m_' + nm, az, False); shoot('e_' + nm, az, True)
print('ok')
