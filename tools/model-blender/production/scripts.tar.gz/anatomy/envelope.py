"""Fuse the fitted bones + muscles into one smooth surface the skin can lie on."""
import bpy
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/anatomy/chest_anatomy.blend')
keep = [o for o in bpy.data.objects if o.type == 'MESH' and
        (o.name.startswith('mus_') or any(k in o.name for k in ('ribs', 'costal', 'sternum', 'clavicle')))]
dups = []
for o in keep:
    d = o.copy(); d.data = o.data.copy(); bpy.context.scene.collection.objects.link(d); dups.append(d)
bpy.ops.object.select_all(action='DESELECT')
for d in dups: d.select_set(True)
bpy.context.view_layer.objects.active = dups[0]
bpy.ops.object.join()
env = bpy.context.active_object; env.name = 'Envelope'
r = env.modifiers.new('vox', 'REMESH'); r.mode = 'VOXEL'; r.voxel_size = 0.022; r.use_smooth_shade = True
bpy.ops.object.modifier_apply(modifier='vox')
# morphological closing (grow, re-fuse, shrink): fills the undercut beneath the
# pec border and the cracks between muscles, the way skin and fascia drape
D = 0.06
for step, amt in (('grow', D), ('shrink', -D)):
    dp = env.modifiers.new(step, 'DISPLACE'); dp.direction = 'NORMAL'; dp.strength = amt; dp.mid_level = 0.0
    bpy.ops.object.modifier_apply(modifier=step)
    if step == 'grow':
        r = env.modifiers.new('vox2', 'REMESH'); r.mode = 'VOXEL'; r.voxel_size = 0.022
        bpy.ops.object.modifier_apply(modifier='vox2')
    sm = env.modifiers.new('sm', 'SMOOTH'); sm.factor = 0.5; sm.iterations = 4
    bpy.ops.object.modifier_apply(modifier='sm')
for o in list(bpy.data.objects):
    if o != env: bpy.data.objects.remove(o)
print('envelope verts', len(env.data.vertices))
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/anatomy/chest_envelope.blend')
