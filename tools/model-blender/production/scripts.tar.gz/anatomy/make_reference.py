import bpy
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/anatomy/body_anatomy.blend')
with bpy.data.libraries.load('/home/claude/mh/anatomy/face_anatomy.blend') as (s, d):
    d.collections = [c for c in s.collections if c in ('Skull', 'FaceMuscles')]
for c in d.collections:
    if c: bpy.context.scene.collection.children.link(c)
def mat(n, rgb):
    m = bpy.data.materials.new(n); m.use_nodes = True; m.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (*rgb, 1); return m
mb, mm = mat('bone', (0.86, 0.82, 0.72)), mat('muscle', (0.55, 0.08, 0.07))
for o in bpy.data.objects:
    if o.type != 'MESH': continue
    o.data.materials.clear(); o.data.materials.append(mb if o.name.startswith(('bone', 'skull', 'eyeball')) else mm)
# skull from the body warp duplicates the fitted skull: hide the body-warp one
for o in bpy.data.objects:
    if o.name.startswith('bone_skull'): o.hide_set(True); o.hide_render = True
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/delivery/GKFitness_Trainer_Anatomy_Reference.blend', compress=True)
print('reference saved', len(bpy.data.objects), 'objects')
