import sys; sys.path.insert(0, '/home/claude/mh/anatomy')
import numpy as np, bpy, json
from bp3d_io import read_stl
F = json.load(open('/home/claude/mh/anatomy/fit.json')); s, z0 = F['s'], F['z0']
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/mh_shaped.blend')
body = bpy.data.objects['Body']
V = np.array([body.matrix_world @ v.co for v in body.data.vertices])
ribs = np.vstack([read_stl(f)[0] for f in ['FMA8256','FMA8202','FMA8148','FMA8093','FMA8310','FMA8391','FMA8039','FMA8012']])
for zl in np.arange(7.8, 9.5, 0.2):
    m = V[np.abs(V[:,2]-zl) < 0.08]; m = m[(m[:,1] > 0)]
    # torso only: points near the torso centre line in x, take the largest y gap-free run
    ys = np.sort(m[:,1]); gaps = np.where(np.diff(ys) > 0.12)[0]
    torso_hw = ys[gaps[0]] if len(gaps) else ys[-1]
    zb = (zl - z0)/s; rb = ribs[np.abs(ribs[:,2]-zb) < 4]
    rib_hw = rb[:,0].max()*s if len(rb) else float('nan')
    print(f'z {zl:.1f}  MH torso halfwidth {torso_hw:.3f}  ribcage halfwidth(raw) {rib_hw:.3f}  ratio {torso_hw/rib_hw:.3f}')
