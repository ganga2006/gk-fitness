"""
GK Fitness — step 2: muscles on the fitted skeleton, then the envelope the skin will wrap.

Each BodyParts3D muscle is carried by the bones it attaches to: a vertex near
the ribs moves with the trunk, one near the humerus moves with the arm, and the
fibres between blend smoothly (inverse-square distance to each bone). That is
what lets the real pectoralis major follow the trainer's arm angle while its
breastbone and collarbone origins stay put.

The muscles are then thickened from their deep side (the side resting on bone)
for an athletic build, and unioned with the bones into one envelope: the
surface the skin lies on.
"""
import sys, os, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, bpy
from scipy.spatial import cKDTree
from mathutils.bvhtree import BVHTree
from fit import *            # T (segment transforms), W, H, read_stl, make_object, groups, NAMES

A = os.path.dirname(os.path.abspath(__file__))
# name: ({'L': fma, 'R': fma}, bone groups it is carried by, thickness factor)
MUSCLES = {
    'pec_major_clav':  ({'L': 'FMA34691', 'R': 'FMA34690'}, ('trunk', 'girdle', 'humerus'), 1.6),
    'pec_major_stern': ({'L': 'FMA79980', 'R': 'FMA79979'}, ('trunk', 'girdle', 'humerus'), 1.45),
    'pec_major_abd':   ({'L': 'FMA45875', 'R': 'FMA45874'}, ('trunk', 'humerus'), 1.2),
    'pec_minor':       ({'L': 'FMA13376', 'R': 'FMA13375'}, ('trunk', 'girdle'), 1.15),
    'deltoid_ant':     ({'L': 'FMA34681', 'R': 'FMA34680'}, ('girdle', 'humerus'), 1.45),
    'deltoid_lat':     ({'L': 'FMA34683', 'R': 'FMA34682'}, ('girdle', 'humerus'), 1.5),
    'deltoid_post':    ({'L': 'FMA34685', 'R': 'FMA34684'}, ('girdle', 'humerus'), 1.4),
    'serratus_ant':    ({'L': 'FMA13399', 'R': 'FMA13398'}, ('trunk', 'girdle'), 1.35),
    'ext_oblique':     ({'L': 'FMA13337', 'R': 'FMA13336'}, ('trunk',), 1.0),
    'rectus_abd':      ({'L': 'FMA13378', 'R': 'FMA13377'}, ('trunk',), 1.6),
    'lat_dorsi':       ({'L': 'FMA13359', 'R': 'FMA13358'}, ('trunk', 'girdle', 'humerus'), 1.2),
    'trap_desc':       ({'L': 'FMA33587', 'R': 'FMA33586'}, ('neck', 'skull', 'girdle'), 1.5),
    'trap_trans':      ({'L': 'FMA33585', 'R': 'FMA33584'}, ('trunk', 'girdle'), 1.45),
    'trap_asc':        ({'L': 'FMA33583', 'R': 'FMA33581'}, ('trunk', 'girdle'), 1.35),
    'teres_major':     ({'L': 'FMA32552', 'R': 'FMA32551'}, ('girdle', 'humerus'), 1.1),
    'teres_minor':     ({'L': 'FMA32554', 'R': 'FMA32553'}, ('girdle', 'humerus'), 1.05),
    'infraspinatus':   ({'L': 'FMA32548', 'R': 'FMA32547'}, ('girdle', 'humerus'), 1.3),
    'supraspinatus':   ({'L': 'FMA32545', 'R': 'FMA32544'}, ('girdle', 'humerus'), 1.2),
    'rhomboid_major':  ({'L': 'FMA13382', 'R': 'FMA13381'}, ('trunk', 'girdle'), 1.2),
    'rhomboid_minor':  ({'L': 'FMA13384', 'R': 'FMA13383'}, ('trunk', 'girdle'), 1.2),
    'sternocleido':    ({'L': 'FMA13409', 'R': 'FMA13408'}, ('trunk', 'girdle', 'neck', 'skull'), 1.2),
    'iliocostalis_l':  ({'L': 'FMA22741', 'R': 'FMA22740'}, ('trunk',), 1.3),
    'iliocostalis_t':  ({'L': 'FMA22743', 'R': 'FMA22742'}, ('trunk',), 1.3),
    'longissimus_t':   ({'L': 'FMA22753', 'R': 'FMA22751'}, ('trunk',), 1.3),
    'spinalis_t':      ({'L': 'FMA22780', 'R': 'FMA22779'}, ('trunk',), 1.2),
    'biceps_long':     ({'L': 'FMA37687', 'R': 'FMA37686'}, ('girdle', 'humerus', 'forearm'), 1.5),
    'biceps_short':    ({'L': 'FMA37685', 'R': 'FMA37684'}, ('girdle', 'humerus', 'forearm'), 1.5),
    'triceps_long':    ({'L': 'FMA37700', 'R': 'FMA37699'}, ('girdle', 'humerus', 'forearm'), 1.45),
    'triceps_lat':     ({'L': 'FMA37698', 'R': 'FMA37697'}, ('humerus', 'forearm'), 1.45),
    'triceps_med':     ({'L': 'FMA37696', 'R': 'FMA37695'}, ('humerus', 'forearm'), 1.4),
    'brachialis':      ({'L': 'FMA37669', 'R': 'FMA37668'}, ('humerus', 'forearm'), 1.5),
    'coracobrachialis':({'L': 'FMA37666', 'R': 'FMA37665'}, ('girdle', 'humerus'), 1.2),
    # hips and legs
    'glute_max':       ({'L': 'FMA22329', 'R': 'FMA22328'}, ('trunk', 'femur'), 1.25),
    'glute_med':       ({'L': 'FMA22331', 'R': 'FMA22330'}, ('trunk', 'femur'), 1.0),
    'glute_min':       ({'L': 'FMA22333', 'R': 'FMA22332'}, ('trunk', 'femur'), 1.0),
    'tensor_fl':       ({'L': 'FMA22426', 'R': 'FMA22425'}, ('trunk', 'femur'), 1.0),
    'it_tract':        ({'L': 'FMA58777', 'R': 'FMA58776'}, ('trunk', 'femur', 'shin'), 1.0),
    'sartorius':       ({'L': 'FMA22355', 'R': 'FMA22354'}, ('trunk', 'femur', 'shin'), 1.1),
    'rectus_femoris':  ({'L': 'FMA38929', 'R': 'FMA38928'}, ('trunk', 'femur', 'shin'), 1.45),
    'vastus_lat':      ({'L': 'FMA38931', 'R': 'FMA38930'}, ('femur', 'shin'), 1.3),
    'vastus_med':      ({'L': 'FMA38933', 'R': 'FMA38932'}, ('femur', 'shin'), 1.5),
    'vastus_int':      ({'L': 'FMA38935', 'R': 'FMA38934'}, ('femur', 'shin'), 1.3),
    'adductor_long':   ({'L': 'FMA22457', 'R': 'FMA22456'}, ('trunk', 'femur'), 1.2),
    'adductor_brev':   ({'L': 'FMA22454', 'R': 'FMA22452'}, ('trunk', 'femur'), 1.1),
    'adductor_mag':    ({'L': 'FMA22460', 'R': 'FMA22459'}, ('trunk', 'femur'), 1.2),
    'gracilis':        ({'L': 'FMA43884', 'R': 'FMA43883'}, ('trunk', 'femur', 'shin'), 1.1),
    'pectineus':       ({'L': 'FMA22451', 'R': 'FMA22450'}, ('trunk', 'femur'), 1.0),
    'biceps_fem_long': ({'L': 'FMA45889', 'R': 'FMA45888'}, ('trunk', 'femur', 'shin'), 1.35),
    'biceps_fem_short':({'L': 'FMA45892', 'R': 'FMA45891'}, ('femur', 'shin'), 1.2),
    'semitendinosus':  ({'L': 'FMA22359', 'R': 'FMA22358'}, ('trunk', 'femur', 'shin'), 1.3),
    'semimembranosus': ({'L': 'FMA22449', 'R': 'FMA22448'}, ('trunk', 'femur', 'shin'), 1.3),
    'gastroc_med':     ({'L': 'FMA45958', 'R': 'FMA45957'}, ('femur', 'shin', 'foot'), 1.4),
    'gastroc_lat':     ({'L': 'FMA45961', 'R': 'FMA45960'}, ('femur', 'shin', 'foot'), 1.4),
    'soleus':          ({'L': 'FMA22559', 'R': 'FMA22558'}, ('shin', 'foot'), 1.3),
    'tibialis_ant':    ({'L': 'FMA22545', 'R': 'FMA22544'}, ('shin', 'foot'), 1.3),
    'fibularis_long':  ({'L': 'FMA22553', 'R': 'FMA22552'}, ('shin', 'foot'), 1.2),
    'fibularis_brev':  ({'L': 'FMA22555', 'R': 'FMA22554'}, ('shin', 'foot'), 1.1),
    'ext_dig_long':    ({'L': 'FMA22549', 'R': 'FMA22548'}, ('shin', 'foot'), 1.15),
    'flex_dig_long':   ({'L': 'FMA65017', 'R': 'FMA65016'}, ('shin', 'foot'), 1.0),
    'tibialis_post':   ({'L': 'FMA65019', 'R': 'FMA65018'}, ('shin', 'foot'), 1.0),
    'popliteus':       ({'L': 'FMA22592', 'R': 'FMA22591'}, ('femur', 'shin'), 1.0),
    'quadratus_lumb':  ({'L': 'FMA22349', 'R': 'FMA22348'}, ('trunk',), 1.0),
    'multifidus':      ({'L': 'FMA22879', 'R': 'FMA22878'}, ('trunk',), 1.2),
}
CHEST = {'pec_major_clav', 'pec_major_stern', 'pec_major_abd'}

# ── bone point clouds (BodyParts3D space) for the attachment weights ─
def cloud(fids, n=25000):
    P = np.vstack([read_stl(f)[0] for f in fids])
    if len(P) > n:
        P = P[np.random.default_rng(0).choice(len(P), n, replace=False)]
    return cKDTree(P)
TREES = {'trunk': cloud(groups['thorax'] + groups['lumbar'] + groups['pelvis']),
         'neck': cloud(groups['neck']), 'skull': cloud(groups['skull'])}
for s in ('L', 'R'):
    for g in ('girdle', 'humerus', 'forearm', 'femur', 'shin', 'foot'):
        TREES[f'{g}_{s}'] = cloud(groups[f'{g}_{s}'])
XFORM = lambda g, s: {'trunk': W, 'neck': T['neck'], 'skull': H}.get(g) or T[f'{g}_{s}']

def carry(P, carriers, s):
    """Move muscle points with the bones they attach to (inverse-square blend)."""
    if len(carriers) == 1:
        return XFORM(carriers[0], s)(P)
    keys = [g if g in ('trunk', 'neck', 'skull') else f'{g}_{s}' for g in carriers]
    d = np.stack([TREES[k].query(P)[0] for k in keys], 1) + 2.0
    w = 1.0 / d ** 2.5; w /= w.sum(1, keepdims=True)
    out = np.zeros((len(P), 3))
    for i, g in enumerate(carriers):
        out += w[:, i:i + 1] * XFORM(g, s)(P)
    return out

def decimated(name, v, f, target=14000):
    ob = make_object(name, v, f)
    if len(f) > target * 2:
        m = ob.modifiers.new('d', 'DECIMATE'); m.ratio = (target * 2) / len(f)
        dg = bpy.context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
        old = ob.data; ob.modifiers.clear(); ob.data = me; bpy.data.meshes.remove(old)
    return ob

# ── skeleton BVH (trainer space) for deep/superficial classification ─
ONLY = [x for x in os.environ.get('GK_ONLY', '').split(',') if x]
prev = os.path.join(A, 'muscles.blend')
bpy.ops.wm.open_mainfile(filepath=prev if (ONLY and os.path.exists(prev)) else os.path.join(A, 'skeleton.blend'))
skel = [o for o in bpy.data.objects if o.name.startswith('Skel_')]
bv, bf, off = [], [], 0
for o in skel:
    if o.name.startswith(('Skel_hand', 'Skel_skull')):
        continue
    me = o.data
    co = np.empty(len(me.vertices) * 3); me.vertices.foreach_get('co', co)
    bv.append(co.reshape(-1, 3))
    bf += [[i + off for i in p.vertices] for p in me.polygons]; off += len(me.vertices)
BONE_BVH = BVHTree.FromPolygons([tuple(x) for x in np.vstack(bv)], bf)

from scipy.sparse import coo_matrix, diags

def adjacency(me):
    n = len(me.vertices)
    e = np.empty(len(me.edges) * 2, dtype=np.int64); me.edges.foreach_get('vertices', e); e = e.reshape(-1, 2)
    A = coo_matrix((np.ones(len(e) * 2), (np.r_[e[:, 0], e[:, 1]], np.r_[e[:, 1], e[:, 0]])), shape=(n, n)).tocsr()
    deg = np.asarray(A.sum(1)).ravel(); deg[deg == 0] = 1
    return diags(1.0 / deg) @ A

def smoothed(L, X, iters, f=0.5):
    for _ in range(iters):
        X = (1 - f) * X + f * (L @ X)
    return X

def thicken(ob, k):
    """
    Scale muscle thickness by k, growing outward from the side that rests on bone.

    Growth runs along the normals of a heavily smoothed copy of the muscle and
    the growth amount is itself smoothed: BodyParts3D muscles carry fine fibre
    relief, and pushing along those raw normals turned thick muscles lumpy.
    """
    me = ob.data
    n = len(me.vertices)
    co = np.empty(n * 3); me.vertices.foreach_get('co', co); co = co.reshape(-1, 3)
    L = adjacency(me)
    # normals of the smoothed shape
    tmp = me.copy()
    tmp.vertices.foreach_set('co', smoothed(L, co, 25).ravel()); tmp.update()
    nor = np.empty(n * 3); tmp.vertices.foreach_get('normal', nor); nor = nor.reshape(-1, 3)
    bpy.data.meshes.remove(tmp)
    if abs(k - 1) < 1e-3:
        co = smoothed(L, co, 3, 0.3)                     # just soften the fibre relief
        me.vertices.foreach_set('co', co.ravel()); me.update()
        return
    bvh = BVHTree.FromPolygons([tuple(x) for x in co], [tuple(p.vertices) for p in me.polygons])
    amt = np.zeros(n)
    for i in range(n):
        p, d = Vector(co[i]), Vector(nor[i])
        if BONE_BVH.ray_cast(p + d * 0.004, d, 1.2)[0] is not None:
            continue                                     # this side faces bone: it stays
        q, last = p - d * 0.003, None
        for _ in range(4):                               # walk to the far side of the muscle
            hit = bvh.ray_cast(q, -d, 0.6)
            if hit[0] is None:
                break
            last = hit[0]; q = hit[0] - d * 0.003
        if last is not None:
            amt[i] = (k - 1) * min((p - last).length, 0.45)
    amt = smoothed(L, amt, 14)
    co = smoothed(L, co, 3, 0.3) + nor * amt[:, None]
    me.vertices.foreach_set('co', co.ravel()); me.update()

mcoll = bpy.data.collections.get('Muscles') or bpy.data.collections.new('Muscles')
if mcoll.name not in bpy.context.scene.collection.children: bpy.context.scene.collection.children.link(mcoll)
red = bpy.data.materials.get('muscle') or bpy.data.materials.new('muscle'); red.diffuse_color = (0.62, 0.16, 0.13, 1)
pec = bpy.data.materials.get('muscle_chest') or bpy.data.materials.new('muscle_chest'); pec.diffuse_color = (0.80, 0.20, 0.16, 1)
made = []
for name, (ids, carriers, k) in MUSCLES.items():
    if ONLY and name not in ONLY:
        made += [o for o in (bpy.data.objects.get(f'M_{name}_L'), bpy.data.objects.get(f'M_{name}_R')) if o]
        continue
    for s in ('L', 'R'):
        old = bpy.data.objects.get(f'M_{name}_{s}')
        if old: bpy.data.objects.remove(old)
        v, f = read_stl(ids[s])
        ob = decimated(f'M_{name}_{s}', v, f)
        me = ob.data
        co = np.empty(len(me.vertices) * 3); me.vertices.foreach_get('co', co)
        P = carry(co.reshape(-1, 3), carriers, s)
        me.vertices.foreach_set('co', P.ravel()); me.update()
        thicken(ob, k)
        bpy.context.scene.collection.objects.unlink(ob); mcoll.objects.link(ob)
        me.materials.append(pec if name in CHEST else red)
        for p in me.polygons: p.use_smooth = True
        made.append(ob)
    print(f'{name:17s} k={k:.2f}  {len(me.vertices)} verts/side')

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(A, 'muscles.blend'))
print('saved anatomy/muscles.blend')
