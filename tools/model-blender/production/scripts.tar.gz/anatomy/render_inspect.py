import bpy, os, math, sys
from mathutils import Vector
f, job = sys.argv[sys.argv.index('--')+1], int(sys.argv[sys.argv.index('--')+2])
bpy.ops.wm.open_mainfile(filepath=f)
sc = bpy.context.scene
for o in bpy.data.objects:
    if o.type == 'MESH' and o.name not in ('Body', 'Shorts', 'Hair', 'Eyes', 'HairStrands', 'BrowHairs', 'Lashes'): o.hide_render = True
mat = bpy.data.materials.new('clay'); mat.use_nodes = True
b = mat.node_tree.nodes['Principled BSDF']; b.inputs['Base Color'].default_value = (0.62, 0.50, 0.43, 1); b.inputs['Roughness'].default_value = 0.55
body = bpy.data.objects['Body']; body.data.materials.clear(); body.data.materials.append(mat)
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 16; sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = 420, 520
w = bpy.data.worlds.new('W'); w.use_nodes = True; w.node_tree.nodes['Background'].inputs[0].default_value = (0.05,0.06,0.08,1); sc.world = w
def light(n, loc, e, sz):
    d = bpy.data.lights.new(n, 'AREA'); d.energy = e; d.size = sz
    o = bpy.data.objects.new(n, d); o.location = loc
    o.rotation_euler = (Vector((0,0,6)) - Vector(loc)).normalized().to_track_quat('-Z','Y').to_euler(); sc.collection.objects.link(o); return o
def aim(o, pos, t):
    o.location = pos; o.rotation_euler = (t - pos).normalized().to_track_quat('-Z','Y').to_euler()
key = light('key', (9, -6, 14), 7000, 5); fill = light('fill', (9, 9, 6), 1400, 9); rim = light('rim', (-9, -2, 10), 3500, 7)
cd = bpy.data.cameras.new('C'); cd.lens = 85
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
VIEWS = [  # name, azimuth, target(x,y,z), distance, lift
 ('full_front', 0, (0.2,0,6.0), 34, 0), ('full_side', 90, (0.2,0,6.0), 34, 0), ('full_back', 180, (0.2,0,6.0), 34, 0), ('full_tq', -40, (0.2,0,6.0), 34, 0),
 ('head_front', 0, (0.3,0,11.1), 6, 0), ('head_side', 90, (0.3,0,11.1), 6, 0), ('head_tq', -40, (0.3,0,11.1), 6, 0),
 ('neck_shoulder_front', 0, (0.2,0,9.9), 9, 0.3), ('shoulder_side', 90, (0.1,1.0,9.4), 7, 0.3), ('upper_back', 180, (-0.2,0,9.0), 10, 0.4),
 ('abs_front', 0, (0.5,0,7.4), 8, 0.2), ('abs_tq', -40, (0.5,0,7.4), 8, 0.2), ('lower_back_glutes', 180, (-0.3,0,6.6), 9, 0.2),
 ('arm_front', 0, (0.2,1.9,8.6), 8, 0), ('arm_back', 180, (0.0,1.9,8.6), 8, 0), ('arm_side', 90, (0.2,2.0,8.6), 8, 0),
 ('hand_front', 0, (1.0,3.0,7.4), 4.5, 0), ('hand_side', 90, (1.0,3.2,7.4), 4.5, 0),
 ('hips_front', 0, (0.4,0,6.0), 8, 0), ('hips_side', 90, (0.2,0,6.0), 8, 0),
 ('legs_front', 0, (0.2,0,3.4), 14, 0), ('legs_back', 180, (0.0,0,3.4), 14, 0), ('legs_side', 90, (0.2,0,3.4), 14, 0),
 ('knee_calf_side', 90, (0.2,1.1,2.2), 7, 0), ('feet_front', 0, (0.6,0,0.5), 10, 1.0), ('feet_side', 90, (0.4,1.5,0.4), 5, 0.4),
]
for i, (nm, az, t, dist, lift) in enumerate(VIEWS):
    if i % 4 != job: continue
    a = math.radians(az); t = Vector(t)
    cam.location = Vector((t.x + math.cos(a)*dist, t.y + math.sin(a)*dist, t.z + lift))
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z','Y').to_euler()
    R = max(dist, 8.0)   # studio lights follow the camera: key high camera-left, fill right, rim behind
    aim(key,  t + Vector((math.cos(a - 0.75)*R, math.sin(a - 0.75)*R, R*0.75)), t)
    aim(fill, t + Vector((math.cos(a + 0.9)*R, math.sin(a + 0.9)*R, R*0.15)), t)
    aim(rim,  t + Vector((math.cos(a + math.pi - 0.4)*R, math.sin(a + math.pi - 0.4)*R, R*0.6)), t)
    sc.render.filepath = f'/home/claude/mh/inspect/{i:02d}_{nm}.png'; bpy.ops.render.render(write_still=True)
