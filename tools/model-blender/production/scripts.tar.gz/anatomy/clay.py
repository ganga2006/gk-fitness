import bpy, os, math, sys
from mathutils import Vector
f = sys.argv[sys.argv.index('--')+1]; tag = sys.argv[sys.argv.index('--')+2]
bpy.ops.wm.open_mainfile(filepath=f)
sc = bpy.context.scene
for o in bpy.data.objects:
    if o.type == 'MESH' and o.name not in ('Body',): o.hide_render = True
body = bpy.data.objects['Body']
mat = bpy.data.materials.new('clay'); mat.use_nodes = True
b = mat.node_tree.nodes['Principled BSDF']; b.inputs['Base Color'].default_value = (0.62, 0.50, 0.43, 1); b.inputs['Roughness'].default_value = 0.55
body.data.materials.clear(); body.data.materials.append(mat)
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 24; sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = 520, 620
w = bpy.data.worlds.new('W'); w.use_nodes = True; w.node_tree.nodes['Background'].inputs[0].default_value = (0.05,0.06,0.08,1); sc.world = w
def light(n, loc, e, sz):
    d = bpy.data.lights.new(n, 'AREA'); d.energy = e; d.size = sz
    o = bpy.data.objects.new(n, d); o.location = loc
    o.rotation_euler = (Vector((0.4,0,8.8)) - Vector(loc)).normalized().to_track_quat('-Z','Y').to_euler()
    sc.collection.objects.link(o)
light('key', (7, -5, 13.5), 5200, 5); light('fill', (8, 7, 9), 900, 8); light('rim', (-7, 0, 11), 2500, 6)
cd = bpy.data.cameras.new('C'); cd.lens = 85
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
for nm, az in (('front', 0), ('tq', -35), ('side', -88)):
    a = math.radians(az); t = Vector((0.4, 0, 8.75))
    cam.location = Vector((math.cos(a)*12 + 0.4, math.sin(a)*12, t.z + 0.5))
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z','Y').to_euler()
    sc.render.filepath = f'/home/claude/mh/anatomy/{tag}_{nm}.png'; bpy.ops.render.render(write_still=True)
