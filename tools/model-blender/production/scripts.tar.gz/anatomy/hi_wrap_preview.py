"""Preview: subdivide the shaped body twice and wrap the torso onto the full-detail muscle body."""
import os, sys, bpy, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); MH = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import wrap as W, fit
bpy.ops.wm.open_mainfile(filepath=os.path.join(MH, 'mh_shaped.blend'))
body = bpy.data.objects['Body']
m = body.modifiers.new('sub', 'SUBSURF'); m.levels = 2; m.render_levels = 2
dg = bpy.context.evaluated_depsgraph_get()
me = bpy.data.meshes.new_from_object(body.evaluated_get(dg))
hi = bpy.data.objects.new('BodyHigh', me); bpy.context.scene.collection.objects.link(hi)
body.modifiers.clear()
with bpy.data.libraries.load(os.path.join(HERE, 'anatomy.blend')) as (src, dst):
    dst.objects = ['Envelope']
bvh = W.bvh_from_object(dst.objects[0])
co = np.array([v.co[:] for v in me.vertices]); nrm = np.array([v.normal[:] for v in me.vertices])
E = np.array([e.vertices[:] for e in me.edges])
J = {k: np.array(v) for k, v in fit.J.items()}
w = W.torso_mask(co, nrm, J)
co, n = W.wrap(co, nrm, E, bvh, w, W.skin_offset(co), relax=6)
me.vertices.foreach_set('co', co.astype(np.float32).ravel()); me.update()
for p in me.polygons: p.use_smooth = True
print('high-detail verts', len(me.vertices), 'wrapped', n)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(MH, 'mh_hiwrap_preview.blend'))
