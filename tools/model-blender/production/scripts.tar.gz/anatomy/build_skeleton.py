"""
Builds the anatomical skeleton inside the GK Fitness trainer.

Bones come from BodyParts3D (CC BY-SA 2.1 JP, (c) The Database Center for Life
Science). Ribcage, spine and pelvis are warped as one piece; collarbones and
shoulder blades are fitted so the shoulder sockets meet the trainer's arm joints;
each limb bone is placed between the trainer's own joint centres; the skull is
fitted to the head. Output: anatomy/skeleton.blend and anatomy/anatomy_joints.json.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, bpy
from bp3d_io import read_stl, make_object
from parts import skeleton_parts, NAMES
import fit
from fit import J, L, lm, warp_axial, axes, segment, girdle_shift, S

HERE = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.read_factory_settings(use_empty=True)
coll = bpy.data.collections.new('Skeleton'); bpy.context.scene.collection.children.link(coll)

def material(name, rgb, rough=0.55):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color = (*rgb, 1)
    m.use_nodes = True
    b = m.node_tree.nodes.get('Principled BSDF')
    if b:
        b.inputs['Base Color'].default_value = (*rgb, 1)
        b.inputs['Roughness'].default_value = rough
    return m
BONE = material('bone', (0.80, 0.74, 0.60))
CART = material('cartilage', (0.66, 0.74, 0.78), 0.4)

# ── head: fit the skull to the trainer's head (uniform scale) ──────
with bpy.data.libraries.load(os.path.join(fit.MH, 'mh_base.blend')) as (src, dst):
    dst.objects = ['Body']
body = dst.objects[0]
V = np.array([v.co[:] for v in body.data.vertices]) @ np.array(body.matrix_world)[:3, :3].T
head_top = V[:, 2].max()
# chin: lowest height at which the midline profile is still out at the chin
mid = V[np.abs(V[:, 1]) < 0.06]
zs = np.arange(J['neck'][2], J['mouth'][2], 0.01)
def _front(P, z, w, col, sign):
    q = P[np.abs(P[:, 2] - z) < w]
    return (sign * q[:, col]).max() if len(q) else -1e9
front = np.array([_front(mid, z, 0.05, 0, 1) for z in zs])
chin = zs[np.argmax(front > 0.8 * front.max())]
sk_top = L['skin-top'][2]
sk, _ = read_stl('FMA7163')
skm = sk[np.abs(sk[:, 0]) < 5]
zb = np.arange(1380.0, 1520.0, 1.0)
fb = np.array([_front(skm, z, 4.0, 1, -1) for z in zb])
sk_chin = zb[np.argmax(fb > 0.8 * fb.max())]
k_head = (head_top - chin) / (sk_top - sk_chin)              # units per mm
hb = L['skin-head-bbox']; bp_c = axes((hb[:3] + hb[3:]) / 2)[0]
ours_head = V[V[:, 2] > chin]
oc = np.array([(ours_head[:, 0].min() + ours_head[:, 0].max()) / 2, 0.0, head_top])
def skull_xf(Q):
    return oc + (Q - np.array([bp_c[0], bp_c[1], sk_top])) * k_head
print(f'head: chin {chin:.3f} top {head_top:.3f}; reference chin {sk_chin:.0f} top {sk_top:.0f} mm; '
      f'skull scale {k_head / S:.3f} x body scale')

def neck_xf(P):
    z = P[:, 2]
    w = np.clip((z - L['C7'][2]) / (L['C1'][2] - L['C7'][2]), 0, 1)
    w = (w * w * (3 - 2 * w))[:, None]
    return (1 - w) * warp_axial(P) + w * skull_xf(axes(P))

# ── per-group transforms ───────────────────────────────────────────
hip_true = {s: warp_axial(L[f'{s}-hip'])[0] for s in ('l', 'r')}
XF = {'thorax': warp_axial, 'lumbar': warp_axial, 'pelvis': warp_axial,
      'skull': skull_xf, 'neck': neck_xf}
for side, S_ in (('l', 'L'), ('r', 'R')):
    sh = girdle_shift(side)
    sc, ac = L[f'{side}-sc'], L[f'{side}-ac']
    def girdle(P, sh=sh, sc=sc, ac=ac):
        f = np.clip((np.abs(P[:, 0]) - abs(sc[0])) / (abs(ac[0]) - abs(sc[0])), 0, 1)
        return warp_axial(P) + f[:, None] * sh
    def scapula(P, sh=sh):
        return warp_axial(P) + sh
    XF[f'girdle_{S_}'] = (girdle, scapula)
    XF[f'humerus_{S_}'] = segment(lm(f'{side}-shoulder'), lm(f'{side}-elbow'), J[f'{side}-shoulder'], J[f'{side}-elbow'])
    XF[f'forearm_{S_}'] = segment(lm(f'{side}-elbow'), lm(f'{side}-wrist'), J[f'{side}-elbow'], J[f'{side}-hand'])
    XF[f'hand_{S_}'] = segment(lm(f'{side}-wrist'), lm(f'{side}-hand-end'), J[f'{side}-hand'], J[f'{side}-finger-3-1'],
                               lm(f'{side}-thumb-end'), J[f'{side}-finger-1-2'])
    XF[f'femur_{S_}'] = segment(lm(f'{side}-hip'), lm(f'{side}-knee'), hip_true[side], J[f'{side}-knee'])
    XF[f'shin_{S_}'] = segment(lm(f'{side}-knee'), lm(f'{side}-ankle'), J[f'{side}-knee'], J[f'{side}-ankle'])
    XF[f'foot_{S_}'] = segment(lm(f'{side}-ankle'), lm(f'{side}-foot-end'), J[f'{side}-ankle'], J[f'{side}-toe-2-1'])

def decimate(ob, target):
    n = len(ob.data.polygons)
    if n <= target: return
    m = ob.modifiers.new('d', 'DECIMATE'); m.ratio = target / n
    dg = bpy.context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
    old = ob.data; ob.modifiers.clear(); ob.data = me; bpy.data.meshes.remove(old)

groups = skeleton_parts()
groups.pop('other', None)
count = 0
for g, fids in sorted(groups.items()):
    xf = XF[g]
    for fid in fids:
        P, F = read_stl(fid)
        name = NAMES[fid]
        if isinstance(xf, tuple):
            Pw = xf[1](P) if 'scapula' in name else xf[0](P)
        elif g in ('thorax', 'lumbar', 'pelvis', 'neck'):
            Pw = xf(P)
        else:
            Pw = xf(axes(P))
        ob = make_object(name[:60], Pw, F, coll)
        ob['fma'] = fid; ob['group'] = g
        ob.data.materials.append(CART if 'cartilage' in name else BONE)
        diag = np.linalg.norm(P.max(0) - P.min(0))
        decimate(ob, int(np.clip(300 + 30 * diag, 300, 7000)))
        for p in ob.data.polygons: p.use_smooth = True
        count += 1
print('bones placed:', count, 'faces:', sum(len(o.data.polygons) for o in coll.objects))

# anatomical joint centres in trainer space, for refining the rig later
AJ = {'shoulder_l': J['l-shoulder'], 'shoulder_r': J['r-shoulder'],
      'hip_l': hip_true['l'], 'hip_r': hip_true['r']}
for k in ('jugular', 'xiphisternal', 'C1', 'C7', 'T1', 'T12', 'L5', 'l-sc', 'r-sc', 'l-ac', 'r-ac'):
    p = L[k][None]
    AJ[k] = (XF['neck'](p) if k == 'C1' else warp_axial(p))[0]
for s in ('l', 'r'):
    AJ[f'{s}-ac'] = AJ[f'{s}-ac'] + girdle_shift(s)
json.dump({k: np.round(v, 4).tolist() for k, v in AJ.items()},
          open(os.path.join(HERE, 'anatomy_joints.json'), 'w'), indent=1)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(HERE, 'skeleton.blend'))
print('saved skeleton.blend')
