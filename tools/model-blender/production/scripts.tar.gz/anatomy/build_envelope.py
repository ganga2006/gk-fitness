"""
Muscles on the skeleton, then one closed 'muscle body' surface the skin can wrap.

Each BodyParts3D muscle is thickened along its own outer normals by a factor that
brings its measured thickness to a lean fitness trainer's, warped with the same
mapping as the bones, and (for muscles that insert on the humerus) rotated with
the arm into the trainer's A-pose. The union of muscles, the ribcage hull and
the subcutaneous bones is voxel-remeshed into a single envelope.
"""
import sys, os, json, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, bpy, bmesh
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
from bp3d_io import read_stl, make_object
from parts import NAMES
import fit
from fit import J, L, warp_axial, girdle_shift

HERE = os.path.dirname(os.path.abspath(__file__))
VOXEL = float(os.environ.get('GK_VOXEL', '0.018'))
bpy.ops.wm.open_mainfile(filepath=os.path.join(HERE, 'skeleton.blend'))
skel = bpy.data.collections['Skeleton']
mcoll = bpy.data.collections.new('Muscles'); bpy.context.scene.collection.children.link(mcoll)

def fid(name):
    for k, v in NAMES.items():
        if v == name: return k
    raise KeyError(name)

# (name pattern, target thickness mm, reference, follows arm)
# reference: 'trunk' = outward from the trunk axis, 'arm' = outward from the humerus
MUSCLES = [   # (name, added thickness mm, outward reference, follows arm)
    ('clavicular part of {s} pectoralis major',    8, 'trunk', True),
    ('sternocostal part of {s} pectoralis major', 11, 'trunk', True),
    ('abdominal part of {s} pectoralis major',     3, 'trunk', True),
    ('{s} pectoralis minor',                       0, 'trunk', False),
    ('clavicular part of {s} deltoid',            10, 'arm',   True),
    ('acromial part of {s} deltoid',              12, 'arm',   True),
    ('spinal part of {s} deltoid',                 6, 'arm',   True),
    ('{s} serratus anterior',                      4, 'trunk', False),
    ('{s} external oblique',                       3, 'trunk', False),
    ('{s} rectus abdominis',                       6, 'trunk', False),
    ('{s} latissimus dorsi',                       6, 'trunk', True),
    ('descending part of {s} trapezius',           8, 'trunk', False),
    ('transverse part of {s} trapezius',           5, 'trunk', False),
    ('ascending part of {s} trapezius',            3, 'trunk', False),
    ('{s} infraspinatus muscle',                   4, 'trunk', False),
    ('{s} supraspinatus',                          4, 'trunk', False),
    ('{s} teres major',                            6, 'trunk', True),
    ('{s} teres minor',                            3, 'trunk', False),
    ('{s} rhomboid major',                         3, 'trunk', False),
    ('{s} rhomboid minor',                         2, 'trunk', False),
    ('{s} iliocostalis lumborum',                  8, 'trunk', False),
    ('{s} iliocostalis thoracis',                  3, 'trunk', False),
    ('{s} longissimus thoracis',                   8, 'trunk', False),
    ('{s} spinalis thoracis',                      3, 'trunk', False),
]
Y_AXIS = -105.0                     # trunk axis, front-back position (reference mm)

def mesh_arrays(ob):
    me = ob.data
    P = np.empty(len(me.vertices) * 3); me.vertices.foreach_get('co', P)
    F = np.empty(len(me.polygons) * 3, dtype=np.int64); me.polygons.foreach_get('vertices', F)
    return P.reshape(-1, 3), F.reshape(-1, 3)

def decimate_to(ob, target):
    n = len(ob.data.polygons)
    if n > target:
        m = ob.modifiers.new('d', 'DECIMATE'); m.ratio = target / n
        dg = bpy.context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
        old = ob.data; ob.modifiers.clear(); ob.data = me; bpy.data.meshes.remove(old)
    bm = bmesh.new(); bm.from_mesh(ob.data)
    bmesh.ops.triangulate(bm, faces=bm.faces)
    bm.to_mesh(ob.data); bm.free()

def vertex_normals(P, F):
    fn = np.cross(P[F[:, 1]] - P[F[:, 0]], P[F[:, 2]] - P[F[:, 0]])
    vn = np.zeros_like(P)
    for k in range(3): np.add.at(vn, F[:, k], fn)
    vol = np.einsum('ij,ij->i', P[F[:, 0]], np.cross(P[F[:, 1]], P[F[:, 2]])).sum() / 6
    vn /= np.linalg.norm(vn, axis=1, keepdims=True) + 1e-12
    return vn * (1 if vol >= 0 else -1)

def smooth_field(D, F, iters, w=0.5):
    e = np.r_[F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]
    e = np.r_[e, e[:, ::-1]]
    cnt = np.bincount(e[:, 0], minlength=len(D)).astype(float)[:, None] + 1e-9
    for _ in range(iters):
        acc = np.zeros_like(D); np.add.at(acc, e[:, 0], D[e[:, 1]])
        D = D * (1 - w) + (acc / cnt) * w
    return D

def outward_ref(P, ref, side):
    if ref == 'arm':
        a, b = L[f'{side}-shoulder'], L[f'{side}-elbow']
    else:
        a, b = np.array([0, Y_AXIS, 960.0]), np.array([0, Y_AXIS, 1300.0])
    ab = b - a
    t = np.clip(((P - a) @ ab) / (ab @ ab), 0, 1)
    r = P - (a + t[:, None] * ab)
    return r / (np.linalg.norm(r, axis=1, keepdims=True) + 1e-9)

def taubin(P, F, iters=8, lam=0.5, mu=-0.53):
    for _ in range(iters):
        P = smooth_field(P, F, 1, lam)
        P = smooth_field(P, F, 1, mu)
    return P

def thicken(P, F, add_mm, ref, side):
    """
    Add a uniform layer over the muscle's outer face, tapering to nothing at its
    rim. A multiplicative scale exaggerated wherever the reference muscle was
    already thick — on the pec that is the lower outer corner, which turned the
    chest into a rounded lower mound. An added layer keeps the muscle's own flat
    front plane and its straight lower border.
    """
    P = taubin(P, F)
    n = vertex_normals(P, F)
    n = smooth_field(n, F, 4); n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
    out = outward_ref(P, ref, side)
    facing = np.einsum('ij,ij->i', n, out)
    w = np.clip((facing - 0.10) / 0.35, 0, 1); w = w * w * (3 - 2 * w)
    bvh = BVHTree.FromPolygons(P.tolist(), F.tolist())
    t = np.zeros(len(P))
    for i in np.nonzero(w > 0)[0]:
        hit = bvh.ray_cast(Vector(P[i] - n[i] * 0.05), Vector(-n[i]), 90.0)
        if hit[0] is not None:
            t[i] = hit[3]
    sup = t[w > 0.5]
    med = float(np.median(sup[sup > 0.5])) if (sup > 0.5).sum() > 20 else 0.0
    ramp = np.clip(t / 7.0, 0, 1); ramp = ramp * ramp * (3 - 2 * ramp)
    D = n * (add_mm * ramp * w)[:, None]
    D = smooth_field(D, F, 8)
    return P + D, med, (med + add_mm) / med if med > 0 else 1.0

def girdle_field(P, side):
    """The shoulder girdle was nudged onto the trainer's shoulder joints; let the
    muscles around it follow, fading to nothing toward the spine and sternum."""
    g = np.clip((np.abs(P[:, 0]) - 40.0) / 90.0, 0, 1)
    g = g * g * (3 - 2 * g)
    return g[:, None] * girdle_shift(side)[None]

def arm_rotation(side):
    sh = J[f'{side}-shoulder']
    el_bp = warp_axial(L[f'{side}-elbow'])[0] + girdle_shift(side)
    u_bp = el_bp - sh
    u = J[f'{side}-elbow'] - sh
    q = Vector(u_bp).rotation_difference(Vector(u))
    axis, ang = np.array(q.axis), q.angle
    return sh, u_bp, axis, ang

_HUM = {}
def humerus_bvh(side):
    # the reference humerus, warped like the trunk (i.e. still hanging), to measure
    # how close each muscle vertex is to the bone it inserts on
    if side not in _HUM:
        P, F = read_stl(fid(f"{'left' if side == 'l' else 'right'} humerus"))
        Q = warp_axial(P) + girdle_shift(side)
        _HUM[side] = BVHTree.FromPolygons(Q.tolist(), F.tolist())
    return _HUM[side]

def follow_arm(Q, side, reach=0.42):
    sh, u_bp, axis, ang = arm_rotation(side)
    Lh = np.linalg.norm(u_bp); u = u_bp / Lh
    rel = Q - sh
    t = (rel @ u) / Lh
    bvh = humerus_bvh(side)
    d = np.array([(bvh.find_nearest(Vector(q))[3] or 9.0) for q in Q])
    wt = np.clip((t + 0.10) / 0.25, 0, 1); wt = wt * wt * (3 - 2 * wt)
    wd = np.clip((reach - d) / (reach - 0.06), 0, 1); wd = wd * wd * (3 - 2 * wd)
    w = wt * wd
    out = np.empty_like(Q)
    for i in range(len(Q)):
        if w[i] < 1e-4:
            out[i] = Q[i]; continue
        R = np.array(Matrix.Rotation(ang * w[i], 3, Vector(axis)))
        out[i] = sh + R @ rel[i]
    return out

MAT = bpy.data.materials.new('muscle'); MAT.diffuse_color = (0.62, 0.16, 0.14, 1)
report = []
for pattern, target, ref, arm in MUSCLES:
    for side, s in (('l', 'left'), ('r', 'right')):
        name = pattern.format(s=s)
        P, F = read_stl(fid(name))
        ob = make_object(name[:60], P, F, mcoll)
        decimate_to(ob, 24000)
        P, F = mesh_arrays(ob)
        P2, med, k = thicken(P, F, target, ref, side)
        Q = warp_axial(P2) + girdle_field(P2, side)
        if arm:
            Q = follow_arm(Q, side, reach=0.55 if 'deltoid' in name else 0.42)
        ob.data.vertices.foreach_set('co', Q.astype(np.float32).ravel())
        ob.data.update()
        ob.data.materials.append(MAT)
        for p in ob.data.polygons: p.use_smooth = True
        ob['thickness_ref_mm'] = round(med, 1); ob['thickness_factor'] = round(k, 2)
        report.append((name, med, k))
        print(f'{name:45s} measured {med:5.1f} mm  +{target} mm', flush=True)

# ── the envelope ───────────────────────────────────────────────────
def hull_from(objs, name):
    pts = np.vstack([mesh_arrays(o)[0] for o in objs])
    bm = bmesh.new()
    for p in pts[::2]: bm.verts.new(p)
    bmesh.ops.convex_hull(bm, input=bm.verts)
    for v in [v for v in bm.verts if not v.link_faces]: bm.verts.remove(v)
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    ob = bpy.data.objects.new(name, me); bpy.context.scene.collection.objects.link(ob)
    return ob

bones = list(skel.objects)
rib = [o for o in bones if o.get('group') == 'thorax' and 'vertebra' not in o.name]
low = [o for o in bones if o.get('group') == 'thorax' and any(w in o.name for w in
       ('eighth rib', 'ninth rib', 'tenth rib', 'eleventh rib', 'twelfth rib', 'costal cartilage'))]
pel = [o for o in bones if o.get('group') == 'pelvis']
core_t = hull_from(rib, 'core_thorax')
core_a = hull_from(low + pel, 'core_abdomen')
subq = [o for o in bones if o.get('group') in ('thorax', 'lumbar', 'neck') and 'vertebra' in o.name] + \
       [o for o in bones if o.get('group', '').startswith('girdle')] + pel

parts = [core_t, core_a] + list(mcoll.objects) + subq
dg = bpy.context.evaluated_depsgraph_get()
bm = bmesh.new()
for o in parts:
    me = o.evaluated_get(dg).to_mesh()
    tmp = bmesh.new(); tmp.from_mesh(me); tmp.transform(o.matrix_world)
    m2 = bpy.data.meshes.new('t'); tmp.to_mesh(m2); tmp.free()
    bm.from_mesh(m2); bpy.data.meshes.remove(m2)
    o.evaluated_get(dg).to_mesh_clear()
env_me = bpy.data.meshes.new('Envelope'); bm.to_mesh(env_me); bm.free()
env = bpy.data.objects.new('Envelope', env_me); bpy.context.scene.collection.objects.link(env)
for o in (core_t, core_a): bpy.data.objects.remove(o)
bpy.context.view_layer.objects.active = env
env.data.remesh_voxel_size = VOXEL
env.data.use_remesh_fix_poles = False
with bpy.context.temp_override(object=env, active_object=env, selected_objects=[env]):
    bpy.ops.object.voxel_remesh()
def bake_modifiers(ob):
    dg = bpy.context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg)); old = ob.data
    ob.modifiers.clear(); ob.data = me; bpy.data.meshes.remove(old)
def remesh(ob, size):
    ob.data.remesh_voxel_size = size
    with bpy.context.temp_override(object=ob, active_object=ob, selected_objects=[ob]):
        bpy.ops.object.voxel_remesh()
def displace(ob, amount):
    m = ob.modifiers.new('d', 'DISPLACE'); m.strength = amount; m.mid_level = 0.0
    m.direction = 'NORMAL'
    bake_modifiers(ob)
CLOSE = float(os.environ.get('GK_CLOSE', '0.022'))
sm = env.modifiers.new('s', 'SMOOTH'); sm.factor = 0.5; sm.iterations = 2; bake_modifiers(env)
displace(env, CLOSE); remesh(env, VOXEL)          # dilate: gaps narrower than 2r fill in
displace(env, -CLOSE); remesh(env, VOXEL)         # erode back to the original surface
sm = env.modifiers.new('s', 'SMOOTH'); sm.factor = 0.5; sm.iterations = 3; bake_modifiers(env)
# keep only the largest connected piece (drops stray islands)
bm = bmesh.new(); bm.from_mesh(env.data)
islands, seen = [], set()
for v in bm.verts:
    if v.index in seen: continue
    stack, isl = [v], []
    seen.add(v.index)
    while stack:
        x = stack.pop(); isl.append(x)
        for e in x.link_edges:
            y = e.other_vert(x)
            if y.index not in seen: seen.add(y.index); stack.append(y)
    islands.append(isl)
islands.sort(key=len, reverse=True)
for isl in islands[1:]:
    bmesh.ops.delete(bm, geom=isl, context='VERTS')
bm.to_mesh(env.data); bm.free()
env.hide_render = True
print(f'envelope: {len(env.data.vertices)} verts, {len(env.data.polygons)} faces, {len(islands)} islands before cleanup')
json.dump([(n, round(m, 1), round(k, 2)) for n, m, k in report],
          open(os.path.join(HERE, 'muscle_thickness.json'), 'w'), indent=1)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(HERE, 'anatomy.blend'))
print('saved anatomy.blend')

# softened copy for the low-poly game mesh
import runpy
runpy.run_path(os.path.join(HERE, 'soften_envelope.py'))
