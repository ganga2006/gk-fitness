import bpy, math, sys
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/GKFitness_Trainer_Production.blend')
sc = bpy.context.scene; sc.render.engine = 'CYCLES'; sc.cycles.samples = 40; sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = 600, 900
w = bpy.data.worlds.new('W'); w.use_nodes = True; w.node_tree.nodes['Background'].inputs[0].default_value = (0.045, 0.05, 0.065, 1); sc.world = w
rig = bpy.data.objects['Rig']; a = bpy.data.actions['Idle_Neutral']; rig.animation_data.action = a; rig.animation_data.action_slot = a.slots[0]; sc.frame_set(1)
def L(n, e, s):
    d = bpy.data.lights.new(n, 'AREA'); d.energy = e; d.size = s; o = bpy.data.objects.new(n, d); sc.collection.objects.link(o); return o
key, fill, rim = L('k', 9000, 6), L('f', 1800, 10), L('r', 6000, 6)
cd = bpy.data.cameras.new('C'); cd.lens = 70; cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
def aim(o, p, t): o.location = p; o.rotation_euler = (t - p).normalized().to_track_quat('-Z', 'Y').to_euler()
SHOTS = [('front', 0, Vector((0.3, 0, 6.0)), 30), ('tq', -35, Vector((0.3, 0, 6.0)), 30), ('back', 180, Vector((0.0, 0, 6.0)), 30),
         ('hips', 0, Vector((0.5, 0, 6.2)), 9), ('hips_side', 90, Vector((0.2, 0, 6.2)), 9), ('portrait', -20, Vector((0.6, 0, 10.6)), 9)]
for nm, az, t, dist in SHOTS:
    a_ = math.radians(az); aim(cam, t + Vector((math.cos(a_) * dist, math.sin(a_) * dist, dist * 0.04)), t)
    R = dist * 0.8
    aim(key, t + Vector((math.cos(a_ - 0.8) * R, math.sin(a_ - 0.8) * R, R * 0.7)), t)
    aim(fill, t + Vector((math.cos(a_ + 0.9) * R, math.sin(a_ + 0.9) * R, R * 0.1)), t)
    aim(rim, t + Vector((math.cos(a_ + 2.7) * R, math.sin(a_ + 2.7) * R, R * 0.6)), t)
    sc.render.filepath = f'/home/claude/mh/inspect/final_{nm}.png'; bpy.ops.render.render(write_still=True)
