"""X-ray views: the fitted skeleton inside a translucent trainer body."""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, bpy
from mathutils import Vector
from PIL import Image
import fit

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'renders'); os.makedirs(OUT, exist_ok=True)
BODY_FILE = sys.argv[sys.argv.index('--body') + 1] if '--body' in sys.argv else os.path.join(fit.MH, 'mh_base.blend')
STRETCH = '--no-stretch' not in sys.argv
bpy.ops.wm.open_mainfile(filepath=os.path.join(HERE, 'skeleton.blend'))
with bpy.data.libraries.load(BODY_FILE) as (src, dst):
    dst.objects = ['Body']
body = dst.objects[0]
bpy.context.scene.collection.objects.link(body)
body.modifiers.clear()
if STRETCH:
    co = np.array([v.co[:] for v in body.data.vertices])
    co = fit.stretch_arms(co)
    body.data.vertices.foreach_set('co', co.astype(np.float32).ravel())
    body.data.update()
skel = [o for o in bpy.data.objects if o.type == 'MESH' and o is not body]
for o in skel:
    o.color = (0.66, 0.74, 0.80, 1) if 'cartilage' in o.name else (0.86, 0.80, 0.66, 1)
body.color = (0.82, 0.62, 0.52, 1)

sc = bpy.context.scene
sc.render.engine = 'BLENDER_WORKBENCH'
sc.render.film_transparent = True
sh = sc.display.shading
sh.light = 'STUDIO'; sh.color_type = 'OBJECT'; sh.show_cavity = True
sh.cavity_type = 'BOTH'; sh.show_shadows = False
cd = bpy.data.cameras.new('C'); cd.lens = 90
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam

def shoot(path, az, target, dist, lift, res):
    sc.render.resolution_x, sc.render.resolution_y = res
    a = math.radians(az)
    cam.location = Vector((math.cos(a) * dist, math.sin(a) * dist, target.z + lift))
    cam.rotation_euler = (target - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)

def xray(name, az, target, dist, lift=0.0, res=(560, 900), ghost=0.30):
    for o in skel: o.hide_render = False
    body.hide_render = True
    shoot(f'/tmp/sk_{name}.png', az, target, dist, lift, res)
    for o in skel: o.hide_render = True
    body.hide_render = False
    shoot(f'/tmp/bd_{name}.png', az, target, dist, lift, res)
    for o in skel: o.hide_render = False
    bg = Image.new('RGBA', res, (22, 25, 31, 255))
    bd = Image.open(f'/tmp/bd_{name}.png').convert('RGBA')
    a = bd.split()[3].point(lambda v: int(v * ghost))
    bd.putalpha(a)
    bg = Image.alpha_composite(bg, bd)
    bg = Image.alpha_composite(bg, Image.open(f'/tmp/sk_{name}.png').convert('RGBA'))
    bg.convert('RGB').save(os.path.join(OUT, f'xray_{name}.png'))
    print('rendered', name)

full = Vector((0, 0, 6.0))
xray('front', 0, full, 46, 0.5)
xray('side', 90, full, 46, 0.5)
xray('back', 180, full, 46, 0.5)
chest = Vector((0.2, 0, 8.9))
xray('chest_front', 0, chest, 17, 0.4, (720, 720), 0.26)
xray('chest_34', -38, chest, 17, 0.6, (720, 720), 0.26)
