"""Cycles torso close-ups (front, three-quarter, side, back) for chest review. usage: -- <blend> <prefix>"""
import bpy, os, math, sys
from mathutils import Vector
args = sys.argv[sys.argv.index('--') + 1:]
bpy.ops.wm.open_mainfile(filepath=args[0]); pre = args[1]
sc = bpy.context.scene
for o in bpy.data.objects:
    if o.type == 'MESH' and o.name != 'Body':
        o.hide_render = True
body = bpy.data.objects['Body']
for m in body.modifiers:
    if m.type == 'ARMATURE': m.show_render = False
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 24; sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = 520, 640
w = bpy.data.worlds.new('W'); w.use_nodes = True
w.node_tree.nodes['Background'].inputs[0].default_value = (0.05, 0.06, 0.08, 1); sc.world = w
mat = bpy.data.materials.new('skin_review'); mat.use_nodes = True
b = mat.node_tree.nodes['Principled BSDF']; b.inputs['Base Color'].default_value = (0.62, 0.45, 0.36, 1)
b.inputs['Roughness'].default_value = 0.5
body.data.materials.clear(); body.data.materials.append(mat)
for p in body.data.polygons: p.material_index = 0; p.use_smooth = True
def light(n, loc, e, sz, c):
    d = bpy.data.lights.new(n, 'AREA'); d.energy = e; d.size = sz; d.color = c
    o = bpy.data.objects.new(n, d); o.location = loc
    o.rotation_euler = (Vector((0, 0, 8.5)) - Vector(loc)).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.collection.objects.link(o)
light('key', (9, -7, 14), 9000, 7, (1, .97, .93)); light('fill', (8, 9, 9), 2600, 10, (.85, .9, 1))
light('rim', (-9, 4, 12), 5200, 8, (1, 1, 1)); light('rim2', (-9, -6, 9), 2500, 8, (1, 1, 1))
cd = bpy.data.cameras.new('C'); cd.lens = 85
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
def shoot(tag, az, z=8.55, dist=14.5, lift=0.5):
    a = math.radians(az); t = Vector((0.25, 0, z))
    cam.location = Vector((math.cos(a) * dist, math.sin(a) * dist, z + lift))
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = f'{pre}_{tag}.png'; bpy.ops.render.render(write_still=True)
shoot('front', -4); shoot('tq', -38); shoot('side', -90); shoot('back', 182)
print('rendered')
