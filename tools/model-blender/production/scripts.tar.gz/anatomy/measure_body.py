"""Measures proportions, girths and mesh health of the current body."""
import bpy, bmesh, numpy as np, json, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/mh_shaped.blend')
o = bpy.data.objects['Body']; me = o.data
V = np.array([v.co for v in me.vertices]); H = V[:,2].max() - V[:,2].min()
U = 1.778 / H   # metres per unit, trainer at 178 cm
J = {k: np.array(v) for k, v in json.load(open('/home/claude/mh/joints.json')).items()}
def girth(z, cond):
    sl = V[(np.abs(V[:,2]-z) < 0.03) & cond(V)]
    if len(sl) < 8: return float('nan')
    c = sl[:,:2].mean(0); ang = np.arctan2(sl[:,1]-c[1], sl[:,0]-c[0]); r = np.hypot(sl[:,0]-c[0], sl[:,1]-c[1])
    bins = np.linspace(-math.pi, math.pi, 49); rr = [r[(ang>=bins[i])&(ang<bins[i+1])].max() for i in range(48) if ((ang>=bins[i])&(ang<bins[i+1])).any()]
    pts = [(c[0]+R*math.cos((bins[i]+bins[i+1])/2), c[1]+R*math.sin((bins[i]+bins[i+1])/2)) for i,R in enumerate(rr)]
    return sum(math.dist(pts[i], pts[(i+1)%len(pts)]) for i in range(len(pts))) * U * 100
torso = lambda V: np.abs(V[:,1]) < 1.15
left = lambda lo, hi: (lambda V: (V[:,1] > lo) & (V[:,1] < hi))
res = {}
res['height_cm'] = H*U*100
head_top = V[:,2].max(); chin = 10.37
res['head_height_cm'] = (head_top - chin)*U*100; res['heads_tall'] = H/(head_top-chin)
for nm, z, c in (('neck', 10.25, lambda V: np.abs(V[:,1])<0.45), ('chest', 8.95, lambda V: np.abs(V[:,1])<1.08), ('waist', 7.35, torso), ('hips', 6.25, torso)):
    res[f'{nm}_girth_cm'] = girth(z, c)
sl = V[np.abs(V[:,2]-9.30) < 0.06]; res['shoulder_width_cm'] = (sl[:,1].max()-sl[:,1].min())*U*100
sl = V[(np.abs(V[:,2]-7.35) < 0.06) & torso(V)]; res['waist_width_cm'] = (sl[:,1].max()-sl[:,1].min())*U*100
sho, elb, hnd = J['l-shoulder'], J['l-elbow'], J['l-hand']; hip, kne, ank = J['l-upper-leg'], J['l-knee'], J['l-ankle']
res['upperarm_len_cm'] = np.linalg.norm(elb-sho)*U*100; res['forearm_len_cm'] = np.linalg.norm(hnd-elb)*U*100
res['thigh_len_cm'] = np.linalg.norm(kne-hip)*U*100; res['shin_len_cm'] = np.linalg.norm(ank-kne)*U*100
def limb_girth(a, b, t, rad=0.75):
    p = a + (b-a)*t; d = (b-a)/np.linalg.norm(b-a)
    rel = V - p; along = rel @ d; perp = rel - np.outer(along, d)
    sl = perp[(np.abs(along) < 0.03) & (np.linalg.norm(perp,axis=1) < rad)]
    if len(sl) < 6: return float('nan')
    e1 = np.cross(d, [0,0,1.0]); e1 /= np.linalg.norm(e1); e2 = np.cross(d, e1)
    xy = np.c_[sl@e1, sl@e2]; ang = np.arctan2(xy[:,1], xy[:,0]); r = np.hypot(*xy.T)
    bins = np.linspace(-math.pi, math.pi, 37); pts=[]
    for i in range(36):
        m = (ang>=bins[i])&(ang<bins[i+1])
        if m.any(): R=r[m].max(); a_=(bins[i]+bins[i+1])/2; pts.append((R*math.cos(a_), R*math.sin(a_)))
    return sum(math.dist(pts[i], pts[(i+1)%len(pts)]) for i in range(len(pts)))*U*100
res['biceps_girth_cm'] = limb_girth(sho, elb, 0.45, 0.6); res['forearm_girth_cm'] = limb_girth(elb, hnd, 0.25, 0.5)
res['thigh_girth_cm'] = limb_girth(hip, kne, 0.30, 0.95); res['calf_girth_cm'] = limb_girth(kne, ank, 0.30, 0.7)
res['shoulder_to_waist'] = res['shoulder_width_cm']/res['waist_width_cm']
res['chest_to_waist_girth'] = res['chest_girth_cm']/res['waist_girth_cm']
# symmetry: mirror error
from mathutils.kdtree import KDTree
kd = KDTree(len(V)); [kd.insert(Vector(p), i) for i,p in enumerate(V)]; kd.balance()
errs = np.array([kd.find(Vector((p[0], -p[1], p[2])))[2] for p in V]); res['symmetry_err_mm_p99'] = float(np.percentile(errs,99))*U*1000
bm = bmesh.new(); bm.from_mesh(me)
res['verts'] = len(bm.verts); res['non_manifold_edges'] = sum(1 for e in bm.edges if not e.is_manifold)
res['loose_verts'] = sum(1 for v in bm.verts if not v.link_edges)
spikes = 0
for v in bm.verts:
    ring = [e.other_vert(v).co for e in v.link_edges]
    if len(ring) < 3: continue
    avg = sum(ring, Vector())/len(ring); edge = sum((p-v.co).length for p in ring)/len(ring)
    if (v.co-avg).length > 0.6*edge: spikes += 1
res['spiky_verts'] = spikes
for k, v in res.items(): print(f'{k:24s} {v:.2f}' if isinstance(v, float) else f'{k:24s} {v}')
json.dump(res, open('/home/claude/mh/inspect/measurements.json', 'w'), indent=1, default=float)
