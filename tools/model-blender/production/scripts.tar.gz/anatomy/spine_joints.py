"""Move the rig's spine/neck pivots onto the real (fitted) vertebral column."""
import sys, json, numpy as np
sys.path.insert(0, '/home/claude/mh/anatomy')
import body_rig_map as M
from bp3d_io import read_stl
from parts import NAMES
ids = {v: k for k, v in NAMES.items()}
names = ['fifth lumbar vertebra','third lumbar vertebra','first lumbar vertebra','tenth thoracic vertebra','seventh thoracic vertebra',
         'fourth thoracic vertebra','first thoracic vertebra','seventh cervical vertebra','fourth cervical vertebra','axis']
pts = []
for n in names:
    P = read_stl(ids[n])[0]
    body = P[P[:, 1] < np.percentile(P[:, 1], 45)]            # anterior part = the vertebral body, not the spinous process
    pts.append(M.trunk(M.c(body.mean(0)[None]))[0] if 'cervical' not in n and n != 'axis' else M.map_points(body.mean(0)[None])[0])
pts = np.array(pts); order = np.argsort(pts[:, 2]); pts = pts[order]
J = json.load(open('/home/claude/mh/joints.json'))
json.dump(J, open('/home/claude/mh/joints_before_spine.json', 'w'))
for k in ('spine-3', 'spine-2', 'spine-1', 'neck', 'head'):     # pelvis stays at the hip-hinge pivot
    z = J[k][2]; x_old = J[k][0]
    x_new = float(np.interp(z, pts[:, 2], pts[:, 0]))
    if k == 'head': x_new = x_old + 0.6 * (x_new - x_old)        # skull pivot (occipital condyles) sits close to the column
    J[k][0] = x_new; J[k][1] = 0.0
    print(f'{k:8s} z {z:.2f}: x {x_old:+.3f} -> {x_new:+.3f}  ({(x_new-x_old)*147.4:+.0f} mm)')
json.dump(J, open('/home/claude/mh/joints.json', 'w'), indent=1)
