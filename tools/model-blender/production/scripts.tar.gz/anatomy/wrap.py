"""
Shared skin wrap: put the torso skin onto a muscle-body surface.

Used for the game mesh (onto the softened muscle body) and for the
high-detail mesh (onto the full-detail muscle body).
"""
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

def sstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)

def bvh_from_object(ob):
    import bmesh
    bm = bmesh.new(); bm.from_mesh(ob.data); bm.transform(ob.matrix_world)
    t = BVHTree.FromBMesh(bm); bm.free()
    return t

def torso_mask(co, nrm, J):
    """1 on the torso, fading out at the neck, below the iliac crest (lower over
    the abs), and down the upper arm past the deltoid."""
    front = np.clip(nrm[:, 0], 0, 1)
    back = np.clip(-nrm[:, 0], 0, 1)
    z = co[:, 2]
    bottom = 7.30 - 0.75 * sstep(0.25, 0.70, front)
    w = sstep(bottom - 0.25, bottom + 0.15, z)
    top = 10.02 + 0.30 * back
    w *= 1 - sstep(top - 0.12, top + 0.18, z)
    for side in ('l', 'r'):
        sh, el = np.asarray(J[f'{side}-shoulder']), np.asarray(J[f'{side}-elbow'])
        u = el - sh; Lh = np.linalg.norm(u); u = u / Lh
        rel = co - sh
        t = (rel @ u) / Lh
        r = np.linalg.norm(rel - np.outer(t * Lh, u), axis=1)
        on_arm = sstep(0.80, 0.55, r) * sstep(0.0, 0.08, t)
        cap = 1 - sstep(0.26, 0.46, t)
        w *= 1 - on_arm * (1 - cap)
        w[(t > 0.95) & (r < 1.2)] = 0.0
    return w

def wrap(co, nrm, edges, bvh, w, offset, relax=12, max_in=0.22):
    """
    Returns new coordinates. Skin vertices with weight w land on the surface
    (plus `offset`) and are then relaxed ON the surface, so none of the old
    surface's small features survive; the result is blended in by w.
    """
    co = np.asarray(co, float); nrm = np.asarray(nrm, float)
    E = np.r_[edges, edges[:, ::-1]]
    cnt = np.bincount(E[:, 0], minlength=len(co)).astype(float)[:, None]
    idx = np.nonzero(w > 1e-3)[0]
    off = np.broadcast_to(offset, (len(co),)) if np.ndim(offset) == 0 else offset
    def onto(q, o):
        h = bvh.find_nearest(Vector(q), 0.6)
        return None if h[0] is None else np.array(h[0] + h[1] * o)
    P = co.copy(); got = np.zeros(len(co), bool)
    for i in idx:
        p, n = Vector(co[i]), Vector(nrm[i])
        hit = None
        for lift in (0.35, 0.70):
            h = bvh.ray_cast(p + n * lift, -n, lift + 0.55)
            if h[0] is not None and h[1].dot(n) > 0.0:
                hit = h; break
        if hit is not None and (hit[0] - p).length < 0.60:
            P[i] = np.array(hit[0] + hit[1] * off[i]); got[i] = True
        else:
            q = onto(co[i], off[i])
            if q is not None: P[i] = q; got[i] = True
    live = idx[got[idx]]
    for _ in range(relax):
        acc = np.zeros_like(P); np.add.at(acc, E[:, 0], P[E[:, 1]])
        avg = acc / cnt
        for i in live:
            q = onto(P[i] + 0.5 * (avg[i] - P[i]), off[i])
            if q is not None: P[i] = q
    D = (P - co) * (w * got)[:, None]
    inward = -np.einsum('ij,ij->i', D, nrm)
    D *= np.where(inward > max_in, max_in / np.maximum(inward, 1e-9), 1.0)[:, None]
    return co + D, int((w > 0.5).sum())

def skin_offset(co):
    return 0.028 + 0.012 * sstep(8.4, 7.4, co[:, 2])
