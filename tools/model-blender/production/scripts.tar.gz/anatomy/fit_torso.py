import sys; sys.path.insert(0, '/home/claude/mh/anatomy')
import numpy as np, bpy, json
from bp3d_io import read_stl
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/mh_shaped.blend')
body = bpy.data.objects['Body']
V = np.array([body.matrix_world @ v.co for v in body.data.vertices])
s = (9.662-6.234)/(1325.2-820.0); z0 = 9.662 - 1325.2*s
sk, _ = read_stl('FMA7163')
rows = []
for zl in np.arange(8.0, 9.65, 0.1):
    m = V[np.abs(V[:,2]-zl) < 0.08]; m = m[np.abs(m[:,1]) < 0.35]   # midline strip: front/back
    zb = (zl - z0)/s
    b = sk[np.abs(sk[:,2]-zb) < 4]; b = b[np.abs(b[:,0]) < 0.35/s]
    rows.append((zl, m[:,0].max(), m[:,0].min(), (-b[:,1]).max()*s, (-b[:,1]).min()*s))
r = np.array(rows)
# fit x = x0 + kx * raw  using front and back
A = np.r_[np.c_[np.ones(len(r)), r[:,3]], np.c_[np.ones(len(r)), r[:,4]]]
y = np.r_[r[:,1], r[:,2]]
(x0, kx), *_ = np.linalg.lstsq(A, y, rcond=None)
print('x0 %.3f kx %.3f' % (x0, kx))
for row in r: print('z %.2f  MH front %.3f back %.3f | BP fit front %.3f back %.3f' % (row[0], row[1], row[2], x0+kx*row[3], x0+kx*row[4]))
json.dump(dict(s=s, z0=z0, x0=x0, kx=kx), open('/home/claude/mh/anatomy/fit.json','w'))
