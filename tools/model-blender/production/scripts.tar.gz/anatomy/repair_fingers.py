"""One-off repair: give the fingertip vertices the hand shift they missed (bug fixed in move_legs.py)."""
import bpy, json
from mathutils import Vector
Jo = {k: Vector(v) for k, v in json.load(open('/home/claude/mh/joints_mh_original.json')).items()}
U = 14.74
def seg_dist(p, a, b):
    ab = b - a; t = (p - a).dot(ab) / ab.length_squared
    return t, (p - (a + ab * max(0.0, min(1.0, t)))).length
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/mh_shaped.blend')
body = bpy.data.objects['Body']; n = 0
for sd, sg in (('l', 1), ('r', -1)):
    S_, E_, H_ = Jo[f'{sd}-shoulder'], Jo[f'{sd}-elbow'], Jo[f'{sd}-hand']
    d1, L1 = (E_ - S_).normalized(), (E_ - S_).length; d2, L2 = (H_ - E_).normalized(), (H_ - E_).length
    shift = d1 * (30.5 / U - L1) + d2 * (26.0 / U - L2)
    tip = Jo[f'{sd}-finger-3-4']; tip = tip + (tip - H_) * 0.15
    for v in body.data.vertices:
        p = v.co
        if p.y * sg < 0.6: continue
        t2, _ = seg_dist(p, E_, H_)
        # missed = beyond the hand, out of the old 1.25 reach, on the fingers (still at the old place)
        if t2 > 0.98 and (p - H_).length >= 1.25 and seg_dist(p, H_, tip)[1] < 0.75:
            v.co = p + shift; n += 1
body.data.update()
bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/mh_shaped.blend')
print('fingertip vertices repaired:', n)
