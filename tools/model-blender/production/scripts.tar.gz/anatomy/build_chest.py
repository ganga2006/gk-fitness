"""
GK Fitness — chest anatomy, skeleton first, then muscle.

1. The real thoracic skeleton (BodyParts3D: ribs, costal cartilage, sternum,
   clavicles) is mapped into the trainer's frame with a measured warp.
2. The real muscles are mapped the same way. The parts that attach to the arm
   (pec tendon, front deltoid) are swung with the humerus from the scan's
   arms-down pose into the trainer's A-pose.
3. Muscles are thickened for an athletic build by growing only their outer
   face (so their borders stay where anatomy puts them).
4. Bones + muscles are fused into one 'envelope' surface the skin is later
   wrapped onto.
"""
import sys, json, math
sys.path.insert(0, '/home/claude/mh/anatomy')
import numpy as np, bpy, bmesh
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
from bp3d_io import read_stl, make_object

F = json.load(open('/home/claude/mh/anatomy/fit.json'))
S, Z0, X0 = F['s'], F['z0'], F['x0']
KY = 1.10                                  # ribcage 10% wider: athletic frame
J = {k: Vector(v) for k, v in json.load(open('/home/claude/mh/joints.json')).items()}

def warp(P):                               # BP3D mm  ->  trainer units (x fwd, y left, z up)
    return np.c_[X0 - P[:, 1] * S, P[:, 0] * S * KY, Z0 + P[:, 2] * S]

bpy.ops.wm.read_factory_settings(use_empty=True)
col_b = bpy.data.collections.new('Skeleton'); bpy.context.scene.collection.children.link(col_b)
col_m = bpy.data.collections.new('Muscles');  bpy.context.scene.collection.children.link(col_m)

# ── arm swing: humerus from arms-down to the trainer's A-pose ───────
def arm_frame(side):
    hum, _ = read_stl('FMA23131' if side > 0 else 'FMA23130')
    W = warp(hum)
    head_bp = np.array([161.3 * side, -71.9, 1325.2])
    h = Vector(warp(head_bp[None])[0])
    dist = Vector(W[W[:, 2] < W[:, 2].min() + 0.12].mean(0))
    sho = Vector((J['l-shoulder'].x, J['l-shoulder'].y * side, J['l-shoulder'].z))
    elb = Vector((J['l-elbow'].x, J['l-elbow'].y * side, J['l-elbow'].z))
    q = (dist - h).normalized().rotation_difference((elb - sho).normalized())
    return h, sho, q.to_matrix()

ARM = {s: arm_frame(s) for s in (1, -1)}
print('arm swing (deg):', {s: round(math.degrees(ARM[s][2].to_quaternion().angle), 1) for s in ARM})

smooth = lambda t: np.clip(t, 0, 1) ** 2 * (3 - 2 * np.clip(t, 0, 1))

def swing(W, side, weight):
    """Blend each point between 'stays with the chest' and 'moves with the humerus'."""
    h, sho, R = ARM[side]
    Rn = np.array(R)
    moved = (W - np.array(h)) @ Rn.T + np.array(sho)
    # the shoulder joint itself also shifts slightly to the rig's joint
    shift = np.array(sho - h)
    stay = W + shift * weight[:, None] * 0.0
    return stay * (1 - weight[:, None]) + moved * weight[:, None]

def add(name, fid, coll, side=0, arm_weight=None, thick=1.0, decimate=None):
    P, Fc = read_stl(fid)
    W = warp(P)
    if side and arm_weight is not None:
        W = swing(W, side, arm_weight(W, side))
    ob = make_object(name, W, Fc, coll)
    if decimate and len(P) > decimate:
        m = ob.modifiers.new('dec', 'DECIMATE'); m.ratio = decimate / len(P)
        bpy.context.view_layer.objects.active = ob
        with bpy.context.temp_override(object=ob): bpy.ops.object.modifier_apply(modifier='dec')
    if thick != 1.0:
        thicken(ob, thick)
    return ob

def thicken(ob, k):
    """Grow the muscle's outer face so its thickness becomes k x, borders fixed."""
    bm = bmesh.new(); bm.from_mesh(ob.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-4)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces); bm.normal_update()
    tree = BVHTree.FromBMesh(bm)
    ctr = Vector((0.35, 0.0, 0.0))
    disp = {}
    for v in bm.verts:
        n = v.normal
        radial = v.co - Vector((ctr.x, 0.0, v.co.z))
        if n.dot(radial.normalized()) < 0.15:       # deep face: leave on the bone
            continue
        hit = tree.ray_cast(v.co - n * 1e-3, -n, 0.6)
        if hit[0] is None: continue
        t = hit[3]
        # an athlete's pec is fullest high and toward the sternum; the lower
        # border stays a tight edge — uniform thickening makes a hanging dome
        zw = 0.35 + 0.65 * max(0.0, min(1.0, (v.co.z - 8.55) / 0.75)) if 'pec' in ob.name else 1.0
        disp[v.index] = n * ((k - 1) * t * zw)
    # relax the displacement field so the surface stays smooth
    for _ in range(6):
        new = {}
        for v in bm.verts:
            if v.index not in disp: continue
            nb = [disp.get(e.other_vert(v).index) for e in v.link_edges]
            nb = [d for d in nb if d is not None]
            new[v.index] = (disp[v.index] * 2 + sum(nb, Vector())) / (2 + len(nb)) if nb else disp[v.index]
        disp = new
    for v in bm.verts:
        if v.index in disp: v.co += disp[v.index]
    bm.to_mesh(ob.data); bm.free()

# weights for arm-attached muscles
def pec_w(W, side):
    y = np.abs(W[:, 1]); return smooth((y - 0.85) / (1.22 - 0.85))
def delt_w(W, side):
    sho = ARM[side][1]
    return smooth(((sho.z + 0.10) - W[:, 2]) / 0.55) * smooth((np.abs(W[:, 1]) - 0.75) / 0.35)

BONES = {
    'ribs': ['FMA7987','FMA8012','FMA8039','FMA8148','FMA8093','FMA8202','FMA8256','FMA8310','FMA8391','FMA8472','FMA8532','FMA8534',
             'FMA7857','FMA7882','FMA7909','FMA7957','FMA8066','FMA8175','FMA8229','FMA8283','FMA8364','FMA8445','FMA8531','FMA8533'],
    'costal_cartilage': ['BP24', 'BP28'],
    'sternum': ['FMA7486', 'FMA7487'],
    'clavicle': ['FMA13323', 'FMA13322'],
    'vertebrae_T': ['FMA9165','FMA9187','FMA9248','FMA9922','FMA9945','FMA9968','FMA9991','FMA10014','FMA10037','FMA10059','FMA10081'],
}
for grp, ids in BONES.items():
    for fid in ids:
        add(f'bone_{grp}_{fid}', fid, col_b, decimate=6000)
for side, hid in ((1, 'FMA23131'), (-1, 'FMA23130')):
    add(f'bone_humerus_{"L" if side>0 else "R"}', hid, col_b, side, lambda W, s: np.ones(len(W)), decimate=6000)

MUSC = [  # name, left id, right id, arm weight, thickness factor, decimate target
    ('pec_clavicular',   'FMA34691', 'FMA34690', pec_w, 1.60, 8000),
    ('pec_sternocostal', 'FMA79980', 'FMA79979', pec_w, 1.45, 14000),
    ('pec_abdominal',    'FMA45875', 'FMA45874', pec_w, 1.10, 6000),
    ('deltoid_front',    'FMA34681', 'FMA34680', delt_w, 1.35, 9000),
    ('serratus_anterior','FMA13399', 'FMA13398', None, 1.25, 14000),
    ('rectus_abdominis', 'FMA13378', 'FMA13377', None, 1.30, 14000),
    ('external_oblique', 'FMA13337', 'FMA13336', None, 1.00, 16000),
]
for name, lid, rid, aw, k, dec in MUSC:
    for side, fid in ((1, lid), (-1, rid)):
        add(f'mus_{name}_{"L" if side>0 else "R"}', fid, col_m, side, aw, k, dec)
        print('muscle', name, side)

bpy.ops.wm.save_as_mainfile(filepath='/home/claude/mh/anatomy/chest_anatomy.blend')
print('saved chest_anatomy.blend', len(col_b.objects), 'bones', len(col_m.objects), 'muscles')
