"""Fast binary-STL loader for BodyParts3D parts (welds the triangle soup)."""
import numpy as np, os, bpy
BP = '/home/claude/kevin-mattheus-moerman/bodyparts3d/assets/BodyParts3D_data/stl'

def read_stl(fmaid):
    path = os.path.join(BP, f'{fmaid}.stl')
    with open(path, 'rb') as f:
        f.read(80)
        n = int(np.frombuffer(f.read(4), dtype='<u4')[0])
        rec = np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')])
        data = np.frombuffer(f.read(n * 50), dtype=rec, count=n)
    tris = data['v'].reshape(-1, 3).astype(np.float64)
    key = np.round(tris, 4)
    uniq, inv = np.unique(key, axis=0, return_inverse=True)
    faces = inv.reshape(-1, 3)
    ok = (faces[:, 0] != faces[:, 1]) & (faces[:, 1] != faces[:, 2]) & (faces[:, 0] != faces[:, 2])
    return uniq, faces[ok]

def make_object(name, verts, faces, coll=None):
    me = bpy.data.meshes.new(name)
    me.vertices.add(len(verts)); me.vertices.foreach_set('co', verts.astype(np.float32).ravel())
    me.loops.add(len(faces) * 3); me.loops.foreach_set('vertex_index', faces.astype(np.int32).ravel())
    me.polygons.add(len(faces))
    me.polygons.foreach_set('loop_start', np.arange(0, len(faces) * 3, 3, dtype=np.int32))
    me.polygons.foreach_set('loop_total', np.full(len(faces), 3, dtype=np.int32))
    me.update(calc_edges=True); me.validate()
    ob = bpy.data.objects.new(name, me)
    (coll or bpy.context.scene.collection).objects.link(ob)
    return ob
