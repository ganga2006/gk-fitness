import bpy, os, math
from mathutils import Vector
A = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(A, 'muscles.blend'))
sc = bpy.context.scene
sc.render.engine = 'BLENDER_WORKBENCH'; sc.render.film_transparent = False
sh = sc.display.shading
sh.light = 'STUDIO'; sh.color_type = 'OBJECT'; sh.show_cavity = True; sh.cavity_type = 'BOTH'
sh.curvature_ridge_factor = 1.0; sh.curvature_valley_factor = 1.2; sh.show_shadows = False
w = bpy.data.worlds.new('W'); sc.world = w; w.color = (0.06, 0.07, 0.09)
for o in bpy.data.objects:
    if o.type != 'MESH': continue
    if o.name.startswith('Skel'): o.color = (0.90, 0.85, 0.72, 1)
    elif o.name.startswith('M_pec_major'): o.color = (0.86, 0.22, 0.17, 1)
    elif o.name.startswith('M_'): o.color = (0.66, 0.20, 0.16, 1)
    elif o.name == 'Envelope': o.color = (0.74, 0.62, 0.55, 1)
cd = bpy.data.cameras.new('C'); cd.type = 'ORTHO'
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
def shoot(name, az, z, scale, w=640, h=760, env=False, el=6):
    cd.ortho_scale = scale; sc.render.resolution_x, sc.render.resolution_y = w, h
    for o in bpy.data.objects:
        if o.type == 'MESH':
            o.hide_render = (o.name != 'Envelope') if env else (o.name == 'Envelope')
    a, e = math.radians(az), math.radians(el); t = Vector((0.2, 0, z))
    cam.location = t + Vector((math.cos(a) * math.cos(e), math.sin(a) * math.cos(e), math.sin(e))) * 30
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = os.path.join(A, f'm_{name}.png'); bpy.ops.render.render(write_still=True)
import sys
if '--envback' not in sys.argv:
    shoot('front', 0, 8.6, 5.4); shoot('tq', -35, 8.6, 5.4); shoot('side', 90, 8.6, 5.4); shoot('back', 180, 8.6, 5.4)
shoot('env_front', 0, 8.6, 5.4, env=True); shoot('env_tq', -35, 8.6, 5.4, env=True); shoot('env_side', 90, 8.6, 5.4, env=True)
shoot('env_back', 180, 8.3, 5.4, env=True); shoot('env_backq', 215, 8.0, 5.0, env=True)
shoot('mus_backq', 215, 8.0, 5.0)
print('ok')
