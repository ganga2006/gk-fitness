"""Écorché check: fitted muscles on the skeleton, with a ghost of the trainer's skin."""
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np, bpy
from mathutils import Vector
from PIL import Image
import fit
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'renders'); os.makedirs(OUT, exist_ok=True)
SHOW_ENV = '--envelope' in sys.argv
bpy.ops.wm.open_mainfile(filepath=os.path.join(HERE, 'anatomy.blend'))
with bpy.data.libraries.load(os.path.join(fit.MH, 'mh_base.blend')) as (src, dst):
    dst.objects = ['Body']
body = dst.objects[0]; bpy.context.scene.collection.objects.link(body); body.modifiers.clear()
co = fit.stretch_arms(np.array([v.co[:] for v in body.data.vertices]))
body.data.vertices.foreach_set('co', co.astype(np.float32).ravel()); body.data.update()
env = bpy.data.objects.get('Envelope')
mus = list(bpy.data.collections['Muscles'].objects)
bones = list(bpy.data.collections['Skeleton'].objects)
TINT = {'pectoralis major': (0.78, 0.16, 0.14), 'deltoid': (0.80, 0.30, 0.16), 'serratus': (0.70, 0.22, 0.30),
        'oblique': (0.62, 0.20, 0.22), 'rectus': (0.74, 0.20, 0.18), 'latissimus': (0.58, 0.14, 0.16),
        'trapezius': (0.70, 0.24, 0.20), 'pectoralis minor': (0.55, 0.12, 0.12)}
for o in mus:
    o.color = (*next((c for k, c in TINT.items() if k in o.name), (0.60, 0.18, 0.16)), 1)
for o in bones:
    o.color = (0.66, 0.74, 0.80, 1) if 'cartilage' in o.name else (0.86, 0.80, 0.66, 1)
body.color = (0.82, 0.62, 0.52, 1)
if env:
    env.color = (0.80, 0.60, 0.50, 1)
sc = bpy.context.scene
sc.render.engine = 'BLENDER_WORKBENCH'; sc.render.film_transparent = True
sh = sc.display.shading
sh.light = 'STUDIO'; sh.color_type = 'OBJECT'; sh.show_cavity = True; sh.cavity_type = 'BOTH'
sh.curvature_ridge_factor = 1.0; sh.curvature_valley_factor = 1.2
cd = bpy.data.cameras.new('C'); cd.lens = 90
cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
def shoot(path, az, target, dist, lift, res):
    sc.render.resolution_x, sc.render.resolution_y = res
    a = math.radians(az)
    cam.location = Vector((math.cos(a) * dist, math.sin(a) * dist, target.z + lift))
    cam.rotation_euler = (target - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = path; bpy.ops.render.render(write_still=True)
def view(name, az, target, dist, lift=0.4, res=(720, 720), ghost=0.22):
    solid = ([env] if SHOW_ENV else mus + bones)
    for o in bpy.data.objects:
        if o.type == 'MESH': o.hide_render = o not in solid
    shoot('/tmp/a.png', az, target, dist, lift, res)
    for o in bpy.data.objects:
        if o.type == 'MESH': o.hide_render = o is not body
    shoot('/tmp/b.png', az, target, dist, lift, res)
    bg = Image.new('RGBA', res, (22, 25, 31, 255))
    bd = Image.open('/tmp/b.png').convert('RGBA'); bd.putalpha(bd.split()[3].point(lambda v: int(v * ghost)))
    bg = Image.alpha_composite(Image.alpha_composite(bg, bd), Image.open('/tmp/a.png').convert('RGBA'))
    bg.convert('RGB').save(os.path.join(OUT, f'{"env" if SHOW_ENV else "mus"}_{name}.png')); print('rendered', name)
chest = Vector((0.2, 0, 8.7))
view('front', 0, chest, 19)
view('34', -40, chest, 19, 0.6)
view('side', 90, chest, 19)
view('back', 180, chest, 19)
