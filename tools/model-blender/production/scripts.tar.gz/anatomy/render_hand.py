import bpy, math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/GKFitness_Trainer_Production.blend')
sc = bpy.context.scene; sc.render.engine = 'CYCLES'; sc.cycles.samples = 24; sc.cycles.use_denoising = True; sc.render.resolution_x, sc.render.resolution_y = 500, 500
w = bpy.data.worlds.new('W'); w.use_nodes = True; w.node_tree.nodes['Background'].inputs[0].default_value = (0.4, 0.42, 0.45, 1); sc.world = w
rig = bpy.data.objects['Rig']; a = bpy.data.actions['Idle_Neutral']; rig.animation_data.action = a; rig.animation_data.action_slot = a.slots[0]; sc.frame_set(1)
pb = rig.pose.bones['hand_l']; t = rig.matrix_world @ pb.tail
cd = bpy.data.cameras.new('C'); cd.lens = 60; cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
for nm, off in (('hand_out', Vector((0.6, 3.5, 0.3))), ('hand_front', Vector((3.5, 0.8, 0.3)))):
    cam.location = t + off; cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z', 'Y').to_euler()
    sc.render.filepath = f'/home/claude/mh/inspect/{nm}.png'; bpy.ops.render.render(write_still=True)
