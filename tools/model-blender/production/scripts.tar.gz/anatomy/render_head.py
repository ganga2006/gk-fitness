import bpy, math, sys
from mathutils import Vector
f = sys.argv[sys.argv.index('--')+1]; tag = sys.argv[sys.argv.index('--')+2]
bpy.ops.wm.open_mainfile(filepath=f); sc = bpy.context.scene
mat = bpy.data.materials.new('clay'); mat.use_nodes = True
b = mat.node_tree.nodes['Principled BSDF']; b.inputs['Base Color'].default_value = (0.62,0.50,0.43,1); b.inputs['Roughness'].default_value = 0.5
for o in bpy.data.objects:
    if o.type == 'MESH':
        if o.name == 'Body':
            sk = bpy.data.materials.new('skin'); sk.use_nodes = True; bs = sk.node_tree.nodes['Principled BSDF']
            bs.inputs['Base Color'].default_value = (0.515, 0.281, 0.196, 1); bs.inputs['Roughness'].default_value = 0.48
            bs.inputs['Subsurface Weight'].default_value = 0.25; bs.inputs['Subsurface Radius'].default_value = (1.0, 0.35, 0.2)
            bs.inputs['Subsurface Scale'].default_value = 0.02
            if '--keep' not in sys.argv: o.data.materials.clear(); o.data.materials.append(sk if '--skin' in sys.argv else mat)
sc.render.engine = 'CYCLES'; sc.cycles.samples = 48; sc.cycles.use_denoising = True; sc.render.resolution_x, sc.render.resolution_y = 420, 500
w = bpy.data.worlds.new('W'); w.use_nodes = True; w.node_tree.nodes['Background'].inputs[0].default_value = (0.05,0.06,0.08,1); sc.world = w
def L(n, e, s):
    d = bpy.data.lights.new(n, 'AREA'); d.energy = e; d.size = s; o = bpy.data.objects.new(n, d); sc.collection.objects.link(o); return o
key, fill, rim = L('k', 900, 2.5), L('f', 220, 4), L('r', 600, 2.5)
cd = bpy.data.cameras.new('C'); cd.lens = 85; cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
t = Vector((0.45, 0, 11.0))
def aim(o, p): o.location = p; o.rotation_euler = (t - p).normalized().to_track_quat('-Z','Y').to_euler()
VIEWS = [('front', 0), ('tq', -38), ('side', -90), ('tql', 35)] if '--mouth' not in sys.argv else [('mouth', -20), ('mouthside', -90)]
if '--mouth' in sys.argv: t = Vector((1.0, 0, 10.85))
for nm, az in VIEWS:
    a = math.radians(az); D_ = 2.4 if '--mouth' in sys.argv else 6.2; aim(cam, t + Vector((math.cos(a)*D_, math.sin(a)*D_, 0.15)))
    aim(key, t + Vector((math.cos(a-0.7)*5, math.sin(a-0.7)*5, 3.5))); aim(fill, t + Vector((math.cos(a+0.9)*5, math.sin(a+0.9)*5, 0.5)))
    aim(rim, t + Vector((math.cos(a+2.6)*5, math.sin(a+2.6)*5, 2.5)))
    sc.render.filepath = f'/home/claude/mh/inspect/head_{tag}_{nm}.png'; bpy.ops.render.render(write_still=True)
