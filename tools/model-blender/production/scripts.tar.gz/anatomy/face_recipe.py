"""Handsome male face: weighted blend of CC0 MakeHuman face-detail morphs -> one offset field."""
import bpy, numpy as np, os
SRC = '/tmp/claude-0/-home-claude/e6b57e36-289f-59ea-995f-25b1be937a96/scratchpad/mht'
RECIPE = {
 'nose_nose-scale-depth-incr': 0.80, 'nose_nose-scale-vert-incr': 0.05, 'nose_nose-scale-horiz-decr': 0.30,
 'nose_nose-point-width-decr': 0.55, 'nose_nose-nostrils-width-decr': 0.35, 'nose_nose-hump-decr': 0.50,
 'nose_nose-width1-decr': 0.35, 'nose_nose-greek-incr': 0.15,
 'mouth_mouth-upperlip-volume-incr': 0.0, 'mouth_mouth-lowerlip-volume-incr': 0.0, 'mouth_mouth-cupidsbow-incr': 0.35,
 'mouth_mouth-philtrum-volume-incr': 0.25, 'mouth_mouth-scale-horiz-incr': 0.55, 'mouth_mouth-upperlip-height-incr': 0.15,
 'chin_chin-prominent-incr': 0.30, 'chin_chin-width-incr': 0.30, 'chin_chin-height-incr': 0.0, 'chin_chin-cleft-incr': 0.25,
 'cheek_l-cheek-bones-incr': 0.85, 'cheek_r-cheek-bones-incr': 0.85, 'cheek_l-cheek-inner-decr': 0.45, 'cheek_r-cheek-inner-decr': 0.45,
 'eyes_l-eye-corner2-up': 0.60, 'eyes_r-eye-corner2-up': 0.60, 'eyes_l-eye-height2-incr': 0.20, 'eyes_r-eye-height2-incr': 0.20,
 'eyes_l-eye-scale-incr': 0.25, 'eyes_r-eye-scale-incr': 0.25,
 'eyebrows_eyebrows-trans-down': 0.55, 'eyebrows_eyebrows-angle-down': 0.20,
 'forehead_forehead-scale-vert-decr': 0.20, 'head_head-square': 0.50, 'head_head-age-decr': 0.25,
 'neck_neck-scale-horiz-incr': 0.30,
 'mouth_mouth-trans-up': 1.00, 'nose_nose-trans-up': 0.70, 'mouth_mouth-angles-up': 0.25, 'mouth_mouth-lowerlip-height-decr': 0.35,
}
verts, faces, group = [], [], None
for line in open('/home/claude/mh/base.obj'):
    if line.startswith('v '): verts.append([float(x) for x in line.split()[1:4]])
    elif line.startswith('g '): group = line[2:].strip()
    elif line.startswith('f ') and group == 'body': faces.append([int(t.split('/')[0]) - 1 for t in line.split()[1:]])
verts = np.array(verts); used = sorted({i for f in faces for i in f}); remap = {v: n for n, v in enumerate(used)}
s = 12.0 / (verts[used, 1].max() - verts[used, 1].min())
D = np.zeros((len(used), 3))
for name, w in RECIPE.items():
    for line in open(os.path.join(SRC, name + '.target')):
        if line.startswith('#') or not line.strip(): continue
        p = line.split(); i = int(p[0])
        if i in remap:
            dx, dy, dz = map(float, p[1:4]); D[remap[i]] += w * np.array((dz * s, dx * s, dy * s))
me = bpy.data.meshes.new('d'); me.from_pydata(D.tolist(), [], [[remap[i] for i in f] for f in faces]); me.update()
ob = bpy.data.objects.new('d', me); bpy.context.scene.collection.objects.link(ob); bpy.context.view_layer.objects.active = ob
m = ob.modifiers.new('s', 'SUBSURF'); m.levels = 1; bpy.ops.object.modifier_apply(modifier='s')
out = np.array([v.co for v in ob.data.vertices]); np.save('/home/claude/mh/anatomy/face_recipe.npy', out)
print('face recipe:', len(RECIPE), 'morphs, max offset %.1f mm' % (np.abs(out).max() * 147.4))
