import bpy, math, sys
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='/home/claude/mh/anatomy/body_anatomy.blend')
with bpy.data.libraries.load('/home/claude/mh/mh_shaped.blend') as (s, d): d.objects = ['Body']
body = d.objects[0]; bpy.context.scene.collection.objects.link(body)
sc = bpy.context.scene; sc.render.engine = 'BLENDER_WORKBENCH'; sc.render.resolution_x, sc.render.resolution_y = 500, 900
sh = sc.display.shading; sh.light = 'STUDIO'; sh.color_type = 'OBJECT'; sh.show_cavity = True; sh.cavity_type = 'BOTH'
w = bpy.data.worlds.new('W'); sc.world = w; w.color = (0.06, 0.07, 0.09)
for o in bpy.data.objects:
    if o.type == 'MESH': o.color = (0.93,0.89,0.80,1) if o.name.startswith('bone') else (0.72,0.13,0.11,1) if o.name.startswith('mus') else (0.8,0.66,0.57,1)
cd = bpy.data.cameras.new('C'); cd.lens = 60; cam = bpy.data.objects.new('C', cd); sc.collection.objects.link(cam); sc.camera = cam
def shoot(n, az):
    a = math.radians(az); t = Vector((0.2, 0, 6.0)); cam.location = Vector((math.cos(a)*30, math.sin(a)*30, 6.4))
    cam.rotation_euler = (t - cam.location).normalized().to_track_quat('-Z','Y').to_euler()
    sc.render.filepath = f'/home/claude/mh/anatomy/full_{n}.png'; bpy.ops.render.render(write_still=True)
for mode in ('skel', 'mus', 'skin'):
    for o in bpy.data.objects:
        if o.type != 'MESH': continue
        o.hide_render = not ((mode == 'skel' and o.name.startswith('bone')) or (mode == 'mus' and o.name[:3] in ('mus', 'bon')) or (mode == 'skin' and o == body))
    for nm, az in (('front', 0), ('side', 90), ('back', 180)): shoot(f'{mode}_{nm}', az)
