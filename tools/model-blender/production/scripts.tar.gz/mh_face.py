"""
GK Fitness — lay the face onto the fitted skull + facial muscles.
Lean gym-trainer tissue depths (forensic facial-reconstruction tables, adult
male, reduced for low body fat) give the slim face, cheekbones and a defined
jawline. Eyes, nose, lips and ears keep their own sculpted forms, blended in.
"""
import bpy, bmesh, json, os, math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped_body_v4.blend'))
with bpy.data.libraries.load(os.path.join(OUT, 'anatomy', 'face_envelope.blend')) as (s, d): d.objects = ['FaceEnvelope']
env = d.objects[0]; body = bpy.data.objects['Body']
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
tree = BVHTree.FromPolygons([v.co.copy() for v in env.data.vertices], [p.vertices[:] for p in env.data.polygons])
def sm(t): t = max(0.0, min(1.0, t)); return t*t*(3-2*t)
EL, ER = J['l-eye'], J['r-eye']
import numpy as _np
LM = _np.load(os.path.join(OUT, 'anatomy', 'lip_masks.npy'))
def lip_centres(verts):
    up = [v.co for v in verts if LM[v.index, 0] > 0.5]; lo = [v.co for v in verts if LM[v.index, 1] > 0.5]
    zu = sum(p.z for p in up) / len(up); zl = sum(p.z for p in lo) / len(lo)
    xf = max(p.x for p in up + lo)
    return zu, zl, xf
_zu, _zl, _xf = lip_centres(body.data.vertices)
_sz = (_zu + _zl) / 2
MO = Vector((_xf - 0.10, 0.0, _sz))      # the real mouth line, from MakeHuman's own lip regions
print('mouth line measured at z %.3f' % _sz)
E = (EL + ER) / 2; MM = 1 / 147.4                      # one millimetre in scene units

def keep(c):
    """1 where the original feature is kept (eyes, nose, lips, ears)"""
    k = 0.0
    for e in (EL, ER):
        k = max(k, 1 - sm(((c - e).length - 0.17) / 0.12))                         # eyelids + socket
    ny = abs(c.y); nz = c.z
    if c.x > E.x - 0.05:                                                            # nose
        k = max(k, sm((0.17 - ny) / 0.07) * sm((E.z - 0.04 - nz) / 0.06) * sm((nz - (MO.z + 0.10)) / 0.06))
    lip = math.hypot((c.y) / 0.30, (c.z - MO.z) / 0.13)
    if c.x > MO.x - 0.25: k = max(k, 1 - sm((lip - 0.85) / 0.35))                  # lips
    return k
def bump(x, c, w): return math.exp(-((x - c) / w) ** 2)
def tissue(c):
    """lean adult-male soft-tissue depth (mm), one smooth function of position"""
    rz = c.z - E.z; ay = abs(c.y); front = sm((c.x - (E.x - 0.55)) / 0.25)
    t = 5.5
    t += 2.5 * bump(rz, -0.30, 0.12) * bump(ay, 0.40, 0.12) * front          # mid-cheek, lean: slight hollow below the cheekbone
    t += 3.5 * bump(c.z, MO.z - 0.30, 0.10) * bump(ay, 0.0, 0.18) * front    # chin pad
    t += 4.0 * bump(c.z, MO.z + 0.13, 0.08) * bump(ay, 0.0, 0.16) * front    # upper lip / philtrum
    t += 1.5 * bump(c.z, 10.30, 0.12) * (1 - front * 0.5)                    # under the jaw
    t += 2.0 * sm((10.25 - c.z) / 0.15)                                      # upper neck
    t -= 0.5 * bump(rz, 0.30, 0.12)                                          # forehead
    return t
bm = bmesh.new(); bm.from_mesh(body.data); bm.verts.ensure_lookup_table(); bm.normal_update()
def safe(c):
    """regions where skin lies on bone or chewing muscle: sample the skull depth here only"""
    if keep(c) > 0.02: return False
    if (c - MO).length < 0.36 and c.x > MO.x - 0.2: return False
    if (c - MO).length < 0.42 and c.x > MO.x - 0.3: return False                 # whole mouth area
    if abs(c.y) > 0.50 and abs(c.z - (E.z - 0.15)) < 0.30 and c.x < E.x - 0.45: return False   # ears
    return c.z > 10.02
# 1) robust samples on a sparse grid
samples = []; taken = []
for v in bm.verts:
    c = v.co
    if not safe(c) or any((c - t).length < 0.055 for t in taken[-60:]): continue
    n = v.normal
    hits = [h for h in (tree.ray_cast(c, n, 0.25), tree.ray_cast(c, -n, 0.25)) if h[0] is not None and h[1].dot(n) * (1 if h[0].dot(n) else 1) and abs(h[1].dot(n)) > 0.5]
    if not hits: continue
    h = min(hits, key=lambda h: h[3])
    hn = h[1] if h[1].dot(n) > 0 else -h[1]
    if hn.dot(n) < 0.5: continue
    d = (h[0] + hn * tissue(c) * MM) - c
    if d.length > 0.18: continue
    samples.append((c.copy(), d)); taken.append(c.copy())
# 2) outlier rejection: each sample must agree with its neighbours
clean = []
for i, (p, d) in enumerate(samples):
    nb = [dd for q, dd in samples if (q - p).length < 0.16]
    avg = sum(nb, Vector()) / len(nb)
    if (d - avg).length < 0.035: clean.append((p, d))
print('skull depth samples:', len(samples), 'kept', len(clean))
# 3) one smooth field over the whole head (features ride along unchanged)
SIG2 = 0.14 ** 2
FIELD = {}
for v in bm.verts:
    c = v.co
    if c.z < 9.85: continue
    num = Vector(); den = 0.0
    for p, d in clean:
        r2 = (c - p).length_squared
        if r2 > 9 * SIG2: continue
        w = math.exp(-r2 / SIG2); num += d * w; den += w
    if den < 1e-4: continue
    conf = min(1.0, den / 0.6)
    FIELD[v.index] = (num / den) * conf * sm((c.z - 9.88) / 0.28) * (1 - sm(LM[v.index].max() * 3.0))   # lips blend out smoothly
# blur the field over the surface itself: no ridge at the jaw's back edge, ears or neck
for _ in range(14):
    new = {}
    for i, dd in FIELD.items():
        v = bm.verts[i]; nb = [FIELD.get(e.other_vert(v).index, Vector()) for e in v.link_edges]
        new[i] = (dd * 2 + sum(nb, Vector())) / (2 + len(nb))
    FIELD = new
for i, dd in FIELD.items(): bm.verts[i].co += dd
print(f'face reshaped from {len(clean)} skull-depth samples')
bm.to_mesh(body.data); bm.free(); body.data.update()
for o in list(bpy.data.objects):
    if o.name == 'FaceEnvelope': bpy.data.objects.remove(o)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend (face on skull)')
