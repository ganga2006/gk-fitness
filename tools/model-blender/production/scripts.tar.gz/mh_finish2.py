"""
GK Fitness — finish (anatomy-based body): muscle-region materials carrying the
realistic skin (procedural in Blender + a baked albedo texture for the app),
and contraction shape keys. No normal-map grooves: the anatomy is real geometry now.
"""
import bpy, bmesh, json, os
from mathutils import Vector
OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
low = bpy.data.objects['Body']
for nm in ('Brows',):
    if nm in bpy.data.objects: bpy.data.objects.remove(bpy.data.objects[nm])
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
exec('#' + open(os.path.join(OUT, 'mh_finish.py')).read().split('# ── muscle regions')[1].split('low.data.materials.clear()')[0])
SHO, ELB, HND = J['l-shoulder'], J['l-elbow'], J['l-hand']; KNE, ANK = J['l-knee'], J['l-ankle']; HIPJ = J['l-upper-leg']; ARM_Y = SHO.y - 0.22

# 1) bake the procedural skin colour to a texture (the app cannot run Blender nodes)
skin = bpy.data.materials['skin_real']
img = bpy.data.images.new('skin_albedo', 2048, 2048, alpha=False)
tex = skin.node_tree.nodes.new('ShaderNodeTexImage'); tex.image = img; skin.node_tree.nodes.active = tex
sc = bpy.context.scene; sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 1
sc.render.bake.use_pass_direct = False; sc.render.bake.use_pass_indirect = False; sc.render.bake.use_pass_color = True
sc.render.bake.margin = 8
for o in bpy.data.objects: o.select_set(o == low)
bpy.context.view_layer.objects.active = low
bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'})
img.filepath_raw = os.path.join(OUT, 'skin_albedo.png'); img.file_format = 'PNG'; img.save()
print('skin albedo baked')
# 2) per-region materials = the realistic skin with the baked colour driving Base Color
bs = skin.node_tree.nodes['Principled BSDF']
for l in list(bs.inputs['Base Color'].links): skin.node_tree.links.remove(l)
skin.node_tree.links.new(tex.outputs['Color'], bs.inputs['Base Color'])
low.data.materials.clear()
for g in GROUPS:
    m = skin.copy(); m.name = g; low.data.materials.append(m)
slot = {g: i for i, g in enumerate(GROUPS)}
counts = {}
for p in low.data.polygons:
    g = classify(p.center, p.normal); p.material_index = slot[g]; counts[g] = counts.get(g, 0) + 1
print('regions:', len(counts))
# 3) contraction shape keys
FLEX = {'flexArms': ['biceps', 'triceps', 'forearms', 'shoulders'], 'flexChest': ['chest', 'serratus', 'traps', 'lats', 'upperBack'],
        'flexAbs': ['abs', 'obliques', 'lowerBack', 'hipFlexors'], 'flexLegs': ['quads', 'hamstrings', 'glutes', 'calves', 'adductors', 'tibialis']}
vg = {}
for p in low.data.polygons:
    for vi in p.vertices: vg.setdefault(vi, GROUPS[p.material_index])
nrm = {v.index: v.normal.copy() for v in low.data.vertices}
if low.data.shape_keys: low.shape_key_clear()
low.shape_key_add(name='Basis', from_mix=False)
for key, members in FLEX.items():
    sk = low.shape_key_add(name=key, from_mix=False); ms = set(members)
    for i, p in enumerate(sk.data):
        if vg.get(i) in ms: p.co = p.co + nrm[i] * 0.045
for kb in low.data.shape_keys.key_blocks[1:]:
    kb.value = 0.0                      # contraction shapes are OFF at rest; the app/actions drive them
print('shape keys:', [(k.name, k.value) for k in low.data.shape_keys.key_blocks])
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_final.blend'))
print('saved mh_final.blend')
