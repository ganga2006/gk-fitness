"""
GK Fitness — lay the whole body's skin onto the fitted real anatomy.
Head, hands, feet and groin keep their own surface (handled separately);
everything else lies on bone + athletically thickened muscle with a thin,
region-dependent skin layer.
"""
import bpy, bmesh, json, os, math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped_pre_fullwrap.blend'))
with bpy.data.libraries.load(os.path.join(OUT, 'anatomy', 'body_envelope.blend')) as (s, d): d.objects = ['Envelope', 'EnvelopeDetail']
env, envd = d.objects[0], d.objects[1]; body = bpy.data.objects['Body']
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
tree = BVHTree.FromPolygons([v.co.copy() for v in env.data.vertices], [p.vertices[:] for p in env.data.polygons])
treed = BVHTree.FromPolygons([v.co.copy() for v in envd.data.vertices], [p.vertices[:] for p in envd.data.polygons])
def sm(t): t = max(0.0, min(1.0, t)); return t*t*(3-2*t)
def seg_t(co, a, b):
    ab = b - a; t = (co - a).dot(ab) / ab.length_squared; return t, (co - (a + ab*max(0,min(1,t)))).length
def side(k, s): p = J[f'l-{k}']; return Vector((p.x, p.y if s > 0 else -p.y, p.z)) if f'r-{k}' not in J else J[f'{"l" if s>0 else "r"}-{k}']

def weight(c):
    w = sm((10.42 - c.z) / 0.30)                          # head excluded (neck kept)
    for s in (1, -1):
        sd = 'l' if s > 0 else 'r'
        t, d = seg_t(c, J[f'{sd}-elbow'], J[f'{sd}-hand'])
        if d < 0.6:  w *= 1 - sm((t - 0.80) / 0.15)        # wrist -> hand fade
        th, dh = seg_t(c, J[f'{sd}-hand'], J[f'{sd}-finger-3-4'])
        if dh < 0.42 and th > -0.05: w = 0.0                # the hand itself is untouched
        t, d = seg_t(c, J[f'{sd}-knee'], J[f'{sd}-ankle'])
        if d < 0.8: w *= 1 - sm((t - 0.86) / 0.14)        # foot/ankle kept
        if c.z < J[f'{sd}-ankle'].z + 0.2 and abs(c.y - J[f'{sd}-ankle'].y) < 0.8: w = 0.0
        for off in ((-0.08, -0.14, -0.42), (-0.40, -0.12, -0.48)):
            ax = J[f'{sd}-shoulder'] + Vector((off[0], off[1]*s, off[2]))
            w *= sm(((c - ax).length - 0.18) / 0.50)       # armpit + back fold keep a smooth hollow
    return w
def zone(c):
    """places where skin bridges a hollow instead of lying on muscle"""
    z = 0.0
    for s in (1, -1):
        sd = 'l' if s > 0 else 'r'
        for off, r in (((-0.05, -0.15, -0.40), 0.78), ((-0.42, -0.10, -0.45), 0.72), ((0.30, -0.12, -0.42), 0.58)):
            ax = J[f'{sd}-shoulder'] + Vector((off[0], off[1]*s, off[2]))
            z = max(z, sm(1 - (c - ax).length / r))                      # armpit: centre, back fold, front fold
        t, d = seg_t(c, J[f'{sd}-elbow'], J[f'{sd}-hand'])
        if d < 0.6: z = max(z, sm(1 - abs(t - 0.82) / 0.12) * 0.7)       # wrist blend
        z = max(z, sm(1 - abs(c.z - (J[f'{sd}-ankle'].z + 0.35)) / 0.25) * 0.6 * (abs(c.y - J[f'{sd}-ankle'].y) < 0.8))
    if abs(c.y) < 0.55 and 5.0 < c.z < 6.6: z = max(z, sm(1 - abs(c.y) / 0.55) * sm(1 - abs(c.z - 5.8) / 0.8))  # groin
    z = max(z, sm(1 - abs(c.z - 10.35) / 0.22))                          # neck -> head
    return z
def abs_w(c):
    front = sm(1 - abs(c.z - 7.55) / 1.0) * sm((0.62 - abs(c.y)) / 0.18) * sm((c.x - 0.30) / 0.25)
    back = 0.75 * sm(1 - abs(c.z - 8.4) / 1.5) * sm((1.15 - abs(c.y)) / 0.25) * sm((-0.05 - c.x) / 0.25)
    chest = 0.35 * sm(1 - abs(c.z - 9.0) / 0.6) * sm((1.0 - abs(c.y)) / 0.2) * sm((c.x - 0.5) / 0.3)
    return max(front, back, chest)
def skin_thickness(c):
    for sd in ('l', 'r'):
        if (c - J[f'{sd}-ankle']).length < 0.75 and c.z < J[f'{sd}-ankle'].z + 0.75: return 0.048   # fuller ankles
    if abs(c.y) < 0.5 and 5.2 < c.z < 6.4 and c.x > -0.1: return 0.090   # groin fill (under briefs)
    if 9.75 < c.z < 10.45 and abs(c.y) < 0.6: return 0.040              # neck: soft over the cords
    if c.z < 6.9 and c.x < 0.0 and c.z > 5.2: return 0.060   # glutes carry more fat
    if 6.4 < c.z < 7.6 and abs(c.y) > 0.75: return 0.022         # lean flanks: no love handles
    if 6.6 < c.z < 8.0 and c.x > 0.2: return 0.030           # abdomen (lean)
    return 0.032

bm = bmesh.new(); bm.from_mesh(body.data); bm.verts.ensure_lookup_table()
mask = {v.index: w for v in bm.verts if (w := weight(v.co)) > 1e-3}
print('verts wrapped:', len(mask), 'of', len(bm.verts))
for _ in range(16):                                         # relax away the old fake shapes
    mv = {}
    for i, w in mask.items():
        v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
        mv[i] = (sum(ring, Vector())/len(ring) - v.co) * 0.5 * w
    for i, dd in mv.items(): bm.verts[i].co += dd
bm.normal_update()
disp, miss, far, detail = {}, 0, 0, {}
for i, w in mask.items():
    v = bm.verts[i]; n = v.normal
    hits = [h for h in (tree.ray_cast(v.co, n, 0.7), tree.ray_cast(v.co, -n, 0.7)) if h[0] is not None and abs(h[1].dot(n)) > 0.35]
    if not hits:
        miss += 1; continue
    h = min(hits, key=lambda h: h[3]); hn = h[1] if h[1].dot(n) > 0 else -h[1]
    disp[i] = (h[0] + hn * skin_thickness(v.co)) - v.co
    aw = abs_w(v.co)
    if aw > 0:
        hd = [x for x in (treed.ray_cast(v.co, n, 0.7), treed.ray_cast(v.co, -n, 0.7)) if x[0] is not None and abs(x[1].dot(n)) > 0.35]
        if hd:
            x = min(hd, key=lambda x: x[3]); xn = x[1] if x[1].dot(n) > 0 else -x[1]
            detail[i] = ((x[0] + xn * 0.022) - v.co, aw)
    if h[3] > 0.45: far += 1
print('projected', len(disp), 'missed', miss, 'moved >0.45', far)
for it_ in range(5):
    new = {}
    for i, dd in disp.items():
        v = bm.verts[i]; nb = [disp[e.other_vert(v).index] for e in v.link_edges if e.other_vert(v).index in disp]
        new[i] = (dd*2 + sum(nb, Vector())) / (2 + len(nb))
    disp = new
for i, (dd, aw) in detail.items():           # abs: keep the six-pack relief (1 light pass only)
    if i in disp: disp[i] = disp[i].lerp(dd, aw)
for i, dd in disp.items(): bm.verts[i].co += dd * mask[i]
# flank taper: a lean male's side line runs straight from ribs to hip, no pad above the iliac crest
for i, wgt in mask.items():
    v = bm.verts[i]; c = v.co
    if 6.25 < c.z < 7.45 and abs(c.y) > 0.55 and c.x > -0.6:
        k = sm(1 - abs(c.z - 6.80) / 0.55) * sm((abs(c.y) - 0.55) / 0.35) * wgt
        v.co.y -= math.copysign(0.11 * k, c.y)
# crease relaxer: any fold sharper than ~60 deg on torso/limbs is softened
for _ in range(3):
    bm.normal_update(); bad = set()
    for e in bm.edges:
        if len(e.link_faces) == 2 and e.link_faces[0].normal.angle(e.link_faces[1].normal) > math.radians(60):
            if all(v.index in mask for v in e.verts): bad.update(v.index for v in e.verts)
    grow = set(bad)
    for i in bad: grow.update(e.other_vert(bm.verts[i]).index for e in bm.verts[i].link_edges)
    for _ in range(4):
        mv = {}
        for i in grow:
            v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
            mv[i] = (sum(ring, Vector())/len(ring) - v.co) * 0.5
        for i, dd in mv.items(): bm.verts[i].co += dd
print('crease verts relaxed (last pass):', len(bad))
for _ in range(10):                                         # spike guard
    mv = {}
    for i in mask:
        v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
        avg = sum(ring, Vector())/len(ring); edge = sum((p - v.co).length for p in ring)/len(ring)
        if (v.co - avg).length > 0.45 * edge: mv[i] = (avg - v.co) * 0.8
    for i, dd in mv.items(): bm.verts[i].co += dd
for _ in range(3):                                          # settle the blend borders
    mv = {}
    for i, w in mask.items():
        if 0.05 < w < 0.95:
            v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
            mv[i] = (sum(ring, Vector())/len(ring) - v.co) * 0.4
    for i, dd in mv.items(): bm.verts[i].co += dd
# forearms: extra smoothing of the surface (flexor/extensor bellies, no ropey ridges)
FA = [v.index for v in bm.verts if v.index in mask and any(0.15 < seg_t(v.co, J[f'{s}-elbow'], J[f'{s}-hand'])[0] < 0.85 and seg_t(v.co, J[f'{s}-elbow'], J[f'{s}-hand'])[1] < 0.5 for s in ('l', 'r'))]
for _ in range(6):
    mv = {}
    for i in FA:
        v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]; mv[i] = (sum(ring, Vector())/len(ring) - v.co) * 0.45
    for i, dd in mv.items(): bm.verts[i].co += dd
# bridge the hollows: armpits, groin, wrists, ankles, neck->head
Z = {v.index: zz for v in bm.verts if (zz := zone(v.co)) > 1e-3}
for _ in range(26):
    mv = {}
    for i, zz in Z.items():
        v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
        mv[i] = (sum(ring, Vector())/len(ring) - v.co) * 0.5 * zz
    for i, dd in mv.items(): bm.verts[i].co += dd
print('bridged hollow verts:', len(Z))
bm.to_mesh(body.data); bm.free(); body.data.update()
for o in list(bpy.data.objects):
    if o.name == 'Envelope': bpy.data.objects.remove(o)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend (full-body anatomy wrap)')
