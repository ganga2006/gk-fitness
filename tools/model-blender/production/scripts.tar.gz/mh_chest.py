"""
GK Fitness — rebuild the chest on real anatomy (skeleton first, then muscle).

The skin of the chest region is relaxed flat (removing the old hand-placed pec
plates and the breast-like nipple folds), then laid onto the fused anatomy
envelope — real ribcage, sternum, clavicles and athletically thickened
pectoralis major / front deltoid / serratus / rectus from BodyParts3D — with a
thin, even layer of skin on top.
"""
import bpy, bmesh, json, math, os
from mathutils import Vector
from mathutils.bvhtree import BVHTree
OUT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(OUT, 'mh_shaped_before_chest.blend')
bpy.ops.wm.open_mainfile(filepath=SRC)
with bpy.data.libraries.load(os.path.join(OUT, 'anatomy', 'chest_envelope.blend')) as (s, d):
    d.objects = ['Envelope']
env = d.objects[0]
body = bpy.data.objects['Body']
# one Catmull-Clark level: the 13k-vert base has ~600 verts across the chest,
# far too few to hold a pectoral border; 4x the density can.
bpy.context.view_layer.objects.active = body
for o in bpy.context.view_layer.objects: o.select_set(o == body)
sd = body.modifiers.new('sub', 'SUBSURF'); sd.levels = 1; sd.render_levels = 1
for m in list(body.modifiers):
    if m.name != 'sub': body.modifiers.move(body.modifiers.find('sub'), 0); break
bpy.ops.object.modifier_apply(modifier='sub')
print('body verts after subdivision:', len(body.data.vertices))
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
SKIN = 0.032                                   # ~5 mm: lean trainer

em = env.data
tree = BVHTree.FromPolygons([v.co.copy() for v in em.vertices], [p.vertices[:] for p in em.polygons])

def sm(t): t = max(0.0, min(1.0, t)); return t * t * (3 - 2 * t)
def arm_dist(co):
    best = 9.0
    for s in (1, -1):
        a = Vector((J['l-shoulder'].x, J['l-shoulder'].y * s, J['l-shoulder'].z))
        b = Vector((J['l-elbow'].x, J['l-elbow'].y * s, J['l-elbow'].z))
        ab = b - a; t = max(0.0, min(1.0, (co - a).dot(ab) / ab.length_squared))
        best = min(best, (co - (a + ab * t)).length)
    return best

bm = bmesh.new(); bm.from_mesh(body.data); bm.verts.ensure_lookup_table(); bm.normal_update()
mask = {}
for v in bm.verts:
    c = v.co
    w = sm((c.z - 7.70) / 0.40) * sm((9.92 - c.z) / 0.22)        # costal margin .. clavicles
    w *= sm((c.x - 0.05) / 0.35)                                  # front of the torso
    w *= sm((arm_dist(c) - 0.30) / 0.32)                          # fade before the arm
    w *= sm((1.32 - abs(c.y)) / 0.20)
    if w > 1e-3: mask[v.index] = w
print('chest verts in region:', len(mask))

# 1) relax the old shape flat (kills plates, folds and the nipple spikes)
for _ in range(24):
    mv = {}
    for i, w in mask.items():
        v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
        avg = sum(ring, Vector()) / len(ring)
        mv[i] = (avg - v.co) * 0.5 * w
    for i, d in mv.items(): bm.verts[i].co += d
bm.normal_update()

# 2) lay the skin onto the anatomy along each vertex's own normal
disp, miss = {}, 0
for i, w in mask.items():
    v = bm.verts[i]; n = v.normal
    hits = [tree.ray_cast(v.co, n, 0.55), tree.ray_cast(v.co, -n, 0.55)]
    # only accept the anatomy's OUTER face (normal agreeing with the skin's)
    hits = [h for h in hits if h[0] is not None and abs(h[1].dot(n)) > 0.35]
    if hits:
        h = min(hits, key=lambda h: h[3]); loc, hn = h[0], h[1]
    else:
        loc, hn, _, dd = tree.find_nearest(v.co, 0.55) if tree.find_nearest(v.co, 0.55)[0] else (None,)*4
        if loc is None: miss += 1; continue
    if hn.dot(n) < 0: hn = -hn
    disp[i] = (loc + hn * SKIN) - v.co
print('projected', len(disp), 'missed', miss)

# 3) smooth the displacement so voxel noise never reaches the skin
for _ in range(3):
    new = {}
    for i, d in disp.items():
        v = bm.verts[i]
        nb = [disp[e.other_vert(v).index] for e in v.link_edges if e.other_vert(v).index in disp]
        new[i] = (d * 2 + sum(nb, Vector())) / (2 + len(nb))
    disp = new
for i, d in disp.items():
    bm.verts[i].co += d * mask[i]

# spike guard: nothing may stand far off its neighbours
for _ in range(6):
    mv = {}
    for i in mask:
        v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
        avg = sum(ring, Vector()) / len(ring)
        edge = sum((p - v.co).length for p in ring) / len(ring)
        if (v.co - avg).length > 0.45 * edge: mv[i] = (avg - v.co) * 0.8
    for i, d in mv.items(): bm.verts[i].co += d

# 4) one gentle pass to settle the blend border
for _ in range(3):
    mv = {}
    for i, w in mask.items():
        if 0.05 < w < 0.95:
            v = bm.verts[i]; ring = [e.other_vert(v).co for e in v.link_edges]
            mv[i] = (sum(ring, Vector()) / len(ring) - v.co) * 0.4
    for i, d in mv.items(): bm.verts[i].co += d
bm.to_mesh(body.data); bm.free(); body.data.update()
for o in list(bpy.data.objects):
    if o.name == 'Envelope': bpy.data.objects.remove(o)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend (chest rebuilt on anatomy)')
