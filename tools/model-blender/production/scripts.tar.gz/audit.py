"""Technical audit of the rigged Blender project."""
import bpy, bmesh, os, sys
from mathutils import Vector
OUT = os.path.dirname(os.path.abspath(__file__))
f = sys.argv[-1] if sys.argv[-1].endswith('.blend') else 'gkfitness_body_RIGGED.blend'
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, f))
print(f'=== AUDIT: {f} | Blender {bpy.app.version_string} ===\n')

for o in sorted(bpy.data.objects, key=lambda o: o.name):
    print(f'{o.name:10s} {o.type}')
    if o.type == 'ARMATURE':
        bones = o.data.bones
        print(f'   bones {len(bones)}')
        roots = [b.name for b in bones if not b.parent]
        print(f'   roots {roots}')
        for b in bones:
            if b.length < 0.02:
                print(f'   !! zero-length bone {b.name}')
    if o.type != 'MESH':
        continue
    me = o.data
    bm = bmesh.new(); bm.from_mesh(me)
    nonman_e = [e for e in bm.edges if not e.is_manifold]
    loose_v = [v for v in bm.verts if not v.link_faces]
    ngons = [p for p in me.polygons if len(p.vertices) > 4]
    tris = [p for p in me.polygons if len(p.vertices) == 3]
    print(f'   {len(me.vertices)} verts  {len(me.polygons)} faces '
          f'({len(tris)} tri, {len(ngons)} ngon)')
    print(f'   non-manifold edges {len(nonman_e)} | loose verts {len(loose_v)}')
    print(f'   materials {len(me.materials)}: '
          f'{", ".join(m.name for m in me.materials[:6])}'
          f'{" ..." if len(me.materials) > 6 else ""}')
    print(f'   uv layers {[l.name for l in me.uv_layers]}')
    sk = me.shape_keys
    print(f'   shape keys {[k.name for k in sk.key_blocks] if sk else "none"}')
    print(f'   vertex groups {len(o.vertex_groups)}')
    print(f'   modifiers {[(m.name, m.type) for m in o.modifiers]}')
    # weight sanity
    unweighted = 0
    for v in me.vertices:
        if sum(g.weight for g in v.groups) < 1e-4:
            unweighted += 1
    print(f'   verts with no armature weight: {unweighted}')
    bm.free()
    print()
