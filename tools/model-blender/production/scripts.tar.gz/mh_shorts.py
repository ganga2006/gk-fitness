"""
GK Fitness — training briefs.

The shorts are built from the body's own surface: the hip-to-mid-thigh faces are
duplicated, pushed out along their normals and closed at the hem, so they drape
on the figure exactly and deform with the same skinning.
"""
import bpy, bmesh, os
from mathutils import Vector

OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
body = bpy.data.objects['Body']
for o in [o for o in bpy.data.objects if o.name.startswith('Shorts')]:
    bpy.data.objects.remove(o)

Z_TOP, Z_HEM = 6.80, 5.55          # waistband and hem heights (briefs)
src = bmesh.new()
src.from_mesh(body.data)
src.faces.ensure_lookup_table(); src.normal_update()

keep = [f for f in src.faces if Z_HEM <= f.calc_center_median().z <= Z_TOP and abs(f.calc_center_median().y) < 1.55]   # torso + legs only (hands hang in this band)
print('shorts faces:', len(keep))

sh = bmesh.new()
vmap = {}
for f in keep:
    vs = []
    for v in f.verts:
        if v.index not in vmap:
            # flare the leg openings so the hem hangs instead of gripping
            t = max(0.0, min(1.0, (Z_TOP - v.co.z) / (Z_TOP - Z_HEM)))
            out = 0.060 + 0.035 * t * t
            vmap[v.index] = sh.verts.new(v.co + v.normal * out)
        vs.append(vmap[v.index])
    try:
        f2 = sh.faces.new(vs)
        # level the hem as the shell is built, so the edge reads straight
        for v2 in f2.verts:
            if v2.co.z > Z_TOP - 0.22:
                v2.co.z += (Z_TOP - v2.co.z) * 0.8
            elif v2.co.z < Z_HEM + 0.22:
                v2.co.z += (Z_HEM - v2.co.z) * 0.8
    except ValueError:
        pass
sh.verts.index_update()

bmesh.ops.recalc_face_normals(sh, faces=sh.faces[:])
sh.normal_update()                 # solidify divides by vertex normals: they must exist
# Solidify builds its own rim along the open boundary. Hole-filling the
# stair-stepped edge first was what tore it into shards, so that step is gone.
# (bmesh.ops.solidify exploded on this shell; the Solidify modifier is applied below instead)

mesh = bpy.data.meshes.new('ShortsMesh')
sh.to_mesh(mesh)
sh.free(); src.free()
shorts = bpy.data.objects.new('Shorts', mesh)
bpy.context.collection.objects.link(shorts)
for o_ in bpy.context.view_layer.objects: o_.select_set(o_ == shorts)
bpy.context.view_layer.objects.active = shorts
sol = shorts.modifiers.new('Solidify', 'SOLIDIFY'); sol.thickness = 0.030; sol.offset = -1.0; sol.use_rim = True
bpy.ops.object.modifier_apply(modifier='Solidify')

mat = bpy.data.materials.new('shorts')
mat.use_nodes = True
mat.use_backface_culling = False
b = mat.node_tree.nodes['Principled BSDF']
b.inputs['Base Color'].default_value = (0.10, 0.12, 0.17, 1)
b.inputs['Roughness'].default_value = 0.88
mesh.materials.append(mat)

bpy.context.view_layer.objects.active = shorts
shorts.select_set(True)
sm = shorts.modifiers.new('Smooth', 'SMOOTH')
sm.factor = 0.5; sm.iterations = 3
bpy.ops.object.modifier_apply(modifier='Smooth')
bpy.ops.object.shade_smooth()
print('shorts verts:', len(mesh.vertices))

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend')
