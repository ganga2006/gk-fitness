"""
GK Fitness — body shape, built skeleton first, then muscle, then skin.

  1. Proportions: the MakeHuman upper arm is lengthened to a real adult ratio
     (anatomy/fit.py), and the updated joint centres are written to joints.json.
  2. Torso: the skin is wrapped over the anatomical muscle body built in
     anatomy/build_envelope.py — real BodyParts3D muscles on a real skeleton —
     with a thin skin/fat offset. This replaces the old hand-placed plates and
     blobs, which made the chest read as a breast.
  3. Limbs keep smooth radial thickening; glutes keep a soft mass (not wrapped yet).
"""
import bpy, bmesh, json, math, os, sys
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

OUT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(OUT, 'anatomy'))
import fit

bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_base.blend'))
obj = bpy.data.objects['Body']
me = obj.data
smooth = lambda t: (lambda u: u * u * (3 - 2 * u))(max(0.0, min(1.0, t)))
def sstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)

# ── 1. proportions ────────────────────────────────────────────────
co = np.array([v.co[:] for v in me.vertices])
co = fit.stretch_arms(co)
me.vertices.foreach_set('co', co.astype(np.float32).ravel()); me.update()
J = fit.J
json.dump({k: [float(x) for x in v] for k, v in J.items()},
          open(os.path.join(OUT, 'joints.json'), 'w'), indent=1)
print('upper arms lengthened to', round(fit.UPPER_ARM_TARGET, 3), 'units; joints.json updated')

# ── 2. neck and jaw (outside the wrap) ─────────────────────────────
for v in me.vertices:
    z = v.co.z
    if 9.95 - 0.45 < z < 10.60 + 0.45 and abs(v.co.y) < 0.7:
        w = smooth((z - 9.5) / 0.45) if z < 9.95 else smooth((11.05 - z) / 0.45) if z > 10.60 else 1.0
        v.co.y *= 1 + 0.20 * w
for v in me.vertices:
    if 10.45 < v.co.z < 10.98 and v.co.x > -0.1:
        w = smooth(1 - abs(v.co.z - 10.64) / 0.34)
        v.co.y *= 1 + 0.13 * w
        if v.co.x > 0.22:
            v.co.x += 0.04 * w
me.update()

# ── 3. wrap the torso over the (softened) muscle body ──────────────
# The game mesh is too coarse (~1.5 cm edges) to carry individual muscle
# borders; it takes the broad anatomical forms from a softened muscle body, and
# the full detail goes into the normal map baked from the high-detail mesh.
import wrap as W
with bpy.data.libraries.load(os.path.join(OUT, 'anatomy', 'anatomy.blend')) as (src, dst):
    dst.objects = ['Envelope_Smooth']
bvh = W.bvh_from_object(dst.objects[0])
me.update()
co = np.array([v.co[:] for v in me.vertices]); nrm = np.array([v.normal[:] for v in me.vertices])
E = np.array([e.vertices[:] for e in me.edges])
w = W.torso_mask(co, nrm, J)
co, nwr = W.wrap(co, nrm, E, bvh, w, W.skin_offset(co))
me.vertices.foreach_set('co', co.astype(np.float32).ravel()); me.update()
print(f'wrapped {nwr} torso vertices onto the softened muscle body')

# ── 4. limbs and glutes (smooth radial thickening, as before) ──────
bm = bmesh.new(); bm.from_mesh(me); bm.normal_update()
base_n = {v.index: v.normal.copy() for v in bm.verts}
disp = {v.index: Vector((0, 0, 0)) for v in bm.verts}
def blob(centre, radii, amount, facing=0):
    c, r = Vector(centre), Vector(radii)
    for v in bm.verts:
        d = Vector(((v.co.x - c.x) / r.x, (v.co.y - c.y) / r.y, (v.co.z - c.z) / r.z)).length
        if d > 1.6: continue
        n = base_n[v.index]
        if facing and n.x * facing <= 0.1: continue
        wgt = math.exp(-(d * 1.35) ** 2)
        if facing: wgt *= min(1.0, abs(n.x) * 1.5)
        disp[v.index] += n * (amount * wgt)
def limb(a, b, profile, bias=None, bias_amt=0.0):
    a, b = Vector(a), Vector(b); ab = b - a; L2 = ab.length_squared
    sd = Vector(bias).normalized() if bias else None
    for v in bm.verts:
        t = (v.co - a).dot(ab) / L2
        if t < -0.10 or t > 1.10: continue
        radial = v.co - (a + ab * max(0.0, min(1.0, t))); rl = radial.length
        if rl > 1.6: continue
        n = base_n[v.index]
        if rl > 1e-6 and n.dot(radial.normalized()) < 0.2: continue
        amt = profile(max(0.0, min(1.0, t)))
        if t < 0: amt *= smooth(1 + t / 0.10)
        if t > 1: amt *= smooth(1 - (t - 1) / 0.10)
        if sd and rl > 1e-6: amt *= 1.0 + bias_amt * radial.normalized().dot(sd)
        disp[v.index] += n * amt
bell = lambda t, pk, wd, h: h * math.exp(-(((t - pk) / wd) ** 2))
FRONT, BACK = Vector((1, 0, 0)), Vector((-1, 0, 0))
for s, side in ((1, 'l'), (-1, 'r')):
    sho, elb, hnd = (Vector(J[f'{side}-{k}']) for k in ('shoulder', 'elbow', 'hand'))
    hip, kne, ank = (Vector(J[f'{side}-{k}']) for k in ('upper-leg', 'knee', 'ankle'))
    # upper arm: only below the deltoid, which now comes from the wrap
    limb(sho, elb, lambda t: bell(t, 0.52, 0.30, 0.20) + bell(t, 0.30, 0.16, 0.06) * 0,
         bias=FRONT, bias_amt=0.26)
    limb(elb, hnd, lambda t: bell(t, 0.18, 0.26, 0.145))
    limb(hip, kne, lambda t: bell(t, 0.40, 0.38, 0.24), bias=FRONT, bias_amt=0.26)
    limb(kne, ank, lambda t: bell(t, 0.24, 0.22, 0.21), bias=BACK, bias_amt=0.40)
    blob((-0.36, s * 0.46, 6.10), (0.38, 0.48, 0.50), 0.19, -1)    # gluteus maximus
for v in bm.verts:
    v.co += disp[v.index]

# relax any vertex standing far off its neighbours (spikes)
for it in range(8):
    moves = {}
    for v in bm.verts:
        ring = [e.other_vert(v).co for e in v.link_edges]
        if len(ring) < 3: continue
        avg = sum(ring, Vector()) / len(ring)
        delta = v.co - avg
        edge = sum((p - v.co).length for p in ring) / len(ring)
        if delta.length > 1.0 * edge:
            moves[v.index] = delta * -0.8
    if not moves: break
    for v in bm.verts:
        if v.index in moves: v.co += moves[v.index]
bm.to_mesh(me); bm.free(); me.update()

bpy.context.view_layer.objects.active = obj; obj.select_set(True)
sm = obj.modifiers.new('Relax', 'SMOOTH'); sm.factor = 0.35; sm.iterations = 2
bpy.ops.object.modifier_apply(modifier='Relax')
bpy.ops.object.shade_smooth()
print('shaped:', len(me.vertices), 'verts')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend')
