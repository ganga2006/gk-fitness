"""
GK Fitness — real hair, eyebrows and eyelashes as individual strands.

Hair  : ~9000 tapered strands rooted on the scalp, combed into a short pompadour
        (up at the front, back over the top), clumped; the existing hair shell
        becomes the dark base layer underneath. Clipper sides keep the shell with
        a stubble texture.
Brows : ~450 hairs per brow following natural brow growth direction.
Lashes: curved upper and lower lashes along each lid margin.
Strands are thin ribbon meshes, so they render in Blender and export to glTF.
"""
import bpy, bmesh, json, math, os, random
import numpy as np
from mathutils import Vector, noise
from mathutils.bvhtree import BVHTree
OUT = os.path.dirname(os.path.abspath(__file__))
random.seed(7); np.random.seed(7)
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
for nm in ('HairStrands', 'BrowHairs', 'Lashes'):
    if nm in bpy.data.objects: bpy.data.objects.remove(bpy.data.objects[nm])
body, shell, brows = bpy.data.objects['Body'], bpy.data.objects['Hair'], bpy.data.objects.get('Brows')
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
C = json.load(open(os.path.join(OUT, 'face_metrics.json')))['colors']
EL, ER = J['l-eye'], J['r-eye']; E = (EL + ER) / 2
def sm(t): t = max(0.0, min(1.0, t)); return t*t*(3-2*t)
srgb2lin = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
bt = BVHTree.FromPolygons([v.co.copy() for v in body.data.vertices], [p.vertices[:] for p in body.data.polygons])
st = BVHTree.FromPolygons([v.co.copy() for v in shell.data.vertices], [p.vertices[:] for p in shell.data.polygons])
HC = Vector((E.x - 0.55, 0.0, E.z + 0.05))

def ribbon(bm, pts, normals, w0, w1, col, uvl, coll):
    """tapered flat ribbon along pts, lying in the surface (width ⟂ tangent and normal)"""
    n = len(pts); prev = None
    for i, p in enumerate(pts):
        t = (pts[min(i + 1, n - 1)] - pts[max(i - 1, 0)]).normalized()
        side = t.cross(normals[i]); side = side.normalized() if side.length > 1e-8 else Vector((0, 1, 0))
        w = w0 + (w1 - w0) * (i / (n - 1))
        a = bm.verts.new(p - side * w * 0.5); b = bm.verts.new(p + side * w * 0.5)
        if prev:
            f = bm.faces.new((prev[0], prev[1], b, a))
            for lp, (u, v) in zip(f.loops, ((0, (i-1)/(n-1)), (1, (i-1)/(n-1)), (1, i/(n-1)), (0, i/(n-1)))):
                lp[uvl].uv = (u, v); lp[coll] = col
        prev = (a, b)

def make_obj(name, bm):
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    ob = bpy.data.objects.new(name, me); bpy.context.scene.collection.objects.link(ob); return ob

# ── 1. strands on the hair volume's outer surface (+ hairline strands from the scalp) ──
sb = bmesh.new(); sb.from_mesh(shell.data); sb.faces.ensure_lookup_table(); sb.normal_update()
cands, areas = [], []
for f in sb.faces:
    c = f.calc_center_median(); out = c - HC
    if f.normal.dot(out.normalized()) < 0.3: continue            # outer face of the shell only
    top = sm((c.z - (E.z + 0.30)) / 0.22)
    if top < 0.10: continue
    cands.append((f, top)); areas.append(f.calc_area() * top)
P = np.array(areas) / sum(areas)
N_HAIR = 11000
hb = bmesh.new(); uvl = hb.loops.layers.uv.new('UVMap'); coll = hb.loops.layers.color.new('Col')
hrgb = [srgb2lin(x / 255) for x in C['hair']]
def grow(root, n, L, lift, front):
    back = Vector((-1, 0.10 * (1 if root.y > 0 else -1), 0.25 * front)); back -= n * back.dot(n); back.normalize()
    cj = noise.noise_vector(Vector((root.x * 7, root.y * 11, root.z * 7))) * 0.30
    dirv = (back + n * lift + cj).normalized(); pts, nrm = [], []; p = root.copy()
    for s_ in range(7):
        loc, sn, _, _ = st.find_nearest(p); sn = sn if sn.dot(p - HC) > 0 else -sn
        if s_ > 0 and loc is not None:
            p = p.lerp(loc + sn * (0.002 + 0.006 * random.random()), 0.5)   # lie on the volume, slight loft
        pts.append(p.copy()); nrm.append(sn)
        p = p + dirv * (L / 6)
        dirv = (dirv * 0.55 + back * 0.45).normalized()
    return pts, nrm
for k in np.random.choice(len(cands), N_HAIR, p=P):
    f, top = cands[k]; vs = [v.co for v in f.verts]; r1, r2 = random.random(), random.random()
    if r1 + r2 > 1: r1, r2 = 1 - r1, 1 - r2
    root = vs[0] + (vs[1] - vs[0]) * r1 + (vs[2] - vs[0]) * r2
    front = sm(((root - HC).x - 0.20) / 0.45)
    L = (0.10 + 0.16 * front) * (0.6 + 0.4 * top) * (0.75 + 0.5 * random.random())
    pts, nrm = grow(root - f.normal * 0.003, f.normal, L, 0.10 + 0.25 * front, front)
    tone = 0.7 + 0.6 * random.random()
    ribbon(hb, pts, nrm, 0.0048, 0.0010, (*[min(1, c * tone) for c in hrgb], 1), uvl, coll)
# hairline: short strands from the scalp, rising into the quiff
bmb = bmesh.new(); bmb.from_mesh(body.data); bmb.normal_update()
nh = 0
for v in bmb.verts:
    c = v.co
    if c.z < E.z + 0.38 or c.x < E.x - 0.35: continue
    loc, sn, _, d = st.find_nearest(c)
    if loc is None or d > 0.03 or random.random() > 0.55: continue
    front = sm(((c - HC).x - 0.20) / 0.45)
    if front < 0.4: continue
    pts, nrm = grow(c, v.normal, 0.16 + 0.06 * random.random(), 0.9, front)
    ribbon(hb, pts, nrm, 0.0042, 0.0010, (*[c_ * (0.7 + 0.5 * random.random()) for c_ in hrgb], 1), uvl, coll); nh += 1
print('hairline strands:', nh)
hair = make_obj('HairStrands', hb)
print('hair strands:', N_HAIR, 'verts', len(hair.data.vertices))

# ── 2. eyebrow hairs ────────────────────────────────────────────────
bb = bmesh.new(); buv = bb.loops.layers.uv.new('UVMap'); bco = bb.loops.layers.color.new('Col')
nb = 0
for e in (EL, ER):
    s = 1 if e.y > 0 else -1; nb_side = 0
    for _ in range(4000):
        if nb_side >= 460: break
        u = random.random() ** 0.9                          # 0 inner .. 1 tail
        zc = e.z + 0.158 + 0.024 * math.sin(math.pi * min(1, u / 0.72)) - 0.045 * max(0, u - 0.72) / 0.28
        hh = 0.052 * (1 - 0.50 * u)
        zz = zc + (random.random() * 2 - 1) * hh * 0.95
        y = s * (0.065 + u * 0.37)
        hit = bt.ray_cast(Vector((e.x + 1.0, y, zz)), Vector((-1, 0, 0)), 2.0)
        if hit[0] is None: continue
        root, n = hit[0], hit[1]
        # growth: up at the head, outward through the body, flat/down at the tail
        ang = math.radians(75 - 95 * min(1, u * 1.25)) + random.gauss(0, 0.18)
        out = Vector((0, s, 0)); up = Vector((0, 0, 1))
        dirv = (out * math.cos(ang) + up * math.sin(ang) + n * 0.15).normalized()
        L = 0.040 + 0.020 * (1 - u) + random.gauss(0, 0.006)
        pts, nrm = [], []
        for k in range(5):
            p = root + dirv * (L * k / 4) + n * (0.002 + 0.004 * (k / 4) ** 1.5)
            pts.append(p); nrm.append(n)
        ribbon(bb, pts, nrm, 0.0016, 0.0004, (*[c * (0.7 + 0.5 * random.random()) for c in hrgb], 1), buv, bco)
        nb += 1; nb_side += 1
brow_obj = make_obj('BrowHairs', bb)
print('eyebrow hairs:', nb)

# ── 3. eyelashes along the measured lid margins ────────────────────
lb = bmesh.new(); luv = lb.loops.layers.uv.new('UVMap'); lco = lb.loops.layers.color.new('Col')
nl = 0
eyes = bpy.data.objects['Eyes']
et = BVHTree.FromPolygons([v.co.copy() for v in eyes.data.vertices], [p.vertices[:] for p in eyes.data.polygons])
for e in (EL, ER):
    s = 1 if e.y > 0 else -1
    for dy in np.linspace(-0.085, 0.085, 46):
        # scan upward/downward from the eye's visible centre to find each lid margin
        for upper in (True, False):
            if not upper and abs(dy) > 0.06: continue
            margin = None
            for dz in np.linspace(0, 0.07, 36):
                zz = e.z + (dz if upper else -dz)
                o = Vector((e.x + 1.5, e.y + dy, zz))
                hb_ = bt.ray_cast(o, Vector((-1, 0, 0)), 3); he = et.ray_cast(o, Vector((-1, 0, 0)), 3)
                eye_first = he[0] is not None and (hb_[0] is None or he[3] < hb_[3])
                if not eye_first and hb_[0] is not None and dz > 0.005:
                    margin = hb_[0]; break
            if margin is None: continue
            n = Vector((1, 0, 0.0))
            for rep in range(3 if upper else 1):
                L = (0.066 if upper else 0.034) * (1 - 0.55 * (abs(dy) / 0.085) ** 2) * (0.85 + 0.3 * random.random())
                curl = Vector((0.55, s * dy * 2.0, 0.75 if upper else -0.75)).normalized()
                pts, nrm = [], []
                for k in range(5):
                    t = k / 4
                    p = margin + Vector((0.003, (random.random() - 0.5) * 0.004, 0)) + curl * (L * t) + Vector((0, 0, (0.012 if upper else -0.006) * t * t))
                    pts.append(p); nrm.append(Vector((0, 0, 1)))
                ribbon(lb, pts, nrm, 0.0022, 0.0005, (0.01, 0.008, 0.007, 1), luv, lco)
                nl += 1
lash = make_obj('Lashes', lb)
print('eyelashes:', nl)

# ── materials ───────────────────────────────────────────────────────
def strand_mat(name, rough):
    m = bpy.data.materials.new(name); m.use_nodes = True; nt = m.node_tree; b = nt.nodes['Principled BSDF']
    vc = nt.nodes.new('ShaderNodeVertexColor'); vc.layer_name = 'Col'
    nt.links.new(vc.outputs['Color'], b.inputs['Base Color'])
    b.inputs['Roughness'].default_value = rough; b.inputs['Coat Weight'].default_value = 0.0
    b.inputs['Specular IOR Level'].default_value = 0.35
    m.use_backface_culling = False; return m
hm = strand_mat('hair_strands', 0.55)
for o in (hair, brow_obj, lash): o.data.materials.append(hm if o is not lash else strand_mat('lashes', 0.5))
# the shell becomes the dark matte base; only the clipper sides show stubble over skin
base = shell.data.materials[0]; nt = base.node_tree; bsdf = nt.nodes['Principled BSDF']
for l in list(bsdf.inputs['Base Color'].links): nt.links.remove(l)
for l in list(bsdf.inputs['Normal'].links): nt.links.remove(l)
bsdf.inputs['Roughness'].default_value = 0.8
tc = nt.nodes.new('ShaderNodeTexCoord'); sep = nt.nodes.new('ShaderNodeSeparateXYZ'); nt.links.new(tc.outputs['Object'], sep.inputs['Vector'])
mr = nt.nodes.new('ShaderNodeMapRange'); mr.inputs['From Min'].default_value = E.z + 0.20; mr.inputs['From Max'].default_value = E.z + 0.42
nt.links.new(sep.outputs['Z'], mr.inputs['Value'])
tx = nt.nodes.new('ShaderNodeTexNoise'); tx.inputs['Scale'].default_value = 1400; tx.inputs['Detail'].default_value = 2
ramp = nt.nodes.new('ShaderNodeValToRGB'); ramp.color_ramp.elements[0].position = 0.48; ramp.color_ramp.elements[1].position = 0.56
ramp.color_ramp.elements[0].color = (*[c * 0.5 for c in hrgb], 1); ramp.color_ramp.elements[1].color = (0.30, 0.18, 0.13, 1)
nt.links.new(tx.outputs['Fac'], ramp.inputs['Fac'])
mix = nt.nodes.new('ShaderNodeMix'); mix.data_type = 'RGBA'
nt.links.new(mr.outputs['Result'], mix.inputs['Factor']); nt.links.new(ramp.outputs['Color'], mix.inputs[6])
mix.inputs[7].default_value = (*[c * 0.45 for c in hrgb], 1)
nt.links.new(mix.outputs[2], bsdf.inputs['Base Color'])
for o in (hair, brow_obj, lash):
    bpy.context.view_layer.objects.active = o
    for x in bpy.data.objects: x.select_set(x == o)
    bpy.ops.object.shade_smooth()
if brows: brows.hide_render = True; brows.hide_viewport = True     # solid brows replaced by real hairs
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend (strand hair, brows, lashes)')
