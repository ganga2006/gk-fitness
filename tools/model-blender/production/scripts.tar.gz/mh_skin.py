"""
GK Fitness — realistic skin: region tint masks (as a colour attribute) + a
layered skin shader (mottling, pores, T-zone sheen, subsurface scattering).
"""
import bpy, json, math, os
from mathutils import Vector
OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
body = bpy.data.objects['Body']; me = body.data
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
EL, ER = J['l-eye'], J['r-eye']; E = (EL + ER) / 2
def sm(t): t = max(0.0, min(1.0, t)); return t*t*(3-2*t)
def g(x, c, w): return math.exp(-((x - c) / w) ** 2)
# masks: R = redness/warmth, G = lip, B = beard shadow; A = T-zone oiliness
def find_slit(verts, lo=10.60, hi=10.80):
    """mouth line = deepest point of the midline profile between chin and nose"""
    best = None
    for z10 in range(int(lo * 100), int(hi * 100)):
        z = z10 / 100.0
        xs = [v.co.x for v in verts if abs(v.co.y) < 0.015 and abs(v.co.z - z) < 0.006 and v.co.x > 0.9]
        if not xs: continue
        x = max(xs)
        if best is None or x < best[1]: best = (z, x)
    return best[0]
import numpy as _np
LM = _np.load(os.path.join(OUT, 'anatomy', 'lip_masks.npy'))
def lip_centres(verts):
    up = [v.co for v in verts if LM[v.index, 0] > 0.5]; lo = [v.co for v in verts if LM[v.index, 1] > 0.5]
    zu = sum(p.z for p in up) / len(up); zl = sum(p.z for p in lo) / len(lo)
    xf = max(p.x for p in up + lo)
    return zu, zl, xf
_zu, _zl, _xf = lip_centres(me.vertices); SL = (_zu + _zl) / 2; print('lips around z %.3f' % SL)
attr = me.color_attributes.get('SkinMask') or me.color_attributes.new('SkinMask', 'FLOAT_COLOR', 'POINT')
for v in me.vertices:
    c = v.co; ay = abs(c.y); front = sm((c.x - 0.75) / 0.2)
    red = 0.0; lip = 0.0; beard = 0.0; oil = 0.0
    if c.z > 10.2:
        red = max(red, 0.7 * g(c.z, E.z - 0.20, 0.10) * g(ay, 0.36, 0.13) * front)          # cheeks
        red = max(red, 0.8 * g(c.z, 10.95, 0.10) * g(ay, 0.0, 0.08) * sm((c.x - 1.15) / 0.1))  # nose
        red = max(red, 0.6 * sm((ay - 0.52) / 0.05) * g(c.z, E.z - 0.10, 0.22) * sm((E.x - 0.3 - c.x) / 0.2))  # ears
        up = math.hypot(c.y / 0.185, (c.z - (SL + 0.024)) / 0.024); lo = math.hypot(c.y / 0.175, (c.z - (SL - 0.058)) / 0.056)
        lip = 0.85 * sm((max(LM[v.index, 0], LM[v.index, 1]) - 0.18) * 2.6)
        beard = (sm((10.98 - c.z) / 0.08) * sm((c.z - 10.25) / 0.10)) * sm((c.x - (E.x - 0.55)) / 0.2) * (1 - lip)
        beard *= 1 - 0.85 * g(c.z, E.z - 0.22, 0.10) * g(ay, 0.33, 0.12)                     # not on the cheekbones
        beard *= 1 - 0.75 * g(c.z, SL + 0.07, 0.05) * g(ay, 0.0, 0.16)                           # clean upper lip
        oil = max(g(c.z, E.z + 0.30, 0.20) * g(ay, 0.0, 0.25), g(c.z, 10.98, 0.12) * g(ay, 0.0, 0.10)) * front
        red = max(red, 0.35 * g((c - EL).length, 0.12, 0.05) + 0.35 * g((c - ER).length, 0.12, 0.05))  # lids
    if 8.6 < c.z < 9.2 and c.x > 0.9:                                                       # areolae
        for s in (1, -1):
            d = math.hypot(c.y - s * 0.62, c.z - 8.92)
            red = max(red, 1.0 * (1 - sm((d - 0.045) / 0.02)))
    attr.data[v.index].color = (red, lip, beard, oil)
lin = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
pal = json.load(open(os.path.join(OUT, 'palette.json')))
skin = [lin(x / 255) for x in pal['skin']]; lipc = [lin(x / 255) for x in pal.get('lip', (150, 90, 80))]
m = bpy.data.materials.get('skin_real') or bpy.data.materials.new('skin_real'); m.use_nodes = True
nt = m.node_tree; nt.nodes.clear()
N = lambda t, **k: (lambda n: [setattr(n, a, b) for a, b in k.items()] and n or n)(nt.nodes.new(t))
out = nt.nodes.new('ShaderNodeOutputMaterial'); bs = nt.nodes.new('ShaderNodeBsdfPrincipled')
nt.links.new(bs.outputs[0], out.inputs[0])
ca = nt.nodes.new('ShaderNodeAttribute'); ca.attribute_name = 'SkinMask'; ca.attribute_type = 'GEOMETRY'
sep = nt.nodes.new('ShaderNodeSeparateColor'); nt.links.new(ca.outputs['Color'], sep.inputs[0])
# base tone with soft mottling
mott = nt.nodes.new('ShaderNodeTexNoise'); mott.inputs['Scale'].default_value = 35; mott.inputs['Detail'].default_value = 6
mr = nt.nodes.new('ShaderNodeMapRange'); mr.inputs['To Min'].default_value = 0.92; mr.inputs['To Max'].default_value = 1.06
nt.links.new(mott.outputs['Fac'], mr.inputs['Value'])
def mix(a_out, b_val, fac_out, blend='MIX'):
    mx = nt.nodes.new('ShaderNodeMix'); mx.data_type = 'RGBA'; mx.blend_type = blend
    nt.links.new(fac_out, mx.inputs['Factor'])
    if isinstance(a_out, tuple): mx.inputs[6].default_value = (*a_out, 1)
    else: nt.links.new(a_out, mx.inputs[6])
    if isinstance(b_val, tuple): mx.inputs[7].default_value = (*b_val, 1)
    else: nt.links.new(b_val, mx.inputs[7])
    return mx.outputs[2]
c1 = mix(tuple(skin), (skin[0] * 1.10, skin[1] * 0.80, skin[2] * 0.78), sep.outputs['Red'])        # warmth
c2 = mix(c1, (lipc[0] * 0.92, lipc[1] * 0.56, lipc[2] * 0.55), sep.outputs['Green'])                 # lips
bfac = nt.nodes.new('ShaderNodeMath'); bfac.operation = 'MULTIPLY'; bfac.inputs[1].default_value = 0.12
nt.links.new(sep.outputs['Blue'], bfac.inputs[0])
c3 = mix(c2, (skin[0] * 0.62, skin[1] * 0.62, skin[2] * 0.72), bfac.outputs[0])                      # shave shadow
mul = nt.nodes.new('ShaderNodeMix'); mul.data_type = 'RGBA'; mul.blend_type = 'MULTIPLY'; mul.inputs['Factor'].default_value = 1.0
nt.links.new(c3, mul.inputs[6]); cm = nt.nodes.new('ShaderNodeCombineColor')
for i in range(3): nt.links.new(mr.outputs['Result'], cm.inputs[i])
nt.links.new(cm.outputs[0], mul.inputs[7]); nt.links.new(mul.outputs[2], bs.inputs['Base Color'])
# roughness: matte skin, oilier T-zone, glossier lips
rg = nt.nodes.new('ShaderNodeMapRange'); rg.inputs['To Min'].default_value = 0.50; rg.inputs['To Max'].default_value = 0.33
nt.links.new(sep.outputs['Alpha'] if 'Alpha' in sep.outputs else ca.outputs['Alpha'], rg.inputs['Value'])
lipr = nt.nodes.new('ShaderNodeMix'); lipr.data_type = 'FLOAT'; nt.links.new(sep.outputs['Green'], lipr.inputs['Factor'])
nt.links.new(rg.outputs['Result'], lipr.inputs[2]); lipr.inputs[3].default_value = 0.28
nt.links.new(ca.outputs['Alpha'], rg.inputs['Value']); nt.links.new(lipr.outputs[0], bs.inputs['Roughness'])
# pores + fine wrinkles as bump
vor = nt.nodes.new('ShaderNodeTexVoronoi'); vor.inputs['Scale'].default_value = 900
nz = nt.nodes.new('ShaderNodeTexNoise'); nz.inputs['Scale'].default_value = 260; nz.inputs['Detail'].default_value = 8
add = nt.nodes.new('ShaderNodeMath'); add.operation = 'ADD'
nt.links.new(vor.outputs['Distance'], add.inputs[0]); nt.links.new(nz.outputs['Fac'], add.inputs[1])
bump = nt.nodes.new('ShaderNodeBump'); bump.inputs['Strength'].default_value = 0.06; bump.inputs['Distance'].default_value = 0.002
nt.links.new(add.outputs[0], bump.inputs['Height']); nt.links.new(bump.outputs['Normal'], bs.inputs['Normal'])
bs.inputs['Subsurface Weight'].default_value = 0.30; bs.inputs['Subsurface Radius'].default_value = (1.0, 0.38, 0.22)
bs.inputs['Subsurface Scale'].default_value = 0.025; bs.inputs['Specular IOR Level'].default_value = 0.45
bs.inputs['Coat Weight'].default_value = 0.04; bs.inputs['Coat Roughness'].default_value = 0.35
body.data.materials.clear(); body.data.materials.append(m)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('realistic skin applied')
