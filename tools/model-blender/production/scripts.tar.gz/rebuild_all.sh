#!/bin/bash
# GK Fitness — full rebuild: skeleton -> muscles -> skin -> face -> hair -> finish -> rig -> validate
set -e
cd /home/claude/mh
run(){ echo "== $1"; timeout 3600 python3 -I $1 2>&1 | grep -E "x .* -> |upper arm|hip joints|placed|saved|reshaped|mouth line|strands:|eyebrow|eyelash|applied|baked|regions|shape keys|bones:|bound:|actions:|exported|rendered inspect|Error|Trace|line [0-9]" || true; }
run anatomy/move_legs.py
run anatomy/spine_joints.py
run anatomy/build_body.py
run anatomy/envelope_body.py
run mh_wrap.py
cp mh_shaped.blend mh_shaped_body_v4.blend
run anatomy/build_face.py
run mh_face.py
cp mh_shaped.blend mh_shaped_face_v1.blend
run anatomy/face_recipe.py
run mh_head2.py
run mh_hair_real.py
run mh_skin.py
run mh_shorts.py
run mh_finish2.py
run production.py
run validate.py
echo "== DONE"
