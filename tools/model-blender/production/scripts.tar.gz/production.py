"""
GK Fitness — production rig and animation build.

Builds the full-body rig from the base mesh's own joint markers (including
fingers and toes), binds and smooths weights, keys twelve named stretching and
exercise Actions, and saves the production file.

The Action poses are the same joint angles the app uses, so the Blender file
and the running app show the same movement.

Output: GKFitness_Trainer_Production.blend, body.glb, gkfitness_body.fbx
"""
import bpy, json, math, os
from mathutils import Vector, Euler, Quaternion, Matrix

OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_final.blend'))
body = bpy.data.objects['Body']
shorts = bpy.data.objects.get('Shorts')
hair = bpy.data.objects.get('Hair')
eyes = bpy.data.objects.get('Eyes')
strands = [bpy.data.objects.get(n) for n in ('HairStrands', 'BrowHairs', 'Lashes')]
strands = [o for o in strands if o]
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}

# drop the high-poly bake source from the production file
hp = bpy.data.objects.get('BodyHigh')
if hp:
    bpy.data.objects.remove(hp, do_unlink=True)

# ── skeleton ───────────────────────────────────────────────────────
def j(n):
    return J[n].copy()

B = [
    ('root',     Vector((0, 0, 0)),  Vector((0, 0, 0.9)), None),
    ('hips',     j('pelvis'),   j('spine-3'),  'root'),
    ('spine_01', j('spine-3'),  j('spine-2'),  'hips'),
    ('spine_02', j('spine-2'),  j('spine-1'),  'spine_01'),
    ('spine_03', j('spine-1'),  j('neck'),     'spine_02'),
    ('neck',     j('neck'),     j('head'),     'spine_03'),
    ('head',     j('head'),     j('head-2'),   'neck'),
]

FINGERS = {1: 'thumb', 2: 'index', 3: 'middle', 4: 'ring', 5: 'pinky'}

for s in ('l', 'r'):
    sg = 1 if s == 'l' else -1
    mir = lambda v: Vector((v.x, v.y * sg, v.z))
    sho, elb = mir(j('l-shoulder')), mir(j('l-elbow'))
    hnd, hnd2 = mir(j('l-hand')), mir(j('l-hand-2'))
    clav = mir(j('l-clavicle'))
    upl, kne = mir(j('l-upper-leg')), mir(j('l-knee'))
    ank, ft1, ft2 = mir(j('l-ankle')), mir(j('l-foot-1')), mir(j('l-foot-2'))
    B += [
        (f'clavicle_{s}', clav, sho,  'spine_03'),
        (f'upperarm_{s}', sho,  elb,  f'clavicle_{s}'),
        (f'forearm_{s}',  elb,  hnd,  f'upperarm_{s}'),
        (f'hand_{s}',     hnd,  hnd2, f'forearm_{s}'),
        (f'thigh_{s}',    upl,  kne,  'hips'),
        (f'shin_{s}',     kne,  ank,  f'thigh_{s}'),
        (f'foot_{s}',     ank,  ft1,  f'shin_{s}'),
        (f'toe_{s}',      ft1,  ft2,  f'foot_{s}'),
    ]
    # fingers, three joints each, straight from the mesh's markers
    for fi, fname in FINGERS.items():
        prev = f'hand_{s}'
        for seg in (1, 2, 3):
            a = f'l-finger-{fi}-{seg}'
            b = f'l-finger-{fi}-{seg + 1}'
            if a not in J or b not in J:
                continue
            B.append((f'{fname}_{seg}_{s}', mir(j(a)), mir(j(b)), prev))
            prev = f'{fname}_{seg}_{s}'

arm = bpy.data.armatures.new('Rig')
rig = bpy.data.objects.new('Rig', arm)
bpy.context.collection.objects.link(rig)
bpy.context.view_layer.objects.active = rig
bpy.ops.object.mode_set(mode='EDIT')
made = {}
for name, head, tail, parent in B:
    if (tail - head).length < 1e-4:
        tail = head + Vector((0, 0, 0.1))
    b = arm.edit_bones.new(name)
    b.head, b.tail = head, tail
    b.use_connect = False
    if parent and parent in made:
        b.parent = made[parent]
    made[name] = b
bpy.ops.object.mode_set(mode='OBJECT')
print('bones:', len(arm.bones))

# ── bind ───────────────────────────────────────────────────────────
targets = [o for o in (body, shorts, hair, eyes) if o]
for o in targets:
    for m in list(o.modifiers):
        if m.type == 'ARMATURE':
            o.modifiers.remove(m)
    bpy.ops.object.select_all(action='DESELECT')
    o.select_set(True); rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    bpy.ops.object.parent_set(type='ARMATURE_AUTO')
    bpy.ops.object.select_all(action='DESELECT')
    o.select_set(True); bpy.context.view_layer.objects.active = o
    bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
    bpy.ops.object.vertex_group_smooth(group_select_mode='ALL', factor=0.5, repeat=4)
    bpy.ops.object.mode_set(mode='OBJECT')
# hair strands, eyebrow hairs and lashes ride rigidly on the head bone
for o in strands:
    for m in list(o.modifiers):
        if m.type == 'ARMATURE': o.modifiers.remove(m)
    o.vertex_groups.clear(); g_ = o.vertex_groups.new(name='head'); g_.add(list(range(len(o.data.vertices))), 1.0, 'REPLACE')
    md = o.modifiers.new('Armature', 'ARMATURE'); md.object = rig; o.parent = rig
print('bound:', [o.name for o in targets] + [o.name for o in strands])

# ── weight hygiene ─────────────────────────────────────────────────
# Automatic weights work by proximity, and in rest pose the hands hang right
# beside the hips — so shorts and thigh vertices pick up hand and finger
# weights and get dragged off with the arm. Each object is limited to the bones
# that can genuinely move it, and the body loses any hand weight far from the hand.
HAND_BONES = {b.name for b in arm.bones
              if b.name.startswith(('hand_', 'thumb_', 'index_', 'middle_', 'ring_', 'pinky_'))}
ALLOWED = {
    'Hair':   {'head', 'neck'},
    'Eyes':   {'head'},
}
FALLBACK = {'Hair': 'head', 'Eyes': 'head'}

def limit_groups(o, allowed, fallback):
    for vg in list(o.vertex_groups):
        if vg.name not in allowed:
            o.vertex_groups.remove(vg)
    fb = o.vertex_groups.get(fallback) or o.vertex_groups.new(name=fallback)
    for v in o.data.vertices:
        if sum(g.weight for g in v.groups) < 1e-4:
            fb.add([v.index], 1.0, 'REPLACE')

for o in targets:
    if o.name in ALLOWED:
        limit_groups(o, ALLOWED[o.name], FALLBACK[o.name])

# body: strip hand/finger influence from anything not actually near a hand
mw = rig.matrix_world
hand_pts = []
for b_ in arm.bones:
    if b_.name in HAND_BONES:            # every hand and finger bone, head and tail
        hand_pts += [mw @ b_.head_local, mw @ b_.tail_local]
idx = {vg.name: vg.index for vg in body.vertex_groups}
stripped = 0
for v in body.data.vertices:
    near = min((body.matrix_world @ v.co - p).length for p in hand_pts)
    if near < 0.55:
        continue
    for g in list(v.groups):
        name = body.vertex_groups[g.group].name
        if name in HAND_BONES and g.weight > 0:
            body.vertex_groups[g.group].remove([v.index])
            stripped += 1

for o in targets:
    bpy.ops.object.select_all(action='DESELECT')
    o.select_set(True); bpy.context.view_layer.objects.active = o
    bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
    bpy.ops.object.vertex_group_normalize_all(lock_active=False)
    bpy.ops.object.mode_set(mode='OBJECT')
# safety net: no vertex may be left without a bone (it would stay behind as a spike)
segs = [(b_.name, mw @ b_.head_local, mw @ b_.tail_local) for b_ in arm.bones if b_.use_deform]
def nearest_bone(p):
    best, bn = 1e9, None
    for n_, a_, c_ in segs:
        ab = c_ - a_; t = max(0.0, min(1.0, (p - a_).dot(ab) / max(ab.length_squared, 1e-9)))
        d_ = (p - (a_ + ab * t)).length
        if d_ < best: best, bn = d_, n_
    return bn
orph = 0
for o in targets:
    for v in o.data.vertices:
        if sum(g.weight for g in v.groups) < 1e-4:
            n_ = nearest_bone(o.matrix_world @ v.co)
            if o.name in ALLOWED and n_ not in ALLOWED[o.name]: n_ = FALLBACK[o.name]
            (o.vertex_groups.get(n_) or o.vertex_groups.new(name=n_)).add([v.index], 1.0, 'REPLACE'); orph += 1
print(f'weight hygiene: limited shorts/hair/eyes, stripped {stripped} stray hand weights, re-homed {orph} unweighted verts')
# briefs move exactly like the skin underneath: copy the body's weights onto them
if shorts:
    for vg_ in list(shorts.vertex_groups): shorts.vertex_groups.remove(vg_)
    for vg_ in body.vertex_groups: shorts.vertex_groups.new(name=vg_.name)
    dt = shorts.modifiers.new('wt', 'DATA_TRANSFER'); dt.object = body; dt.use_vert_data = True
    dt.data_types_verts = {'VGROUP_WEIGHTS'}; dt.vert_mapping = 'POLYINTERP_NEAREST'
    dt.layers_vgroup_select_src = 'ALL'; dt.layers_vgroup_select_dst = 'NAME'
    bpy.ops.object.select_all(action='DESELECT'); shorts.select_set(True); bpy.context.view_layer.objects.active = shorts
    while shorts.modifiers[0].name != 'wt': bpy.ops.object.modifier_move_up(modifier='wt')
    bpy.ops.object.modifier_apply(modifier='wt')
    print('briefs: weights copied from the cleaned body weights')


# ── pose helpers ───────────────────────────────────────────────────
# Poses use the app's own convention: an angle in the sagittal plane, degrees,
# 0 = pointing along +X, 90 = straight up. Rest directions are read from the
# armature so the two stay in step if bone positions change.
DEG = math.pi / 180
AXIS = Vector((0, 1, 0))      # sagittal swing axis in Blender's Z-up space
LEAF = {'head': 90.0, 'hand': -78.0, 'toe': -10.0}
OVERRIDE = {'root': 90.0, 'hips': 90.0, 'neck': 90.0, 'head': 90.0}

bpy.context.view_layer.objects.active = rig
rest_angle = {}
for b in arm.bones:
    base = b.name.replace('_l', '').replace('_r', '')
    if b.name in OVERRIDE:
        rest_angle[b.name] = OVERRIDE[b.name]
        continue
    kids = [c for c in b.children]
    d = (kids[0].head_local - b.head_local) if kids else (b.tail_local - b.head_local)
    rest_angle[b.name] = math.degrees(math.atan2(d.z, d.x)) if (abs(d.x) + abs(d.z)) > 1e-6 \
        else LEAF.get(base, -90.0)

rest_vec = {}
for b in arm.bones:
    kids = list(b.children)
    d = (kids[0].head_local - b.head_local) if kids else (b.tail_local - b.head_local)
    rest_vec[b.name] = d.normalized() if d.length > 1e-6 else Vector((0, 0, 1))

def rot_y(deg):
    """Rotation that raises a sagittal angle by `deg` (0 = +X, 90 = up)."""
    return Matrix.Rotation(-deg * DEG, 3, 'Y')

def toward(angle_deg, side, spread):
    a = math.radians(angle_deg)
    return Vector((math.cos(a), side * spread, math.sin(a))).normalized()

def aim(name, target_dir):
    """
    Point a bone along `target_dir` (armature space), as forward kinematics.

    The orientation is set through pose_bone.matrix, then the bone's location
    is zeroed so it stays attached to its parent. Without that second step the
    matrix assignment writes a compensating location that pins the bone at its
    rest position: the pose LOOKS right while keying, but only rotations are
    keyed, so playback differed — which is what made the squat float.
    """
    pb = rig.pose.bones.get(name)
    if pb is None:
        return
    q = rest_vec[name].rotation_difference(target_dir.normalized())
    R = q.to_matrix().to_4x4()
    piv = Matrix.Translation(pb.bone.head_local)
    pb.matrix = piv @ R @ piv.inverted() @ pb.bone.matrix_local
    if name != 'root':
        pb.location = (0, 0, 0)
    bpy.context.view_layer.update()

# how far each limb sits out from the body's midline in a natural stance
SPREAD = {'upperarm': 0.20, 'forearm': 0.10, 'thigh': 0.14, 'shin': 0.06}

def set_pose(pose):
    """
    Pose the rig from joint angles (degrees, sagittal: 0 = forward, 90 = up).

    Limbs use absolute angles, matching the app. The trunk keeps its natural
    curvature and moves by delta from upright. `lean` (side bend, + toward the
    figure's left) and `twist` (rotation about the vertical) are true 3D
    rotations, which a side bend and a torso rotation genuinely need.
    """
    for pb in rig.pose.bones:
        pb.rotation_mode = 'QUATERNION'
        pb.rotation_quaternion = Quaternion((1, 0, 0, 0))
        pb.location = (0, 0, 0)
    bpy.context.view_layer.update()

    torso = pose.get('torso', 90.0)
    curve = pose.get('spine', 0.0)
    lean = pose.get('lean', 0.0)
    twist = pose.get('twist', 0.0)

    def chest(frac):
        return (Matrix.Rotation(twist * frac * DEG, 3, 'Z') @
                Matrix.Rotation(-lean * frac * DEG, 3, 'X'))

    # parents strictly before children
    aim('hips', rot_y(torso - 90) @ rest_vec['hips'])
    for i, seg in enumerate(('spine_01', 'spine_02', 'spine_03'), 1):
        aim(seg, chest(i / 3) @ rot_y((torso - 90) + curve * i / 3) @ rest_vec[seg])
    aim('neck', chest(1) @ rot_y(pose.get('head', 90.0) - 90) @ rest_vec['neck'])

    for side, sgn, up, fore in (('l', 1, 'armF', 'faF'), ('r', -1, 'armB', 'faB')):
        aim(f'upperarm_{side}', chest(1) @ toward(pose.get(up, -80.0), sgn, SPREAD['upperarm']))
        aim(f'forearm_{side}', chest(1) @ toward(pose.get(fore, -82.0), sgn, SPREAD['forearm']))

    for side, sgn, th, sh_, ft in (('l', 1, 'thF', 'shF', 'ftF'), ('r', -1, 'thB', 'shB', 'ftB')):
        aim(f'thigh_{side}', toward(pose.get(th, -92.0), sgn, SPREAD['thigh']))
        aim(f'shin_{side}', toward(pose.get(sh_, -91.0), sgn, SPREAD['shin']))
        # the foot moves by delta from flat, so a standing foot stays flat
        aim(f'foot_{side}', rot_y(pose.get(ft, -5.0) + 5.0) @ rest_vec[f'foot_{side}'])

FOOT_BONES = ('foot_l', 'foot_r', 'toe_l', 'toe_r')

def lowest_foot_z():
    mw = rig.matrix_world
    zs = []
    for n in FOOT_BONES:
        pb = rig.pose.bones.get(n)
        if pb:
            zs += [(mw @ pb.head).z, (mw @ pb.tail).z]
    return min(zs) if zs else 0.0

def plant_feet(rest_min):
    """Drop the root so the lowest foot point sits back at its rest height."""
    root = rig.pose.bones.get('root')
    if root is None:
        return
    bpy.context.view_layer.update()
    dz = rest_min - lowest_foot_z()
    root.matrix = Matrix.Translation((0, 0, dz)) @ root.bone.matrix_local
    bpy.context.view_layer.update()

def key(frame):
    for pb in rig.pose.bones:
        pb.keyframe_insert('rotation_quaternion', frame=frame)
    root = rig.pose.bones.get('root')
    if root:
        root.keyframe_insert('location', frame=frame)

STAND = dict(torso=90, head=90, armF=-78, faF=-80, armB=-82, faB=-84,
             thF=-93, shF=-92, ftF=-5, thB=-87, shB=-88, ftB=-5)
M = lambda **kw: {**STAND, **kw}

# Twelve Actions. Joint angles stay inside normal ranges of motion: no joint is
# driven to its limit, and the knee and elbow only fold the way they can.
ACTIONS = {
    'Idle_Neutral': [(1, STAND), (40, M(torso=89, armF=-76, armB=-84)), (80, STAND)],
    'Warmup_Arms': [(1, STAND), (20, M(armF=10, faF=6, armB=6, faB=2)),
                    (40, M(armF=86, faF=88, armB=82, faB=84)),
                    (60, M(armF=10, faF=6, armB=6, faB=2)), (80, STAND)],
    'Overhead_Stretch': [(1, STAND), (30, M(armF=84, faF=88, armB=88, faB=92, spine=6)),
                         (70, M(armF=92, faF=94, armB=96, faB=98, spine=10, head=96)),
                         (100, STAND)],
    'Triceps_Stretch': [(1, STAND), (30, M(armF=96, faF=-24, armB=-70, faB=-20, head=86)),
                        (75, M(armF=100, faF=-34, armB=-66, faB=-14, head=84)), (105, STAND)],
    'Cross_Body_Shoulder_Stretch': [(1, STAND),
        (30, M(armF=4, faF=14, armB=-24, faB=150, head=84)),
        (75, M(armF=0, faF=8, armB=-30, faB=156, head=82)), (105, STAND)],
    'Side_Bend_Stretch': [(1, STAND), (30, M(lean=-14, armF=92, faF=96)),
                          (70, M(lean=-24, armF=96, faF=100)), (100, STAND),
                          (130, M(lean=14, armB=92, faB=96)), (170, M(lean=24, armB=96, faB=100)),
                          (200, STAND)],
    'Torso_Rotation': [(1, STAND), (25, M(twist=38, armF=-2, faF=0, armB=-2, faB=0)),
                       (50, STAND), (75, M(twist=-38, armF=-2, faF=0, armB=-2, faB=0)),
                       (100, STAND)],
    'Forward_Fold': [(1, STAND), (35, M(torso=40, head=28, armF=-86, armB=-82, spine=-20)),
                     (75, M(torso=10, head=-6, armF=-88, faF=-90, armB=-84, faB=-86, spine=-34)),
                     (110, STAND)],
    'Bodyweight_Squat': [(1, STAND),
        (26, M(torso=72, head=80, thF=-22, shF=-133, ftF=-4, thB=-26, shB=-129, ftB=-4,
               armF=6, faF=12, armB=2, faB=8)),
        (42, M(torso=72, head=80, thF=-22, shF=-133, ftF=-4, thB=-26, shB=-129, ftB=-4,
               armF=6, faF=12, armB=2, faB=8)),
        (68, STAND)],
    'Forward_Lunge': [(1, STAND),
        (28, M(torso=88, thF=-30, shF=-100, ftF=-5, thB=-125, shB=-55, ftB=-120,
               armF=-80, faF=-84, armB=-84, faB=-88)),
        (50, M(torso=88, thF=-30, shF=-100, ftF=-5, thB=-125, shB=-55, ftB=-120)),
        (80, STAND)],
    'Calf_Stretch': [(1, STAND),
        (30, M(torso=84, thF=-84, shF=-86, ftF=-34, thB=-118, shB=-104, ftB=-58,
               armF=-20, faF=-40, armB=-24, faB=-44)),
        (70, M(torso=82, thF=-82, shF=-84, ftF=-40, thB=-120, shB=-106, ftB=-62)),
        (100, STAND)],
    'Return_To_Neutral': [(1, M(torso=84, armF=-60, armB=-66, thF=-88, thB=-90)),
                          (30, STAND), (60, STAND)],
}

sc = bpy.context.scene
sc.render.fps = 30
rig.animation_data_create()
set_pose(STAND)
REST_FOOT_Z = lowest_foot_z()
print(f'rest foot height {REST_FOOT_Z:.3f}')
for name, frames in ACTIONS.items():
    act = bpy.data.actions.new(name)
    act.use_fake_user = True            # survive saving with no user
    rig.animation_data.action = act
    for f, pose in frames:
        set_pose(pose)
        plant_feet(REST_FOOT_Z)
        key(f)
    # Blender 5.x moved F-curves onto Action layers/slots; support both so the
    # file opens and edits cleanly in either generation.
    curves = []
    if hasattr(act, 'fcurves'):
        curves = list(act.fcurves)
    else:
        for layer in getattr(act, 'layers', []):
            for strip in getattr(layer, 'strips', []):
                for slot in getattr(act, 'slots', []):
                    cb = strip.channelbag(slot) if hasattr(strip, 'channelbag') else None
                    if cb:
                        curves.extend(cb.fcurves)
    for fc in curves:
        for kp in fc.keyframe_points:
            kp.interpolation = 'BEZIER'
            kp.handle_left_type = kp.handle_right_type = 'AUTO_CLAMPED'
print('actions:', len(ACTIONS), '->', ', '.join(ACTIONS))

# leave the file on the neutral pose
rig.animation_data.action = bpy.data.actions['Idle_Neutral']
set_pose(STAND)
sc.frame_set(1)

P = json.load(open(os.path.join(OUT, 'palette.json')))
lin = lambda c: tuple(((v / 255) / 12.92) if (v / 255) <= 0.04045
                      else (((v / 255) + 0.055) / 1.055) ** 2.4 for v in c)
# realistic skin is carried by the region materials (baked albedo + skin shader): no flat tone override
bpy.ops.file.pack_all()
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'GKFitness_Trainer_Production.blend'))
print('saved GKFitness_Trainer_Production.blend')

# ── export ─────────────────────────────────────────────────────────
# app export: a lighter strand set (every third hair) keeps the GLB mobile-friendly
lite = None
hs = bpy.data.objects.get('HairStrands')
if hs:
    import bmesh as _bm
    lite = hs.copy(); lite.data = hs.data.copy(); lite.name = 'HairStrandsLite'; bpy.context.scene.collection.objects.link(lite)
    b_ = _bm.new(); b_.from_mesh(lite.data); b_.faces.ensure_lookup_table()
    _bm.ops.delete(b_, geom=[f for f in b_.faces if (f.index // 6) % 3 != 0], context='FACES'); b_.to_mesh(lite.data); b_.free()
bpy.ops.object.select_all(action='DESELECT')
for o in targets + [o for o in strands if o.name != 'HairStrands'] + ([lite] if lite else []):
    o.select_set(True)
rig.select_set(True)
bpy.context.view_layer.objects.active = body
bpy.ops.export_scene.gltf(
    filepath=os.path.join(OUT, 'body.glb'), export_format='GLB',
    use_selection=True, export_skins=True, export_morph=True, export_yup=True,
    export_materials='EXPORT', export_normals=True, export_tangents=True,
    export_image_format='JPEG', export_animations=False,
)
print('exported body.glb')
if lite: bpy.data.objects.remove(lite)
bpy.ops.object.select_all(action='DESELECT')
for o in targets + strands: o.select_set(True)
rig.select_set(True)
bpy.ops.export_scene.fbx(
    filepath=os.path.join(OUT, 'gkfitness_body.fbx'), use_selection=True,
    add_leaf_bones=False, bake_anim=True, bake_anim_use_all_actions=True,
    mesh_smooth_type='FACE', path_mode='COPY', embed_textures=True,
)
print('exported gkfitness_body.fbx')
