"""
GK Fitness — head shaped from the reference portrait's measurements.

No pixel of the photograph is used. `face_metrics.json` holds ratios and colour
samples measured from it; this script applies those ratios to the base mesh's
head and builds hair and beard geometry to match. That is how a character
artist works from reference: measure, then sculpt.
"""
import bpy, bmesh, json, math, os
from mathutils import Vector

OUT = os.path.dirname(os.path.abspath(__file__))
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
body = bpy.data.objects['Body']
M = json.load(open(os.path.join(OUT, 'face_metrics.json')))
R, C = M['ratios'], M['colors']
J = {k: Vector(v) for k, v in json.load(open(os.path.join(OUT, 'joints.json'))).items()}
hexof = lambda rgb: tuple(v / 255 for v in rgb)

# ── head extents on the current mesh ───────────────────────────────
bm = bmesh.new()
bm.from_mesh(body.data)
head_v = [v for v in bm.verts if v.co.z > 10.30]
Z_TOP = max(v.co.z for v in head_v)
Z_CHIN = 10.42
face_len = Z_TOP - Z_CHIN
cur_w = max(abs(v.co.y) for v in head_v) * 2
mid_z = (Z_TOP + Z_CHIN) / 2

smooth = lambda t: (lambda u: u * u * (3 - 2 * u))(max(0.0, min(1.0, t)))

# ── 1. overall width: the reference face is notably broad ──────────
BOX_OVER_FACE = 1.15        # the detector box is wider than the cheekbones
true_ratio = R['face_len_over_width'] * BOX_OVER_FACE
want_w = face_len / max(0.8, true_ratio)
# clamp hard: the base head is already a good human head, and a large width
# change wrecks it faster than it adds likeness
widen = max(0.98, min(1.045, want_w / cur_w))
for v in bm.verts:
    if v.co.z < 10.15:
        continue
    w = smooth((v.co.z - 10.15) / 0.35)
    v.co.y *= 1 + (widen - 1) * w

# ── 2. jaw and temple, as fractions of cheekbone width ─────────────
def band_y(z0, z1, factor, feather=0.14):
    for v in bm.verts:
        z = v.co.z
        if z < z0 - feather or z > z1 + feather:
            continue
        w = smooth((z - (z0 - feather)) / feather) if z < z0 else \
            smooth(((z1 + feather) - z) / feather) if z > z1 else 1.0
        v.co.y *= 1 + (factor - 1) * w

cheek_z = Z_CHIN + face_len * 0.42
jaw_z = Z_CHIN + face_len * 0.16
temple_z = Z_CHIN + face_len * 0.78
# measured ratios are relative to cheekbone width; the base mesh already
# tapers, so only the difference from its own taper is applied
band_y(jaw_z - 0.06, jaw_z + 0.06, 0.94 + 0.10 * (R['jaw_width_over_cheek'] / 0.62))
band_y(temple_z - 0.08, temple_z + 0.08, 0.93 + 0.10 * (R['temple_width_over_cheek'] / 0.66))

# ── 3. a squarer, slightly heavier jawline ─────────────────────────
for v in bm.verts:
    if Z_CHIN - 0.05 < v.co.z < Z_CHIN + face_len * 0.30 and v.co.x > -0.25:
        w = smooth(1 - abs(v.co.z - (Z_CHIN + face_len * 0.12)) / (face_len * 0.26))
        ay = abs(v.co.y)
        if ay > cur_w * 0.18:
            v.co.y += math.copysign(0.022 * w, v.co.y)
        if v.co.x > 0.1:
            v.co.x += 0.020 * w

# ── 3b. facial features: NOT sculpted procedurally ─────────────────
# Deliberately left alone. Coordinate-driven vertex nudges were tried for the
# eyes, nose and mouth and they damaged the face: the sockets became empty
# holes and the nose flattened. Identity likeness needs either a morphable
# face model or hand sculpting, so the base mesh's own (good) face is kept and
# the measurements are written to face_sheet.md for sculpting against.

# ── 4. brow ridge, the most characterful feature in the reference ──
brow_z = Z_CHIN + face_len * 0.60
for v in bm.verts:
    d = math.hypot((v.co.z - brow_z) / 0.10, abs(v.co.y) / 0.42)
    if d < 1.6 and v.co.x > 0.12:
        v.co.x += 0.028 * math.exp(-(d * 1.2) ** 2)

bm.to_mesh(body.data)
bm.free()
body.data.update()
print(f'head: widened x{widen:.3f}, face length {face_len:.2f}')

# ── 4b. eyeballs ───────────────────────────────────────────────────
# The base mesh keeps its eyes as separate helper geometry, which was dropped
# on import — leaving the sockets as open holes that read as black voids. Two
# spheres at the mesh's own eye joint markers fill them.
eye_c = {}
for side in ('l', 'r'):
    key = f'{side}-eye'
    if key not in J:
        continue
    c = J[key]
    bpy.ops.mesh.primitive_uv_sphere_add(segments=24, ring_count=16, location=c)
    o = bpy.context.active_object
    o.name = f'Eye_{side}'
    o.scale = (0.115, 0.115, 0.115)
    bpy.ops.object.transform_apply(scale=True)
    bpy.ops.object.shade_smooth()
    eye_c[side] = o

if eye_c:
    bpy.ops.object.select_all(action='DESELECT')
    for o in eye_c.values():
        o.select_set(True)
    bpy.context.view_layer.objects.active = list(eye_c.values())[0]
    bpy.ops.object.join()
    eyes = bpy.context.view_layer.objects.active
    eyes.name = 'Eyes'
    em = bpy.data.materials.new('eyes')
    em.use_nodes = True
    eb = em.node_tree.nodes['Principled BSDF']
    eb.inputs['Base Color'].default_value = (0.86, 0.84, 0.82, 1)
    eb.inputs['Roughness'].default_value = 0.18
    eyes.data.materials.append(em)
    # iris, sampled dark from the reference
    im = bpy.data.materials.new('iris')
    im.use_nodes = True
    ib = im.node_tree.nodes['Principled BSDF']
    ib.inputs['Base Color'].default_value = (0.07, 0.045, 0.03, 1)
    ib.inputs['Roughness'].default_value = 0.12
    eyes.data.materials.append(im)
    for p in eyes.data.polygons:
        if p.center.x > 0.0 and p.normal.x > 0.55:
            p.material_index = 1
    print('eyes added at the mesh joint markers')

# ── 5. hair ────────────────────────────────────────────────────────
# A smooth sculpted cap, not a shell duplicated from the scalp faces: at this
# mesh density a duplicated shell leaves a ragged stair-stepped hairline, which
# reads far worse than a clean simple form.
HAIR_H = R['hair_height_over_face'] * face_len
head_c = Vector((0.0, 0.0, Z_CHIN + face_len * 0.72))
head_r = cur_w * widen * 0.52

parts = []
def ball(centre, radii, name='h'):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=28, ring_count=18, location=centre)
    o = bpy.context.active_object
    o.scale = Vector(radii)
    bpy.ops.object.transform_apply(scale=True)
    parts.append(o)

# cranium cap, swept back, with the volume the reference carries above the brow
ball((head_c.x - 0.10, 0, head_c.z + HAIR_H * 0.20),
     (head_r * 1.06, head_r * 1.10, head_r * 0.98))
# the quiff: height at the front, which is the reference's defining feature
ball((head_c.x + 0.22, 0, head_c.z + HAIR_H * 0.52),
     (head_r * 0.80, head_r * 0.86, HAIR_H * 0.42))
# body at the back of the head
ball((head_c.x - 0.46, 0, head_c.z + HAIR_H * 0.06),
     (head_r * 0.74, head_r * 0.92, head_r * 0.90))
# sides, kept tight as in the reference
for sgn in (1, -1):
    ball((head_c.x - 0.12, sgn * head_r * 0.80, head_c.z - head_r * 0.12),
         (head_r * 0.86, head_r * 0.34, head_r * 0.80))

bpy.ops.object.select_all(action='DESELECT')
for o in parts:
    o.select_set(True)
bpy.context.view_layer.objects.active = parts[0]
bpy.ops.object.join()
hair = bpy.context.view_layer.objects.active
hair.name = 'Hair'
rm = hair.modifiers.new('R', 'REMESH')
rm.mode = 'VOXEL'; rm.voxel_size = 0.045
bpy.ops.object.modifier_apply(modifier='R')
sm = hair.modifiers.new('S', 'SMOOTH'); sm.factor = 0.5; sm.iterations = 6
bpy.ops.object.modifier_apply(modifier='S')

# cut away everything below the hairline and across the face
hbm = bmesh.new(); hbm.from_mesh(hair.data)
face_cut = Z_CHIN + face_len * (1.0 - R['forehead_over_face']) - 0.04
bmesh.ops.bisect_plane(hbm, geom=hbm.verts[:] + hbm.edges[:] + hbm.faces[:],
                       plane_co=(0, 0, head_c.z - head_r * 0.95), plane_no=(0, 0, -1),
                       clear_outer=True)
bmesh.ops.bisect_plane(hbm, geom=hbm.verts[:] + hbm.edges[:] + hbm.faces[:],
                       plane_co=(head_r * 0.52, 0, face_cut), plane_no=(1.0, 0, -0.75),
                       clear_outer=True)
hbm.to_mesh(hair.data); hbm.free()
hair.data.update()

mat = bpy.data.materials.new('hair')
mat.use_nodes = True
b = mat.node_tree.nodes['Principled BSDF']
b.inputs['Base Color'].default_value = (*hexof(C['hair']), 1)
b.inputs['Roughness'].default_value = 0.70
hair.data.materials.append(mat)
bpy.context.view_layer.objects.active = hair
bpy.ops.object.shade_smooth()
print('hair verts:', len(hair.data.vertices))

# ── 7. skin tone from the reference ────────────────────────────────
skin = [(a + b) / 2 for a, b in zip(C['skin_cheek'], C['skin_fore'])]
json.dump({'skin': skin, 'hair': C['hair'], 'beard': C['beard'], 'lip': C['lip']},
          open(os.path.join(OUT, 'palette.json'), 'w'))
print('skin #%02X%02X%02X' % tuple(int(v) for v in skin))

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'mh_shaped.blend'))
print('saved mh_shaped.blend')
